"""Demo 伺服器（只用標準庫）：python -m gcs_demo.server --port 8765
畫面：瀏覽器開 http://127.0.0.1:8765/
QGC/QML 之後可直接打同一組 JSON API（XMLHttpRequest）。
"""
from __future__ import annotations

import argparse
import json
import os
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from . import scenario as S
from .energy import Vehicle, Wind
from .llm import get_backend, backend_for
from .planner import plan_mission, replan, check_apply
from .planner_t3 import replan_context
from .report import make_report
from .sim import MissionRun
from .alert_bridge import AlertFeed, battery_raise
from .alerts.typed_explain import LegacyAlertExplainer

WEB = os.path.join(os.path.dirname(__file__), "web")


class Session:
    """單人 demo 的狀態。"""

    def __init__(self):
        self.lock = threading.Lock()
        self.calib = 1.0
        self.reset()

    def reset(self):
        self.mission = S.mission()
        self.wind = Wind(**S.WIND)
        self.plan = None
        self.chosen = None
        self.run = None
        self.replans = []
        self.alerts = []
        self.current_state = None
        self.active_event = None
        close = getattr(getattr(self, "feed", None), "explain_fn", None)
        if close is not None and hasattr(close, "close"):
            close.close(wait=False)
        self.feed = None

    def refresh_alerts(self):
        """取回背景完成的模型說明，重建告警畫面資料（分級先出、說明後補）。"""
        if self.feed is None or self.chosen is None:
            return self.alerts
        self.feed.poll_explanations()
        self.alerts = [_alert_view(e, self.chosen) for e in self.feed.events if e["type"] != "resolve"]
        return self.alerts

    def vehicle(self):
        return Vehicle(calib=self.calib)


SESSION = Session()


def _find(cands, cid):
    for c in cands:
        if c["id"] == cid:
            return c
    raise KeyError(cid)


def _alert_view(ev, cand):
    """告警引擎事件 → 畫面與報告用的精簡格式；航點編號換成目標名稱。"""
    names = [p["id"] for p in cand["path"][1:-1]]
    ex = ev.get("explain") or {}
    text = (ex.get("text") or {}).get("summary_zh") or f"{ev['title']}：{ev['value']}"
    for i in range(len(names), 0, -1):
        text = text.replace(f"WP{i}", f"WP{i}（{names[i-1]}）")
    return {"t_s": ev["t"], "key": ev["key"], "severity": ev["severity"], "title": ev["title"],
            "value": ev["value"], "lead_s": ev.get("lead_s"), "text_zh": text,
            "source": (ex.get("source") or "rule"), "level": "crit" if ev["severity"] <= 2 else "warn"}


def handle(path, body):
    s = SESSION
    with s.lock:
        if path == "/api/scenario":
            b = get_backend()
            return {"mission": s.mission, "wind": {"speed_mps": s.wind.speed_mps, "from_deg": s.wind.from_deg},
                    "vehicle": s.vehicle().to_dict(),
                    "llm": {"backend": b.name, "model": b.model, "url": b.url, "available": b.available()}}
        if path == "/api/reset":
            s.reset()
            return {"ok": True}
        if path == "/api/plan":
            if "wind" in body:
                s.wind = Wind(**body["wind"])
            if "calib" in body:
                s.calib = float(body["calib"])
            s.plan = plan_mission(s.mission, s.vehicle(), s.wind)
            s.run, s.replans, s.alerts = None, [], []
            s.current_state, s.active_event = None, None
            return s.plan
        if path == "/api/start":
            if not s.plan or body.get("mission_version") != s.plan.get("mission_version"):
                return {"ok": False, "reason_zh": "任務已變更，請重新規劃"}
            gate = check_apply(s.plan, s.mission, s.vehicle(), s.wind, s.current_state)
            if not gate["ok"]:
                return gate
            chosen = _find(s.plan["candidates"], body["choice_id"])
            if not chosen["feasible"]:
                return {"ok": False, "reason_zh": "候選不可行，不能套用"}
            if chosen.get("sorties"):
                return {"ok": False, "reason_zh": "S1 含兩個獨立架次，請分別檢視與套用；目前執行器僅支援單趟"}
            s.chosen = chosen
            s.run = MissionRun(s.vehicle(), s.wind, S.TRUE_CALIB, S.WIND_EVENTS)
            s.replans, s.alerts = [], []
            feed = AlertFeed(s.mission["home"], s.chosen["path"], s.vehicle(),
                             explain_fn=LegacyAlertExplainer(backend=backend_for("alerts")))
            s.feed = feed
            # 飛到告警引擎發出「電量不足以飛完／即將到最晚返航點」的預測告警為止
            state = s.run.fly(s.chosen, on_tick=lambda rec, i: battery_raise(feed.tick(rec, i)) is not None)
            s.refresh_alerts()
            s.current_state = state
            out = {"state": state, "telemetry": s.run.log, "alerts": s.alerts}
            if state["done"]:
                out.update({"report": make_report(s.run, s.mission, s.chosen, [], s.alerts, backend=backend_for("report"),
                                                  versions={"git_short_hash": os.environ.get("GCS_PROGRAM_GIT_SHORT_HASH")}),
                            "planned_curve": _curve(s.chosen)})
                return out
            trig = battery_raise(feed.events) or {}
            w = s.run._wind_now()
            event = {"type": "wind", "speed_mps": w.speed_mps, "from_deg": w.from_deg,
                     "text_zh": f"預測告警「{trig.get('title', '電量')}：{trig.get('value', '')}」"}
            s.active_event = event
            r = replan(s.mission, s.vehicle(), s.wind, state, event)
            s.replans.append(r)
            out.update({"alert": _alert_view(trig, s.chosen) if trig else None, "replan": r})
            return out
        if path == "/api/continue":
            if not s.replans or s.current_state is None or s.active_event is None:
                return {"ok": False, "reason_zh": "沒有可套用的重規劃"}
            r = s.replans[-1]
            if body.get("mission_version") != r.get("mission_version"):
                return {"ok": False, "reason_zh": "任務已變更，請重新規劃"}
            context = replan_context(s.mission, s.vehicle(), s.wind, s.current_state, s.active_event)
            gate = check_apply(r, *context)
            if not gate["ok"]:
                return gate
            cand = _find(r["candidates"], body["choice_id"])
            if not cand["feasible"]:
                return {"ok": False, "reason_zh": "候選不可行，不能套用"}
            r["final_choice"] = body["choice_id"]
            n0 = len(s.run.log)
            state = s.run.fly(cand)
            s.current_state = state
            s.refresh_alerts()
            rep = make_report(s.run, s.mission, s.chosen, s.replans, s.alerts, backend=backend_for("report"),
                              versions={"git_short_hash": os.environ.get("GCS_PROGRAM_GIT_SHORT_HASH")})
            return {"state": state, "telemetry": s.run.log[n0:], "report": rep, "alerts": s.alerts,
                    "planned_curve": _curve(s.chosen)}
        if path == "/api/alerts":
            alerts = s.refresh_alerts()
            return {"alerts": alerts, "pending": any(a["source"] == "rule_pending" for a in alerts)}
        if path == "/api/apply_calib":
            s.calib = float(body["calib"])
            return {"calib": s.calib}
    raise KeyError(path)


def _curve(cand):
    t, out = 0.0, [{"t_s": 0, "pct": 100.0}]
    for leg in cand["legs"]:
        t += leg["time_s"]
        out.append({"t_s": round(t, 1), "pct": leg["pct_after"]})
    return out


class Handler(BaseHTTPRequestHandler):
    def _send(self, code, data, ctype="application/json; charset=utf-8"):
        raw = data if isinstance(data, bytes) else json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(raw)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        if self.path in ("/", "/index.html"):
            with open(os.path.join(WEB, "index.html"), "rb") as f:
                return self._send(200, f.read(), "text/html; charset=utf-8")
        if self.path.startswith("/api/"):
            return self._api(self.path, {})
        self._send(404, {"error": "not found"})

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0) or 0)
        body = json.loads(self.rfile.read(n) or b"{}") if n else {}
        self._api(self.path, body)

    def _api(self, path, body):
        try:
            self._send(200, handle(path, body))
        except KeyError as exc:
            self._send(400, {"error": f"unknown {exc}"})
        except Exception as exc:  # demo：錯誤直接回給畫面
            self._send(500, {"error": repr(exc)})

    def log_message(self, fmt, *args):
        pass


# MVP 預設：經共用 LLM 閘道接真模型（契約 v0.3）；環境變數已設定者優先，--rules-only 回到純規則
GATEWAY = "http://127.0.0.1:8090"
MVP_LLM_DEFAULTS = {
    "GCS_LLM_BACKEND": "openai",
    "GCS_LLM_URL": GATEWAY + "/f/mission/v1",
    "GCS_LLM_URL_REPORT": GATEWAY + "/f/report/v1",
    "GCS_LLM_URL_ALERTS": GATEWAY + "/f/alerts/v1",
    "GCS_LLM_MODEL": "gemma4:e2b",
    "GCS_LLM_TIMEOUT": "60",
    "GCS_LLM_TIMEOUT_REPORT": "90",
}


def apply_mvp_llm_defaults(rules_only=False, environ=os.environ):
    if rules_only:
        environ["GCS_LLM_BACKEND"] = "none"
        return
    for k, v in MVP_LLM_DEFAULTS.items():
        environ.setdefault(k, v)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--rules-only", action="store_true", help="不接模型，全部走規則")
    a = ap.parse_args()
    apply_mvp_llm_defaults(a.rules_only)
    b = get_backend()
    print(f"GCS 任務規劃 demo：http://{a.host}:{a.port}/  （LLM 後端：{b.name} {b.model or ''}）")
    ThreadingHTTPServer((a.host, a.port), Handler).serve_forever()


if __name__ == "__main__":
    main()
