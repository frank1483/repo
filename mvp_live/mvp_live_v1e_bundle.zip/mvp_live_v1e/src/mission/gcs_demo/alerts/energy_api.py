"""告警用的能耗入口：直接用三功能共用的 gcs_demo/energy.py，只做座標轉換。

告警引擎內部用本地 ENU 公尺 (x 東, y 北, alt)，共用模型吃經緯度；這裡把兩者接起來，
數字完全由共用模型算，告警不另養一套。速度參數是「地速指令」（PX4 任務巡航速度）。
"""
from __future__ import annotations

import math
from dataclasses import replace

from gcs_demo import energy as _e
from gcs_demo.energy import Vehicle, Wind  # noqa: F401  (re-export)

SOURCE = "gcs_demo.energy"
REF_LAT, REF_LON = 23.6945, 120.5340        # 本地座標原點（demo 用）
_M_PER_DEG = math.pi * _e.R_EARTH / 180.0


def to_latlon(p):
    lat = REF_LAT + p[1] / _M_PER_DEG
    lon = REF_LON + p[0] / (_M_PER_DEG * math.cos(math.radians(REF_LAT)))
    return lat, lon


def default_vehicle(path_or_id=None) -> Vehicle:
    """Load an explicit shared profile, or keep the legacy 6 kg / 488 Wh demo.

    Profile I/O and validation errors propagate; never substitute demo values.
    No default aircraft is selected silently for an existing demo caller.
    """
    if path_or_id is not None:
        return _e.load_airframe(path_or_id)
    return Vehicle(vehicle_id="UAV-01", mass_kg=6.0, battery_wh=488.0, usable_frac=1.0,
                   p_hover_w=800.0, cda_m2=0.15, eta=0.7, cruise_mps=12.0, max_mps=16.0,
                   reserve_pct=20.0)


def profile_limits(v: Vehicle) -> dict:
    """Only these two alert thresholds belong to the shared airframe profile.

    Other alert policy and battery-voltage estimator settings stay in Config.
    Returned scalars are a snapshot; this does not mutate the loaded profile.
    """
    if v.airframe_profile is None:
        return {}
    limits = v.airframe_profile["limits"]
    return {key: limits[key] for key in ("reserve_pct", "wind_limit_mps")}


def air_power_w(v: Vehicle, v_air: float) -> float:
    return _e.power_w(v, v_air)


def leg_energy(v: Vehicle, p0, p1, wind: Wind, ground_mps: float | None = None) -> dict:
    return _e.leg_estimate(v, to_latlon(p0), to_latlon(p1), p0[2], p1[2],
                           ground_mps or v.cruise_mps, wind)


def rtl_energy(pos, home, v: Vehicle, wind: Wind) -> dict:
    lat, lon = to_latlon(pos)
    hlat, hlon = to_latlon(home)
    return _e.rtl_energy({"lat": lat, "lon": lon, "alt": pos[2]}, {"lat": hlat, "lon": hlon}, v, wind)


def with_calib(v: Vehicle, calib: float) -> Vehicle:
    return replace(v, calib=calib)


def typed_alert_speeds(vehicle, requested, mode=None, bank_deg=0.0):
    """Typed preparation only; legacy ENU alert engine remains unchanged."""
    return _e.typed_alert_speeds(vehicle, requested, mode, bank_deg)


def evaluate_typed_alert_candidates(vehicle, candidates, wind, start_pct=100.0):
    """Caller supplies normalized lat/lon mission events, never ENU tuples."""
    return _e.evaluate_typed_alert_candidates(vehicle, candidates, wind, start_pct)


def geographic_wind_route_bounds(vehicle, entry, events, wind, start_pct=100.0, mode=None):
    """Explicit geographic input; no legacy ENU conversion or live tick."""
    return _e.geographic_wind_route_bounds(vehicle, entry, events, wind, start_pct, mode)


def evaluate_geographic_alert_candidates(vehicle, candidates, wind, start_pct=100.0):
    """Additive typed caller; candidate entry/events are already geographic."""
    return _e.evaluate_geographic_alert_candidates(vehicle, candidates, wind, start_pct)


def geographic_energy_alert_snapshot(vehicle, candidates, current_id, wind, start_pct=100.0):
    """Additive FW geographic P1 entry; old ENU predictors remain separate."""
    return _e.geographic_energy_alert_snapshot(vehicle, candidates, current_id, wind, start_pct)


# New explicit predictor class. This does not enable the legacy MC engine for FW.
from .typed_geographic import GeographicEnergyAlertPredictor  # noqa: E402,F401

# Opt-in measured geographic P1 caller; no legacy ENU/model fallback.
from .typed_feed import TypedGeographicAlertFeed  # noqa: E402,F401
