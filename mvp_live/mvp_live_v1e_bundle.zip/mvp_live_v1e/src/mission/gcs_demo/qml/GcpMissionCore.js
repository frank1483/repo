.pragma library
// 任務規劃與智慧任務報告的演算法核心（gcs_demo/*.py 的 JS 移植，給 APK 內的 QML 用）。
// 純 JS、不碰 QML 物件；node 也能載入（test/test_core.js 用它和 Python 版比對）。
// 原則同共用介面：演算法算數字、產生候選、先做規則選擇；模型只在候選內選 ID 或改寫有證據的建議。

var R_EARTH = 6371000.0
var RHO = 1.225
var G = 9.81

function rnd(x, n) { var k = Math.pow(10, n || 0); return Math.round(x * k) / k }
function rad(d) { return d * Math.PI / 180 }
function clone(o) { return JSON.parse(JSON.stringify(o)) }

// ---------------- 能耗 ----------------

function haversineM(a, b) {
    var lat1 = rad(a[0]), lon1 = rad(a[1]), lat2 = rad(b[0]), lon2 = rad(b[1])
    var h = Math.pow(Math.sin((lat2 - lat1) / 2), 2) +
            Math.cos(lat1) * Math.cos(lat2) * Math.pow(Math.sin((lon2 - lon1) / 2), 2)
    return 2 * R_EARTH * Math.asin(Math.sqrt(h))
}

function bearingRad(a, b) {
    var lat1 = rad(a[0]), lon1 = rad(a[1]), lat2 = rad(b[0]), lon2 = rad(b[1])
    var y = Math.sin(lon2 - lon1) * Math.cos(lat2)
    var x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(lon2 - lon1)
    return Math.atan2(y, x)
}

function vehicle(over) {
    var v = { vehicle_id: "UAV-01", mass_kg: 2.0, battery_wh: 90.0, usable_frac: 0.9, p_hover_w: 190.0,
              cda_m2: 0.12, eta: 0.7, cruise_mps: 8.0, max_mps: 15.0, reserve_pct: 20.0, calib: 1.0 }
    for (var k in (over || {})) v[k] = over[k]
    return v
}

// T5a: pure profile primitives. JSON/file loading belongs to the QML caller.
function profileNumber(x, name, low, high, positive) {
    if (typeof x !== "number" || !isFinite(x)) throw new Error(name + ": finite number required")
    if (low === undefined) low = 0
    if (x < low || (positive && x <= low) || (high !== undefined && x > high)) throw new Error(name + ": out of range")
    return x
}
function profileObject(x, name) {
    if (!x || typeof x !== "object" || Array.isArray(x)) throw new Error(name + ": object required")
    return x
}
function profileMerge(defaults, value, name) {
    profileObject(value, name)
    var result = clone(defaults)
    for (var k in value) if (Object.prototype.hasOwnProperty.call(value, k)) result[k] = value[k]
    return result
}
function profileMc(p, prefix) {
    p = profileMerge({p_hover_w:190, cda_m2:0.12, eta:0.7}, p, prefix)
    profileNumber(p.p_hover_w, prefix + ".p_hover_w", 0, undefined, true)
    profileNumber(p.cda_m2, prefix + ".cda_m2")
    profileNumber(p.eta, prefix + ".eta", 0, 1, true)
    return p
}
function profileFw(p, prefix) {
    profileObject(p, prefix)
    var keys = ["wing_area_m2", "cd0", "k_induced", "eta_prop", "p_avionics_w", "v_stall_mps", "min_turn_radius_m"]
    keys.forEach(function(k) {
        profileNumber(p[k], prefix + "." + k, 0, k === "eta_prop" ? 1 : undefined, k !== "p_avionics_w")
    })
    return p
}
function profileLoadFactor(bankDeg) {
    profileNumber(bankDeg, "bank_deg", -90, 90)
    if (Math.abs(bankDeg) >= 90) throw new Error("bank_deg: absolute bank must be less than 90 degrees")
    return 1 / Math.cos(rad(bankDeg))
}
function profileSpeedRange(p, bankDeg) {
    if (bankDeg === undefined) bankDeg = 0
    var lo = p.limits.min_airspeed_mps
    if (p.type !== "multirotor") {
        var f = p.type === "fixed_wing" ? p.power : p.power.fw
        lo = Math.max(lo, 1.2 * f.v_stall_mps * Math.sqrt(profileLoadFactor(bankDeg)))
    }
    return [lo, p.limits.max_airspeed_mps]
}
function validateAirframeProfile(value) {
    profileObject(value, "profile")
    // Copy without JSON round-tripping until validation: JSON turns NaN/Infinity
    // into null and would lose unknown provenance fields. Only JSON data accepted.
    function copy(x) {
        if (x === null || typeof x === "string" || typeof x === "boolean") return x
        if (typeof x === "number") {
            if (!isFinite(x)) throw new Error("profile: nonfinite JSON number")
            return x
        }
        if (Array.isArray(x)) return x.map(copy)
        profileObject(x, "profile value")
        var o = {}
        Object.keys(x).forEach(function(k) {
            if (k === "__proto__" || k === "constructor" || k === "prototype") throw new Error("profile: reserved key")
            o[k] = copy(x[k])
        })
        return o
    }
    var p = copy(value)
    if (p.id === undefined) p.id = "UAV-01"
    if (typeof p.id !== "string" || !p.id.trim()) throw new Error("id: nonempty string required")
    if (p.type === undefined) p.type = "multirotor"
    if (["multirotor", "fixed_wing", "vtol_hybrid"].indexOf(p.type) < 0) throw new Error("type: unsupported airframe")
    if (p.schema === undefined) p.schema = 0
    if (p.schema !== 0) throw new Error("schema: only version 0 is supported")
    if (p.mass_kg === undefined) p.mass_kg = 2
    if (p.calib === undefined) p.calib = 1
    if (p.source === undefined) p.source = "assumed"
    if (typeof p.source !== "string" || !p.source.trim()) throw new Error("source: nonempty string required")
    profileNumber(p.mass_kg, "mass_kg", 0, undefined, true)
    profileNumber(p.calib, "calib", 0, undefined, true)
    p.battery = profileMerge({wh:90, usable_frac:0.9, cell_count:4, cell_empty_v:3.55, cell_r_ohm:0.004}, p.battery === undefined ? {} : p.battery, "battery")
    p.limits = profileMerge({reserve_pct:20, wind_limit_mps:12, min_airspeed_mps:0, max_airspeed_mps:15, cruise_mps:8}, p.limits === undefined ? {} : p.limits, "limits")
    p.uncertainty = profileMerge({power_pct:10, capacity_pct:5, wind_mps:2}, p.uncertainty === undefined ? {} : p.uncertainty, "uncertainty")
    var b = p.battery, l = p.limits, u = p.uncertainty
    profileNumber(b.wh, "battery.wh", 0, undefined, true)
    profileNumber(b.usable_frac, "battery.usable_frac", 0, 1, true)
    profileNumber(b.cell_count, "battery.cell_count", 0, undefined, true)
    if (Math.floor(b.cell_count) !== b.cell_count) throw new Error("battery.cell_count: integer required")
    profileNumber(b.cell_empty_v, "battery.cell_empty_v", 0, undefined, true)
    profileNumber(b.cell_r_ohm, "battery.cell_r_ohm")
    Object.keys({reserve_pct:0, wind_limit_mps:0, min_airspeed_mps:0, max_airspeed_mps:0, cruise_mps:0}).forEach(function(k) {
        profileNumber(l[k], "limits." + k, 0, k === "reserve_pct" ? 100 : undefined, k === "max_airspeed_mps" || k === "cruise_mps")
    })
    Object.keys({power_pct:0, capacity_pct:0, wind_mps:0}).forEach(function(k) {
        profileNumber(u[k], "uncertainty." + k, 0, k === "wind_mps" ? undefined : 100)
    })
    if (u.capacity_pct >= 100) throw new Error("uncertainty.capacity_pct: must leave positive capacity")
    var pw = p.power === undefined ? {} : p.power
    if (p.type === "multirotor") p.power = profileMc(pw, "power")
    else if (p.type === "fixed_wing") p.power = profileFw(pw, "power")
    else {
        profileObject(pw, "power")
        pw.mc = profileMc(pw.mc === undefined ? {} : pw.mc, "power.mc")
        pw.fw = profileFw(pw.fw === undefined ? {} : pw.fw, "power.fw")
        p.power = pw
        p.transition = profileObject(p.transition === undefined ? {} : p.transition, "transition")
        ;["to_fw_wh", "to_fw_s", "to_fw_dist_m", "to_mc_wh", "to_mc_s"].forEach(function(k) {
            profileNumber(p.transition[k], "transition." + k)
        })
    }
    var prop = p.prop_model
    if (prop !== undefined && prop !== null) {
        if (typeof prop === "string") {
            if (!prop.trim()) throw new Error("prop_model: nonempty identifier required")
        } else {
            profileObject(prop, "prop_model")
            if (typeof prop.id !== "string" || !prop.id.trim()) throw new Error("prop_model.id: nonempty string required")
            if ((prop.rpm !== undefined) !== (prop.diameter_m !== undefined)) throw new Error("prop_model: rpm and diameter_m must appear together")
            ;["rpm", "diameter_m"].forEach(function(k) {
                if (prop[k] !== undefined) profileNumber(prop[k], "prop_model." + k, 0, undefined, true)
            })
        }
    }
    if (p.eta_table !== undefined) {
        if (!prop || !Array.isArray(p.eta_table) || p.eta_table.length < 2) throw new Error("eta_table: prop_model and at least two [J, eta] rows required")
        var previous = -1
        p.eta_table.forEach(function(row) {
            if (!Array.isArray(row) || row.length !== 2) throw new Error("eta_table: rows must be [J, eta]")
            profileNumber(row[0], "eta_table.J")
            profileNumber(row[1], "eta_table.eta", 0, 1, true)
            if (row[0] <= previous) throw new Error("eta_table: J must be strictly increasing")
            previous = row[0]
        })
    }
    var range = profileSpeedRange(p)
    if (range[0] > range[1] || l.cruise_mps < range[0] || l.cruise_mps > range[1]) throw new Error("limits: cruise and max must satisfy the effective airspeed range")
    return p
}
function loadAirframe(jsonOrObject) {
    // QML supplies file contents; this core never reads disk or downloads files.
    var p = validateAirframeProfile(typeof jsonOrObject === "string" ? JSON.parse(jsonOrObject.replace(/^\uFEFF/, "")) : jsonOrObject)
    var mc = p.type === "multirotor" ? p.power : p.type === "vtol_hybrid" ? p.power.mc : {p_hover_w:0, cda_m2:0, eta:1}
    return vehicle({vehicle_id:p.id, mass_kg:p.mass_kg, battery_wh:p.battery.wh, usable_frac:p.battery.usable_frac,
                    p_hover_w:mc.p_hover_w, cda_m2:mc.cda_m2, eta:mc.eta, cruise_mps:p.limits.cruise_mps,
                    max_mps:p.limits.max_airspeed_mps, reserve_pct:p.limits.reserve_pct, calib:p.calib,
                    airframe_profile:p})
}
function airframeType(v) { return v.airframe_profile ? v.airframe_profile.type : "multirotor" }
function speedRange(v, bankDeg) {
    return v.airframe_profile ? profileSpeedRange(v.airframe_profile, bankDeg) : [0, v.max_mps]
}
function propEfficiency(p, vAir, fallback, advanceRatio) {
    var table = p.eta_table
    if (!table) return fallback
    var j = advanceRatio, prop = p.prop_model
    if ((j === undefined || j === null) && prop && typeof prop === "object" && prop.rpm !== undefined) j = vAir / (prop.rpm / 60 * prop.diameter_m)
    if (j === undefined || j === null) return fallback
    profileNumber(j, "advance_ratio")
    if (j <= table[0][0]) return table[0][1]
    for (var i = 1; i < table.length; i++) {
        if (j <= table[i][0]) {
            var a = table[i - 1], b = table[i]
            return a[1] + (b[1] - a[1]) * (j - a[0]) / (b[0] - a[0])
        }
    }
    return table[table.length - 1][1]
}
function profilePowerW(p, vAir, mode, bankDeg, climbMps, advanceRatio, massKg) {
    if (bankDeg === undefined) bankDeg = 0
    if (climbMps === undefined) climbMps = 0
    profileNumber(vAir, "v_air")
    profileNumber(climbMps, "climb_mps", -1e100)
    profileLoadFactor(bankDeg)
    var pw
    if (p.type === "vtol_hybrid") {
        if (mode !== "mc" && mode !== "fw") throw new Error("vtol_hybrid power requires explicit mode='mc' or 'fw'")
        pw = p.power[mode]
    } else {
        var active = p.type === "multirotor" ? "mc" : "fw"
        if (mode !== undefined && mode !== null && mode !== active) throw new Error("mode is incompatible with airframe type")
        mode = active; pw = p.power
    }
    var mass = massKg === undefined ? p.mass_kg : massKg
    profileNumber(mass, "mass_kg", 0, undefined, true)
    var climb = mass * G * Math.max(0, climbMps)
    if (mode === "mc") {
        if (bankDeg !== 0) throw new Error("multirotor bank compensation is not modeled")
        return pw.p_hover_w + 0.5 * RHO * pw.cda_m2 * Math.pow(vAir, 3) / pw.eta + climb / pw.eta
    }
    var n = profileLoadFactor(bankDeg), range = profileSpeedRange(p, bankDeg)
    if (vAir < range[0] || vAir > range[1]) throw new Error("v_air: outside fixed-wing airspeed/stall envelope")
    var eta = propEfficiency(p, vAir, pw.eta_prop, advanceRatio)
    var drag = 0.5 * RHO * Math.pow(vAir, 3) * pw.wing_area_m2 * pw.cd0 +
            2 * pw.k_induced * Math.pow(mass * G, 2) * n * n / (RHO * vAir * pw.wing_area_m2)
    return (drag + climb) / eta + pw.p_avionics_w
}
function turnGeometry(v, vAir, bankDeg, radiusM) {
    if (airframeType(v) === "multirotor") throw new Error("turn geometry is defined only for fixed-wing flight")
    var p = v.airframe_profile, pw = p.type === "fixed_wing" ? p.power : p.power.fw
    profileNumber(vAir, "v_air", 0, undefined, true)
    var hasBank = bankDeg !== undefined && bankDeg !== null, hasRadius = radiusM !== undefined && radiusM !== null
    if (hasBank && hasRadius) throw new Error("specify bank_deg or radius_m, not both")
    if (!hasBank) {
        if (!hasRadius) radiusM = pw.min_turn_radius_m
        profileNumber(radiusM, "radius_m", 0, undefined, true)
        bankDeg = Math.atan(vAir * vAir / (G * radiusM)) * 180 / Math.PI
    }
    var n = profileLoadFactor(bankDeg)
    var radius = bankDeg === 0 ? null : vAir * vAir / (G * Math.abs(Math.tan(rad(bankDeg))))
    if (radius !== null && radius < pw.min_turn_radius_m - 1e-9) throw new Error("turn radius below configured minimum")
    var range = profileSpeedRange(p, bankDeg)
    if (vAir < range[0] || vAir > range[1]) throw new Error("turn exceeds bank-adjusted stall/airspeed envelope")
    return {bank_deg:bankDeg, load_factor:n, radius_m:radius, min_airspeed_mps:range[0]}
}
function requireLegacyRoute(v) {
    if (airframeType(v) !== "multirotor") throw new Error("T5b route/transition/bounds integration pending; fixed-wing/hybrid routes unavailable")
}


// NaN 不能用 || 0 靜默變成無風；僅缺省值使用 0。
function wind(speed, fromDeg) {
    return { speed_mps: speed === undefined ? 0 : speed, from_deg: fromDeg === undefined ? 0 : fromDeg }
}

function windVector(w) {
    var to = rad(w.from_deg + 180.0)
    return [w.speed_mps * Math.sin(to), w.speed_mps * Math.cos(to)]   // (east, north)
}

function powerW(v, vAir, mode, bankDeg, climbMps, advanceRatio) {
    if (!v.airframe_profile && (mode === undefined || mode === null) && (bankDeg === undefined || bankDeg === 0) &&
            (climbMps === undefined || climbMps === 0) && (advanceRatio === undefined || advanceRatio === null))
        return v.p_hover_w + 0.5 * RHO * v.cda_m2 * Math.pow(vAir, 3) / v.eta
    var p = v.airframe_profile || {type:"multirotor", power:{}}
    if (airframeType(v) === "multirotor") {
        p = profileMerge({}, p, "profile")
        p.power = profileMerge(p.power, {p_hover_w:v.p_hover_w, cda_m2:v.cda_m2, eta:v.eta}, "power")
    }
    return profilePowerW(p, vAir, mode, bankDeg, climbMps, advanceRatio, v.mass_kg)
}

function legEstimate(v, a, b, altA, altB, groundMps, w, mode) {
    if (airframeType(v) !== "multirotor") return airframeLegEstimate(v,a,b,altA,altB,groundMps,w,mode)
    flightMode(v,mode)
    var dist = haversineM(a, b), t = 0, vAir = 0, head = 0
    if (dist >= 0.5) {
        var brg = bearingRad(a, b)
        var ge = groundMps * Math.sin(brg), gn = groundMps * Math.cos(brg)
        var wv = windVector(w)
        vAir = Math.hypot(ge - wv[0], gn - wv[1])
        head = -(wv[0] * Math.sin(brg) + wv[1] * Math.cos(brg))
        t = dist / groundMps
    }
    var eJ = powerW(v, vAir) * t
    var climb = Math.max(0, altB - altA)
    eJ += v.mass_kg * G * climb / v.eta
    var vt = climb > 0 ? climb / 3.0 : Math.max(0, altA - altB) / 2.0
    t += vt
    eJ += v.p_hover_w * vt
    return { dist_m: dist, time_s: t, energy_wh: eJ / 3600.0 * v.calib, v_air: vAir, headwind_mps: head }
}

function routeEstimate(v, points, groundMps, w, startPct, hoverS, mode) {
    if (airframeType(v) !== "multirotor") return airframeRouteEstimate(v,points,groundMps,w,startPct,hoverS,mode)
    flightMode(v,mode)
    if (startPct === undefined) startPct = 100.0
    if (hoverS === undefined) hoverS = 5.0
    var legs = [], wh = 0, ts = 0, dm = 0, cap = v.battery_wh * v.usable_frac, pct = startPct
    for (var i = 0; i < points.length - 1; i++) {
        var a = points[i], b = points[i + 1]
        var e = legEstimate(v, [a.lat, a.lon], [b.lat, b.lon], a.alt || 0, b.alt || 0, groundMps, w)
        var hover = b.kind === "target" ? hoverS : 0
        e.energy_wh += v.p_hover_w * hover / 3600.0 * v.calib
        e.time_s += hover
        pct -= e.energy_wh / cap * 100.0
        e.from = a.id; e.to = b.id; e.pct_after = pct
        legs.push(e)
        wh += e.energy_wh; ts += e.time_s; dm += e.dist_m
    }
    return { dist_m: dm, time_s: ts, energy_wh: wh, end_pct: pct, used_pct: startPct - pct,
             margin_pct: pct - v.reserve_pct, feasible: pct >= v.reserve_pct, legs: legs }
}

function bestSpeed(v, w, headingDeg, lo, hi, mode) {
    if (airframeType(v) !== "multirotor") return airframeBestSpeed(v,w,headingDeg,lo,hi,mode)
    flightMode(v,mode)
    if (lo === undefined) lo = 4
    if (hi === undefined || hi === null) hi = v.max_mps
    var a = [0, 0], b = [0.001 * Math.cos(rad(headingDeg || 0)), 0.001 * Math.sin(rad(headingDeg || 0))]
    var best = null
    for (var s = lo; s <= hi + 1e-9; s += 0.5) {
        var e = legEstimate(v, a, b, 0, 0, s, w)
        var perKm = e.energy_wh / Math.max(e.dist_m, 1) * 1000
        if (best === null || perKm < best[1]) best = [rnd(s, 1), perKm]
    }
    if (best === null) return { speed_mps: null, wh_per_km: null, error: "沒有可搜尋的速度" }
    return { speed_mps: best[0], wh_per_km: rnd(best[1], 2) }
}

// ---------------- 禁航區 ----------------

function toXY(o, p) {
    var lat0 = rad(o[0])
    return [rad(p[1] - o[1]) * R_EARTH * Math.cos(lat0), rad(p[0] - o[0]) * R_EARTH]
}
function toLL(o, xy) {
    var lat0 = rad(o[0])
    return [o[0] + xy[1] / R_EARTH * 180 / Math.PI, o[1] + xy[0] / (R_EARTH * Math.cos(lat0)) * 180 / Math.PI]
}
function segCircleHit(a, b, c, r) {
    var dx = b[0] - a[0], dy = b[1] - a[1], l2 = dx * dx + dy * dy
    var t = l2 === 0 ? 0 : Math.max(0, Math.min(1, ((c[0] - a[0]) * dx + (c[1] - a[1]) * dy) / l2))
    var px = a[0] + t * dx, py = a[1] + t * dy
    return Math.hypot(px - c[0], py - c[1]) < r ? t : null
}

function insertDetours(points, zones, origin) {
    if (!points.length) return []
    var out = [points[0]], n = 0
    for (var i = 1; i < points.length; i++) {
        var b = points[i], a = out[out.length - 1]
        for (var j = 0; j < zones.length; j++) {
            var z = zones[j]
            var A = toXY(origin, [a.lat, a.lon]), B = toXY(origin, [b.lat, b.lon]), C = toXY(origin, [z.lat, z.lon])
            if (segCircleHit(A, B, C, z.radius_m) === null) continue
            var dx = B[0] - A[0], dy = B[1] - A[1], L = Math.hypot(dx, dy) || 1
            var nx = -dy / L, ny = dx / L, mx = (A[0] + B[0]) / 2, my = (A[1] + B[1]) / 2
            var side = (mx - C[0]) * nx + (my - C[1]) * ny >= 0 ? 1 : -1
            var r = z.radius_m * 1.35
            var w = toLL(origin, [C[0] + side * nx * r, C[1] + side * ny * r])
            n += 1
            out.push({ id: "繞" + z.id + "-" + n, lat: w[0], lon: w[1], alt: Math.max(a.alt || 0, b.alt || 0), kind: "detour" })
            break
        }
        out.push(b)
    }
    return out
}

function zoneViolations(points, zones, origin) {
    var bad = []
    for (var i = 0; i < points.length - 1; i++) {
        var A = toXY(origin, [points[i].lat, points[i].lon]), B = toXY(origin, [points[i + 1].lat, points[i + 1].lon])
        for (var j = 0; j < zones.length; j++) {
            var z = zones[j]
            if (segCircleHit(A, B, toXY(origin, [z.lat, z.lon]), z.radius_m) !== null)
                bad.push(points[i].id + "→" + points[i + 1].id + " 穿越 " + z.id)
        }
    }
    return bad
}

// ---------------- 排序 ----------------

function costFn(v, w, speed, mode) {
    return function (a, b) {
        if (mode === "dist") return haversineM([a.lat, a.lon], [b.lat, b.lon])
        return routeEstimate(v, [a, b], speed, w).energy_wh
    }
}

function orderTargets(start, targets, end, cost) {
    var rem = targets.slice(), seq = [], cur = start
    while (rem.length) {
        var bi = 0
        for (var i = 1; i < rem.length; i++) if (cost(cur, rem[i]) < cost(cur, rem[bi])) bi = i
        cur = rem.splice(bi, 1)[0]
        seq.push(cur)
    }
    function total(s) {
        var p = [start].concat(s, [end]), c = 0
        for (var i = 0; i < p.length - 1; i++) c += cost(p[i], p[i + 1])
        return c
    }
    var best = total(seq), improved = true
    while (improved && seq.length > 2) {
        improved = false
        for (var a = 0; a < seq.length - 1; a++)
            for (var b = a + 1; b < seq.length; b++) {
                var cand = seq.slice(0, a).concat(seq.slice(a, b + 1).reverse(), seq.slice(b + 1))
                var c = total(cand)
                if (c < best - 1e-9) { seq = cand; best = c; improved = true }
            }
    }
    return seq
}

// ---------------- 候選 ----------------

function evaluate(cid, label, how, mission, v, w, path, speed, startPct) {
    var origin = [mission.home.lat, mission.home.lon], zones = mission.no_fly || []
    path = insertDetours(path, zones, origin)
    var est = routeEstimate(v, path, speed, w, startPct)
    var viol = zoneViolations(path, zones, origin)
    var maxAlt = (mission.limits || {}).max_altitude_m || 120
    path.forEach(function (p) { if ((p.alt || 0) > maxAlt) viol.push(p.id + " 高度 " + p.alt + " m 超過上限 " + maxAlt + " m") })
    var tids = path.filter(function (p) { return p.kind === "target" }).map(function (p) { return p.id })
    var must = mission.targets.filter(function (t) { return (t.priority || 1) === 1 }).map(function (t) { return t.id })
    var done = mission.completed || []
    var missing = must.filter(function (m) { return tids.indexOf(m) < 0 && done.indexOf(m) < 0 })
    var mustRank = 0
    tids.forEach(function (t, i) { if (must.indexOf(t) >= 0) mustRank += i })
    return {
        id: cid, label: label, how: how, order: tids, speed_mps: speed, calib: v.calib,
        dist_km: rnd(est.dist_m / 1000, 2), time_min: rnd(est.time_s / 60, 1),
        energy_wh: rnd(est.energy_wh, 1), end_pct: rnd(est.end_pct, 1), margin_pct: rnd(est.margin_pct, 1),
        feasible: est.feasible && viol.length === 0 && missing.length === 0,
        violations: viol, missing_must: missing, must_rank: mustRank,
        constraint_deltas: constraintDeltas(mission, v, path, est, missing),
        path: path.map(function (p) { return { id: p.id, lat: p.lat, lon: p.lon, alt: p.alt || 0, kind: p.kind, priority: p.priority } }),
        legs: est.legs.map(function (l) {
            return { from: l.from, to: l.to, dist_m: rnd(l.dist_m, 2), time_s: rnd(l.time_s, 2), energy_wh: rnd(l.energy_wh, 2),
                     headwind_mps: rnd(l.headwind_mps, 2), pct_after: rnd(l.pct_after, 2) }
        })
    }
}

function ruleChoice(cands) {
    // 分兩趟（S1）需要換電、目前無法一次套用：只列為建議，不當規則選擇
    var feas = cands.filter(function (c) { return c.feasible && !c.requires_battery_swap })
    if (!feas.length) return ""
    var best = feas.reduce(function (a, c) {
        if (c.order.length !== a.order.length) return c.order.length > a.order.length ? c : a
        return c.energy_wh < a.energy_wh ? c : a
    })
    // 能耗差 3% 以內視為同等，改選「必要目標較早完成」者
    var near = feas.filter(function (c) { return c.order.length === best.order.length && c.energy_wh <= best.energy_wh * 1.03 })
    return near.reduce(function (a, c) {
        if (c.must_rank !== a.must_rank) return c.must_rank < a.must_rank ? c : a
        return c.energy_wh < a.energy_wh ? c : a
    }).id
}

function evidenceFor(cands, v, w, extra) {
    var ev = [{ id: "E1", text: "風速 " + w.speed_mps + " m/s，風從 " + Math.round(w.from_deg) + "° 吹來" },
              { id: "E2", text: "電池 " + v.battery_wh + " Wh，可用 " + Math.round(v.usable_frac * 100) + "%，落地保留 " +
                                v.reserve_pct + "%，耗電修正係數 " + v.calib.toFixed(2) }]
    cands.forEach(function (c, i) {
        var why = c.violations.concat(c.missing_must)
        ev.push({ id: "E" + (i + 3), text: c.id + " " + c.label + "：落地剩 " + c.end_pct + "%，" + (c.feasible ? "可行" : "不可行") +
                                       (!c.feasible && why.length ? "（" + why.join("；") + "）" : "") })
    })
    cands.forEach(function (c, i) {
        var entry = ev[i + 2]
        if (!c.feasible) {
            entry.value = {candidate_id: c.id, violations: c.constraint_deltas}
            entry.text += "；約束差額：" + JSON.stringify(c.constraint_deltas)
        }
        if (c.sorties) {
            entry.value = {candidate_id: c.id, sorties: c.sorties.map(function (s) { return {id:s.id, end_pct:s.end_pct, margin_pct:s.margin_pct} })}
            entry.text += "（兩趟各自返航／滿電出發；落地電量表示兩趟較低值，非累積值）"
        }
    })
    ;(extra || []).forEach(function (e) { ev.push({ id: "E" + (ev.length + 1), text: e }) })
    return ev
}

function brief(c) {
    return { id: c.id, label: c.label, order: c.order, speed_mps: c.speed_mps, dist_km: c.dist_km, time_min: c.time_min,
             energy_wh: c.energy_wh, end_pct: c.end_pct, margin_pct: c.margin_pct, feasible: c.feasible }
}

function home(m) { var h = clone(m.home); if (!h.id) h.id = "H"; h.alt = 0; h.kind = "home"; return h }
function targets(m) { return m.targets.map(function (t) { var p = clone(t); p.kind = "target"; return p }) }

function rulePick(rc, text) {
    return rc ? { choice_id: rc, source: "rule", decision: "SELECT", reason_zh: text || "規則選擇：可行候選中能耗最低且涵蓋所有必要目標。", evidence_ids: [] }
              : { choice_id: "", source: "rule", decision: "HOLD", reason_zh: "所有候選都不可行（電量或限制不符），建議換電池、分兩趟或減少目標。", evidence_ids: [] }
}

// ---------------- 入口邊界（不改有效輸入的排序、能耗公式或候選 ID） ----------------
function finiteNumber(x) { return typeof x === "number" && isFinite(x) }
function coordinate(p) {
    return p && finiteNumber(p.lat) && finiteNumber(p.lon) && Math.abs(p.lat) <= 90 && Math.abs(p.lon) <= 180
}
function inputError(m, v, w, allowEmpty) {
    if (!m || !coordinate(m.home) || !Array.isArray(m.targets)) return "home 或航點格式無效"
    if (!allowEmpty && !m.targets.length) return "沒有任務航點，請先加入目標"
    if (!v || !w || !finiteNumber(w.speed_mps) || w.speed_mps < 0 || !finiteNumber(w.from_deg)) return "風速或風向無效"
    var positive = ["mass_kg", "battery_wh", "usable_frac", "p_hover_w", "eta", "cruise_mps", "max_mps", "calib"]
    for (var i = 0; i < positive.length; ++i)
        if (!finiteNumber(v[positive[i]]) || v[positive[i]] <= 0) return "載具數值無效：" + positive[i]
    if (v.max_mps < 4 || v.usable_frac > 1 || v.eta > 1 || !finiteNumber(v.cda_m2) || v.cda_m2 < 0 ||
        !finiteNumber(v.reserve_pct) || v.reserve_pct < 0 || v.reserve_pct > 100) return "載具限制無效"
    if (m.speed_mps !== undefined && (!finiteNumber(m.speed_mps) || m.speed_mps <= 0)) return "任務速度無效"
    if (m.cruise_alt_m !== undefined && (!finiteNumber(m.cruise_alt_m) || m.cruise_alt_m < 0)) return "巡航高度無效"
    var seenIds = [String(m.home.id || "H")], positions = []
    for (i = 0; i < m.targets.length; ++i) {
        var t = m.targets[i]
        if (!coordinate(t) || typeof t.id !== "string" || !t.id ||
            (t.alt !== undefined && (!finiteNumber(t.alt) || t.alt < 0))) return "航點欄位無效"
        var xyz = [t.lat, t.lon, t.alt === undefined ? (m.cruise_alt_m || 50) : t.alt].join(",")
        if (seenIds.indexOf(t.id) >= 0 || positions.indexOf(xyz) >= 0) return "重複航點 ID 或位置，請先釐清目標"
        seenIds.push(t.id); positions.push(xyz)
    }
    if (m.no_fly !== undefined && !Array.isArray(m.no_fly)) return "禁航區格式無效"
    for (i = 0; i < (m.no_fly || []).length; ++i) {
        var z = m.no_fly[i]
        if (!coordinate(z) || !finiteNumber(z.radius_m) || z.radius_m <= 0) return "禁航區數值無效"
    }
    return ""
}
function boundaryHold(kind, why) {
    return { kind: kind, candidates: [], rule_choice: "", pick: {
        decision: "HOLD", choice_id: "", source: "rule", reason_zh: why, evidence_ids: ["E1"]
    }, evidence: [{ id: "E1", text: why }], task_zh: "輸入待釐清，未產生可執行建議" }
}
function stateError(m, s) {
    if (!s || !coordinate(s) || !finiteNumber(s.battery_pct) || s.battery_pct < 0 || s.battery_pct > 100 ||
        (s.alt !== undefined && (!finiteNumber(s.alt) || s.alt < 0)) ||
        (s.observed_ratio !== undefined && (!finiteNumber(s.observed_ratio) || s.observed_ratio <= 0)) ||
        !Array.isArray(s.remaining) || !Array.isArray(s.completed)) return "重規劃遙測或目標清單無效"
    var ids = m.targets.map(function (t) { return t.id }), seen = []
    var all = s.remaining.concat(s.completed)
    for (var i = 0; i < all.length; ++i) {
        if (ids.indexOf(all[i]) < 0 || seen.indexOf(all[i]) >= 0) return "剩餘／已完成航點重複或不存在"
        seen.push(all[i])
    }
    return ""
}

function planMission(mission, v, w) {
    var invalid = inputError(mission, v, w, false)
    if (invalid) return boundaryHold("plan", invalid)
    var alt = mission.cruise_alt_m || 50, h = home(mission), tg = targets(mission)
    tg.forEach(function (t) { if (t.alt === undefined) t.alt = alt })
    var v0 = mission.speed_mps || v.cruise_mps, end = home(mission), c = []
    c.push(evaluate("C1", "照輸入順序", "使用者給的順序", mission, v, w, [h].concat(tg, [end]), v0, 100))
    var sd = orderTargets(h, tg, end, costFn(v, w, v0, "dist"))
    c.push(evaluate("C2", "最短距離", "最近鄰居＋2-opt（距離）", mission, v, w, [h].concat(sd, [end]), v0, 100))
    var se = orderTargets(h, tg, end, costFn(v, w, v0, "energy"))
    c.push(evaluate("C3", "最省電順序", "最近鄰居＋2-opt（含風的能耗）", mission, v, w, [h].concat(se, [end]), v0, 100))
    var bs = bestSpeed(v, w, w.from_deg % 360).speed_mps
    if (Math.abs(bs - v0) >= 0.5)
        c.push(evaluate("C4", "最省電順序＋改速 " + bs + " m/s", "能耗最低地速", mission, v, w, [h].concat(se, [end]), bs, 100))
    var tm = tg.filter(function (t) { return (t.priority || 1) === 1 })
    if (tm.length < tg.length) {
        var sm = orderTargets(h, tm, end, costFn(v, w, v0, "energy"))
        c.push(evaluate("C5", "只做必要目標", "刪除選配目標後重排", mission, v, w, [h].concat(sm, [end]), v0, 100))
    }
    if (!c.some(function (x) { return x.feasible && x.order.length === tg.length })) {
        var split = splitSorties(mission, v, w, [tg, sd, se], [v0, bs])
        if (split) c.push(split)
    }
    var rc = ruleChoice(c)
    return { kind: "plan", mission_version: missionVersion(mission, v, w, null), candidates: c, rule_choice: rc, pick: rulePick(rc), evidence: evidenceFor(c, v, w),
             task_zh: "出發前任務規劃：選一條航線。必要目標都要做到，落地電量要高於保留值。",
             vehicle: v, wind: w }
}

function replan(mission, v0in, w, state, event) {
    var invalid = inputError(mission, v0in, w, true)
    if (invalid) return boundaryHold("replan", invalid)
    invalid = stateError(mission, state)
    if (invalid || !event || typeof event !== "object") return boundaryHold("replan", invalid || "事件格式無效")
    if (event.type === "add_target" && !event.target) return boundaryHold("replan", "新增目標格式無效")
    var note = event.text_zh || "", ratio = state.observed_ratio !== undefined ? state.observed_ratio : v0in.calib
    var context = replanContext(mission, v0in, w, state, event)
    var m = context.mission, v = context.vehicle
    w = context.wind; state = context.state
    invalid = inputError(m, v, w, true) || stateError(m, state)
    if (invalid) return boundaryHold("replan", invalid)
    m.completed = state.completed
    var cur = { id: "現在位置", lat: state.lat, lon: state.lon, alt: state.alt !== undefined ? state.alt : (m.cruise_alt_m || 50), kind: "current" }
    var end = home(m)
    var rem = state.remaining.map(function (id) { return targets(m).filter(function (t) { return t.id === id })[0] }).filter(Boolean)
    rem.forEach(function (t) { if (t.alt === undefined) t.alt = m.cruise_alt_m || 50 })
    var s0 = m.speed_mps || v.cruise_mps, pct = state.battery_pct, c = []
    var local = evaluate("L1", "LOCAL 局部修補", "保留剩餘順序，只繞禁航區", m, v, w, [cur].concat(rem, [end]), s0, pct)
    c.push(local)
    if (!local.feasible) {
        var trimmed = rem.slice(), lc = null
        while (trimmed.length && trimmed.some(function (t) { return (t.priority || 1) === 2 })) {
            var idx = -1
            trimmed.forEach(function (t, i) { if ((t.priority || 1) === 2) idx = i })
            trimmed.splice(idx, 1)
            lc = evaluate("L2", "LOCAL 刪選配目標", "保留順序，刪掉尾端選配目標", m, v, w, [cur].concat(trimmed, [end]), s0, pct)
            if (lc.feasible) break
        }
        if (lc) c.push(lc)
        var mustOnly = rem.filter(function (t) { return (t.priority || 1) === 1 })
        var ids = function (a) { return a.map(function (t) { return t.id }).join(",") }
        if (mustOnly.length && mustOnly.length < rem.length && ids(mustOnly) !== ids(trimmed))
            c.push(evaluate("L3", "LOCAL 只留必要目標", "保留順序，刪掉所有選配目標", m, v, w, [cur].concat(mustOnly, [end]), s0, pct))
    }
    var sf = orderTargets(cur, rem, end, costFn(v, w, s0, "energy"))
    c.push(evaluate("F1", "FULL 全部重排", "剩餘目標以能耗重新排序", m, v, w, [cur].concat(sf, [end]), s0, pct))
    var bs = bestSpeed(v, w, w.from_deg % 360).speed_mps
    if (Math.abs(bs - s0) >= 0.5)
        c.push(evaluate("F2", "FULL 重排＋改速 " + bs + " m/s", "重排並改用最省電速度", m, v, w, [cur].concat(sf, [end]), bs, pct))
    if (!c.some(function (x) { return x.feasible }) && rem.length > 1) {
        var best = null
        ;[["LOCAL", rem], ["FULL", sf]].forEach(function (p) {
            for (var k = p[1].length - 1; k > 0; k--) {
                var pc = evaluate("P1", p[0] + " 做 " + k + " 個後返航", "依 " + p[0] + " 順序完成前 " + k + " 個再回家", m, v, w,
                                  [cur].concat(p[1].slice(0, k), [end]), s0, pct)
                pc.feasible = pc.end_pct >= v.reserve_pct && pc.violations.length === 0
                pc.partial = true
                if (pc.feasible) {
                    if (!best || pc.order.length > best.order.length || (pc.order.length === best.order.length && pc.energy_wh < best.energy_wh)) best = pc
                    break
                }
            }
        })
        if (best) c.push(best)
    }
    var rtl = evaluate("R1", "立即返航", "放棄剩餘目標直接回家", m, v, w, [cur, end], s0, pct)
    rtl.feasible = rtl.end_pct >= v.reserve_pct && rtl.violations.length === 0
    c.push(rtl)
    var rc = ruleChoice(c.filter(function (x) { return x.id !== "R1" })) || (rtl.feasible ? "R1" : "")
    var ev = evidenceFor(c, v, w, ["觸發事件：" + note, "目前電量 " + pct + "%", "起飛後實際耗電是預估的 " + Math.round(ratio * 100) + "%，剩餘航線已用此比例修正"])
    return { kind: "replan", mission_version: missionVersion(m, v, w, state), event: event, state: state, candidates: c, rule_choice: rc, pick: rulePick(rc), evidence: ev,
             task_zh: "飛行中重規劃：事件發生後選一條剩餘航線。必要目標盡量完成，但落地電量必須高於保留值；返航也必須可行，全部不可行則 HOLD。",
             vehicle: v, wind: w }
}

// ---------------- 模型（H-a）：提示與驗證；HTTP 由 QML 端呼叫 ----------------

var PICK_SYSTEM = "你是無人機地面站的任務規劃助理。只能從給定候選中選一個 id，或在資訊不足、全部有風險時回 HOLD。只輸出 JSON：" +
                  "{\"decision\":\"SELECT|HOLD\",\"choice_id\":\"<候選id或空字串>\",\"reason_zh\":\"一句繁體中文理由\",\"evidence_ids\":[\"證據id\"]}"

function pickPrompt(result) {
    return { system: PICK_SYSTEM,
             user: JSON.stringify({ task: result.task_zh, candidates: result.candidates.map(brief), evidence: result.evidence }) }
}

function extractJson(text) {
    text = String(text || "").trim()
    var s = text.indexOf("{"), e = text.lastIndexOf("}")
    if (s < 0 || e <= s) return null
    try { return JSON.parse(text.slice(s, e + 1)) } catch (err) { return null }
}

// 模型回覆 → pick；不合法就退回規則選擇（附原因）
function validatePick(result, text) {
    var rc = result.rule_choice, d = extractJson(text)
    var fb = result.pick && result.pick.decision === "HOLD" ? clone(result.pick) : rulePick(rc)
    if (!d) { fb.reason_zh += "（模型回覆不是 JSON，已退回規則）"; return fb }
    var ids = result.candidates.map(function (c) { return c.id }), ev = result.evidence.map(function (e) { return e.id })
    var cited = (Array.isArray(d.evidence_ids) ? d.evidence_ids : []).filter(function (x) { return ev.indexOf(x) >= 0 })
    var dec = String(d.decision || "").toUpperCase()
    if (dec === "HOLD") return { choice_id: "", source: "llm", decision: "HOLD", reason_zh: String(d.reason_zh || ""), evidence_ids: cited }
    if (dec !== "SELECT" || ids.indexOf(d.choice_id) < 0) { fb.reason_zh += "（模型選了不存在的候選，已退回規則）"; return fb }
    var selected = result.candidates.filter(function (c) { return c.id === d.choice_id })[0]
    if (!selected.feasible) { fb.reason_zh += "（模型選了不可行候選，已退回規則）"; return fb }
    if (selected.requires_battery_swap) { fb.reason_zh += "（模型選了需換電的分趟候選，已退回規則）"; return fb }
    return { choice_id: d.choice_id, source: "llm", decision: "SELECT", reason_zh: String(d.reason_zh || ""), evidence_ids: cited }
}

// ---------------- 模擬飛行（demo 用；實機改吃 QGC 遙測） ----------------

function mulberry32(seed) {
    return function () {
        seed |= 0; seed = seed + 0x6D2B79F5 | 0
        var t = Math.imul(seed ^ seed >>> 15, 1 | seed)
        t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t
        return ((t ^ t >>> 14) >>> 0) / 4294967296
    }
}

function MissionRun(v, w, trueCalib, windEvents, seed, dt) {
    this.v = v; this.wind = w; this.trueCalib = trueCalib === undefined ? 1.15 : trueCalib
    this.windEvents = (windEvents || []).slice().sort(function (a, b) { return a.t_s - b.t_s })
    this.rand = mulberry32(seed || 7); this.dt = dt || 2.0
    this.t = 0; this.pct = 100; this.usedWh = 0; this.log = []; this.legs = []; this.completed = []; this.pos = null
}

MissionRun.prototype.u = function (lo, hi) { return lo + (hi - lo) * this.rand() }

MissionRun.prototype.windNow = function () {
    var w = this.wind
    for (var i = 0; i < this.windEvents.length; i++) if (this.t >= this.windEvents[i].t_s) w = wind(this.windEvents[i].speed_mps, this.windEvents[i].from_deg)
    return w
}

// onTick(rec, nextIdx) 回 true 就停（例如預測告警成立）
MissionRun.prototype.fly = function (plan, stopAtS, onTick) {
    var cap = this.v.battery_wh * this.v.usable_frac, path = plan.path, speed = plan.speed_mps, calib = plan.calib || 1
    var pred = {}
    plan.legs.forEach(function (l) { pred[l.from + ">" + l.to] = l })
    for (var i = 0; i < path.length - 1; i++) {
        var a = path[i], b = path[i + 1]
        if (!this.pos) this.pos = [a.lat, a.lon, a.alt || 0]
        var st = this.pos.slice()
        var dist = haversineM(st, [b.lat, b.lon]), brg = bearingRad(st, [b.lat, b.lon])
        var climb = (b.alt || 0) - st[2]
        var hover = b.kind === "target" ? 5.0 : 0
        var tLeg = dist / speed + Math.abs(climb) / (climb > 0 ? 3.0 : 2.0) + hover
        var used = 0, heads = [], n = Math.max(1, Math.ceil(tLeg / this.dt))
        for (var k = 1; k <= n; k++) {
            var wn = this.windNow(), gust = 1 + this.u(-0.25, 0.25), wv = windVector(wn)
            var we = wv[0] * gust, wnn = wv[1] * gust, frac = k / n, hovering = hover && k * this.dt > tLeg - hover
            var vAir = hovering ? Math.hypot(we, wnn) : Math.hypot(speed * Math.sin(brg) - we, speed * Math.cos(brg) - wnn)
            heads.push(-(we * Math.sin(brg) + wnn * Math.cos(brg)))
            var p = powerW(this.v, vAir)
            if (climb > 0) p += this.v.mass_kg * G * 3.0 / this.v.eta * Math.min(1, climb / 3.0 / Math.max(tLeg, 1))
            p *= this.trueCalib * (1 + this.u(-0.03, 0.03))
            var wh = p * this.dt / 3600
            used += wh; this.usedWh += wh; this.pct -= wh / cap * 100; this.t += this.dt
            this.pos = [st[0] + (b.lat - st[0]) * frac, st[1] + (b.lon - st[1]) * frac, st[2] + climb * frac]
            var rec = { t_s: rnd(this.t, 1), lat: this.pos[0], lon: this.pos[1], alt: rnd(this.pos[2], 1), battery_pct: rnd(this.pct, 2),
                        power_w: rnd(p, 1), wind_mps: wn.speed_mps, wind_from: wn.from_deg, leg: a.id + "→" + b.id,
                        vel_e: hovering ? 0 : speed * Math.sin(brg), vel_n: hovering ? 0 : speed * Math.cos(brg), used_wh: rnd(this.usedWh, 3) }
            this.log.push(rec)
            var stop = onTick ? !!onTick(rec, i) : false
            if ((stop || (stopAtS !== undefined && stopAtS !== null && this.t >= stopAtS)) && k < n) {
                this.legs.push(this.legRec(a, b, pred, used, heads, calib, frac))
                return this.state(plan, i, true)
            }
        }
        this.pos = [b.lat, b.lon, b.alt || 0]
        this.legs.push(this.legRec(a, b, pred, used, heads, calib, 1))
        if (b.kind === "target") this.completed.push(b.id)
        if (stopAtS !== undefined && stopAtS !== null && this.t >= stopAtS && i < path.length - 2) return this.state(plan, i + 1, false)
    }
    return this.state(plan, path.length - 1, false, true)
}

MissionRun.prototype.legRec = function (a, b, pred, used, heads, calib, partial) {
    var p = pred[a.id + ">" + b.id]
    var hw = heads.length ? heads.reduce(function (s, x) { return s + x }, 0) / heads.length : 0
    return { from: a.id, to: b.id, actual_wh: rnd(used, 2), pred_wh: p ? rnd(p.energy_wh * partial / calib, 2) : null,
             headwind_mps: rnd(hw, 2), partial: partial < 1, end_t_s: rnd(this.t, 1) }
}

MissionRun.prototype.state = function (plan, idx, partial, done) {
    var rem = plan.path.slice(idx + 1).filter(function (p) { return p.kind === "target" }).map(function (p) { return p.id })
    if (partial) { var nx = plan.path[idx + 1]; if (nx.kind === "target" && rem.indexOf(nx.id) < 0) rem.unshift(nx.id) }
    var pl = this.legs.filter(function (l) { return l.pred_wh })
    var pr = pl.reduce(function (s, l) { return s + l.pred_wh }, 0), ac = pl.reduce(function (s, l) { return s + l.actual_wh }, 0)
    return { observed_ratio: pr ? rnd(ac / pr, 3) : 1.0, t_s: rnd(this.t, 1), lat: this.pos[0], lon: this.pos[1], alt: this.pos[2],
             battery_pct: rnd(this.pct, 1), completed: this.completed.slice(), remaining: rem, done: !!done }
}

// 預測告警（最小版）：用重規劃的 L1（保留原順序）候選推估照原計畫飛完的落地電量
function predictiveAlert(v, state, rp) {
    var keep = rp.candidates.filter(function (c) { return c.id === "L1" })[0]
    if (!keep || keep.end_pct >= v.reserve_pct) return null
    return { t_s: state.t_s, level: keep.end_pct > 0 ? "warn" : "crit", title: "電量不足以飛完航線", projected_end_pct: keep.end_pct,
             text_zh: "照原計畫飛完，預估落地電量只剩 " + keep.end_pct.toFixed(1) + "%（門檻 " + v.reserve_pct + "%）；起飛後實際耗電是預估的 " +
                      Math.round((state.observed_ratio || 1) * 100) + "%" }
}

// ---------------- 智慧任務報告 ----------------

// T3 report helpers. CSV/Plan file I/O stays in the Python offline adapter;
// a serialized RunLike (including data_quality) uses the same report gates here.
function sha256Text(text) {
    var encoded=encodeURIComponent(text),bytes=[],i,j
    for(i=0;i<encoded.length;i++) {
        if(encoded[i]==="%") {bytes.push(parseInt(encoded.slice(i+1,i+3),16));i+=2}
        else bytes.push(encoded.charCodeAt(i))
    }
    var bits=bytes.length*8
    bytes.push(128);while(bytes.length%64!==56)bytes.push(0)
    for(i=7;i>=0;i--)bytes.push(Math.floor(bits/Math.pow(256,i))%256)
    var h=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]
    var k=[0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
        0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
        0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
        0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
        0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
        0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
        0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
        0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2]
    function rotr(x,n){return (x>>>n)|(x<<(32-n))}
    for(i=0;i<bytes.length;i+=64) {
        var w=[]
        for(j=0;j<16;j++)w[j]=(bytes[i+4*j]<<24)|(bytes[i+4*j+1]<<16)|(bytes[i+4*j+2]<<8)|bytes[i+4*j+3]
        for(j=16;j<64;j++) {
            var x=w[j-15],y=w[j-2],s0=rotr(x,7)^rotr(x,18)^(x>>>3),s1=rotr(y,17)^rotr(y,19)^(y>>>10)
            w[j]=(w[j-16]+s0+w[j-7]+s1)|0
        }
        var a=h[0],b=h[1],c=h[2],d=h[3],e=h[4],f=h[5],g=h[6],hh=h[7]
        for(j=0;j<64;j++) {
            var t1=(hh+(rotr(e,6)^rotr(e,11)^rotr(e,25))+((e&f)^((~e)&g))+k[j]+w[j])|0
            var t2=((rotr(a,2)^rotr(a,13)^rotr(a,22))+((a&b)^(a&c)^(b&c)))|0
            hh=g;g=f;f=e;e=(d+t1)|0;d=c;c=b;b=a;a=(t1+t2)|0
        }
        var v=[a,b,c,d,e,f,g,hh];for(j=0;j<8;j++)h[j]=(h[j]+v[j])|0
    }
    return h.map(function(n){return ("00000000"+(n>>>0).toString(16)).slice(-8)}).join("")
}

function qualityFor(run) {
    if (run.data_quality && Object.keys(run.data_quality).length) return clone(run.data_quality)
    var gaps = [], log = run.log || []
    for (var i = 1; i < log.length; i++) if (log[i].t_s > log[i-1].t_s) gaps.push(log[i].t_s-log[i-1].t_s)
    gaps.sort(function (a,b) { return a-b })
    var missing = !log.length || log.some(function (r) { return r.wind_mps == null || r.wind_from == null })
    var estimated = !!run.energy_estimated, mid = Math.floor(gaps.length/2)
    return { source: "simulation_or_supplied_run", missing_wind: missing, missing_current: estimated,
        soc_estimated: estimated, calibration_eligible: !estimated && !missing, sample_count: log.length, trimmed_samples: 0,
        sample_interval_s: gaps.length ? {min:gaps[0],median:gaps.length%2 ? gaps[mid] : (gaps[mid-1]+gaps[mid])/2,max:gaps[gaps.length-1]} : null }
}

function numberTokens(text) {
    var s = String(text)
    if (s.normalize) s = s.normalize("NFKC")
    return s.match(/[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?/g) || []
}
function unsupportedNumbers(texts, facts) {
    var values = [], bad = []
    function visit(x) {
        if (typeof x === "number" && isFinite(x)) values.push(x)
        else if (typeof x === "string") numberTokens(x).forEach(function (s) { if (isFinite(Number(s))) values.push(Number(s)) })
        else if (Array.isArray(x)) x.forEach(visit)
        else if (x && typeof x === "object") Object.keys(x).forEach(function (k) { visit(x[k]) })
    }
    facts.forEach(function (f) { visit(f.text); visit(f.value) })
    texts.forEach(function (text) { numberTokens(text).forEach(function (token) {
        var parts = token.toLowerCase().split("e"), decimals = parts[0].split(".")[1] || ""
        var tolerance = 0.5 * Math.pow(10, Number(parts[1] || 0)-decimals.length), value = Number(token)
        if (!isFinite(tolerance)) tolerance = 0
        if ((!isFinite(value) || !values.some(function (n) { return Math.abs(n-value) <= tolerance+1e-10 })) && bad.indexOf(token)<0) bad.push(token)
    }) })
    return bad
}

function reportEvents(run, mission, replans, alerts) {
    var events = [], airborne = false, seen = {}, ids = mission.targets.map(function (t) { return t.id })
    run.log.forEach(function (r,i) {
        if (r.alt == null) return
        if (!airborne && r.alt>1) { events.push({kind:i===0 ? "start_in_air" : "takeoff",t_s:r.t_s,basis:"altitude_threshold_inference"}); airborne=true }
        else if (airborne && Math.abs(r.alt)<=1) {
            var speed = r.ground_speed_mps == null ? Math.hypot(r.vel_e || 0,r.vel_n || 0) : r.ground_speed_mps
            if (speed<=0.5 && !r.armed) { events.push({kind:"landing",t_s:r.t_s,basis:"stationary_ground_inference"}); airborne=false }
        }
    })
    run.legs.forEach(function (l) { if (!l.partial && ids.indexOf(l.to)>=0 && !seen[l.to] && l.end_t_s!=null) {
        seen[l.to]=true; events.push({kind:"waypoint",target_id:l.to,t_s:l.end_t_s,basis:"sample_arrival_or_supplied_leg"})
    } })
    ;(replans || []).forEach(function (r) { if (r.state && r.state.t_s!=null) events.push({kind:"replan",t_s:r.state.t_s,choice_id:r.final_choice || r.pick.choice_id || ""}) })
    ;(alerts || []).forEach(function (a) { if (a.t_s!=null) events.push({kind:"alert",t_s:a.t_s,text_zh:a.text_zh || ""}) })
    return events.sort(function (a,b) { return a.t_s-b.t_s })
}

function reserveAlertLeads(run, alerts) {
    var result=[]
    ;(alerts || []).forEach(function (a,i) {
        if (a.t_s==null) return
        var breach=a.predicted_reserve_breach_t_s, basis="caller_reserve_prediction"
        if (breach==null) {
            var samples=run.log.filter(function (r) { return r.t_s<=a.t_s })
            if (samples.length<2) return
            var p=samples[samples.length-2],q=samples[samples.length-1],dt=q.t_s-p.t_s
            if (dt<=0 || a.t_s-q.t_s>dt) return
            var slope=(q.battery_pct-p.battery_pct)/dt
            if (slope>=0) return
            breach=q.t_s+(run.v.reserve_pct-q.battery_pct)/slope
            basis="linear_soc_at_alert_not_future_observation"
        }
        if (typeof breach==="number" && isFinite(breach)) result.push({alert_index:i,alert_t_s:a.t_s,predicted_reserve_breach_t_s:breach,lead_s:Math.max(0,breach-a.t_s),basis:basis})
    })
    return result
}

function buildFacts(run, mission, plan, replans, alerts) {
    var v = run.v, facts = []
    var quality = qualityFor(run), windKnown = !quality.missing_wind, eligible = quality.calibration_eligible
    var estimated = !!run.energy_estimated
    function add(key, text, value) { facts.push({ id: "F" + (facts.length + 1), key: key, text: text, value: value }) }
    var legs = run.legs.filter(function (l) { return l.pred_wh })
    var act = legs.reduce(function (s, l) { return s + l.actual_wh }, 0), pred = legs.reduce(function (s, l) { return s + l.pred_wh }, 0)
    var ratio = pred ? act / pred : 1, dist = 0
    for (var i = 1; i < run.log.length; i++) dist += haversineM([run.log[i - 1].lat, run.log[i - 1].lon], [run.log[i].lat, run.log[i].lon])
    var must = mission.targets.filter(function (t) { return (t.priority || 1) === 1 }).map(function (t) { return t.id })
    var all = mission.targets.map(function (t) { return t.id }), done = run.completed
    add("completion", "完成目標 " + done.length + "/" + all.length + "（必要目標 " + must.filter(function (m) { return done.indexOf(m) >= 0 }).length + "/" + must.length + "）：" + (done.join("、") || "無"),
        { done: done, all: all, must: must })
    add("duration", "飛行 " + (run.t / 60).toFixed(1) + " 分鐘、" + (dist / 1000).toFixed(2) + " 公里", { t_s: run.t, dist_m: dist })
    add("energy_ratio", (estimated ? "以電量差估算耗電 " : "實際耗電 ") + act.toFixed(1) + " Wh，物理模型預估 " + pred.toFixed(1) + " Wh，能耗是預估的 " + Math.round(ratio * 100) + "%",
        { actual_wh: act, pred_wh: pred, ratio: ratio, calibration_eligible: eligible })
    add("end_battery", "落地電量 " + run.pct.toFixed(1) + "%（保留門檻 " + v.reserve_pct + "%，起飛前預估落地 " + plan.end_pct + "%）",
        { end_pct: run.pct, reserve: v.reserve_pct, planned_end: plan.end_pct })
    if (legs.length) {
        var worst = legs.reduce(function (a, l) { return l.actual_wh / Math.max(l.pred_wh, 1e-6) > a.actual_wh / Math.max(a.pred_wh, 1e-6) ? l : a })
        var worstValue=clone(worst); if (!windKnown) delete worstValue.headwind_mps
        add("worst_leg", "超耗最多的航段 " + worst.from + "→" + worst.to + "：實際 " + worst.actual_wh.toFixed(2) + " Wh／預估 " + worst.pred_wh.toFixed(2) + " Wh" + (windKnown ? "，平均逆風 " + worst.headwind_mps + " m/s" : "；風況未知"), worstValue)
    }
    var head = legs.filter(function (l) { return windKnown && l.headwind_mps != null && l.headwind_mps > 2 })
    if (head.length) {
        var hr = head.reduce(function (s, l) { return s + l.actual_wh }, 0) / Math.max(head.reduce(function (s, l) { return s + l.pred_wh }, 0), 1e-6)
        add("headwind", "逆風超過 2 m/s 的航段共 " + head.length + " 段，耗電是預估的 " + Math.round(hr * 100) + "%", { n: head.length, ratio: hr })
    }
    var seen = {}, winds = []
    if (windKnown) run.log.forEach(function (r) { var k = r.wind_mps + "|" + r.wind_from; if (!seen[k]) { seen[k] = 1; winds.push([r.wind_mps, r.wind_from]) } })
    winds.sort(function (a, b) { return a[0] - b[0] || a[1] - b[1] })
    if (winds.length > 1) add("wind_change", "飛行中風況改變：" + winds.map(function (x) { return x[0] + " m/s（從 " + Math.round(x[1]) + "°）" }).join("→"), winds)
    ;(replans || []).forEach(function (r) {
        add("replan", "第 " + (r.state.t_s / 60).toFixed(1) + " 分鐘因「" + (r.event.text_zh || "事件") + "」重規劃，採用 " + (r.final_choice || r.pick.choice_id || "HOLD") +
            "（" + (r.pick.source === "llm" ? "模型選擇" : "規則選擇") + "）", { choice: r.final_choice || r.pick.choice_id, source: r.pick.source })
    })
    ;(alerts || []).forEach(function (a) { add("alert", "第 " + (a.t_s / 60).toFixed(1) + " 分鐘告警：" + a.text_zh, a) })
    var nc = eligible ? rnd(ratio, 3) : v.calib
    add("calib", eligible ? "耗電修正係數建議由 " + v.calib.toFixed(2) + " 更新為 " + nc.toFixed(2) : "缺電流或風況資料，能耗不足以校正；維持耗電修正係數", { old: v.calib, "new": nc, eligible: eligible })
    if (windKnown) {
        var wl = winds.length ? wind(winds[winds.length - 1][0], winds[winds.length - 1][1]) : wind(0, 0)
        var bs = bestSpeed(v, wl, wl.from_deg)
        add("best_speed", "以本次最大風況（" + wl.speed_mps + " m/s）估算，逆風最省電地速約 " + bs.speed_mps + " m/s（" + bs.wh_per_km + " Wh/km），本次巡航 " + plan.speed_mps + " m/s",
            { speed_mps: bs.speed_mps, wh_per_km: bs.wh_per_km, cruise: plan.speed_mps })
    }
    if (run.provenance) add("telemetry_source", "CSV 遙測來源：" + run.provenance.energy_source + "；已用 PX4 SITL 匯出核對欄位，尚未用實機核對", run.provenance)
    var missing=[]; if (quality.missing_wind) missing.push("風速／風向"); if (quality.missing_current) missing.push("電流")
    add("data_quality", "資料品質：" + (missing.length ? "缺少"+missing.join("、") : "所需風況與能耗資料可用") + (estimated ? "；耗電採 SOC 差值估算" : "") + "；取樣間隔（秒）"+JSON.stringify(quality.sample_interval_s), quality)
    var timeline=reportEvents(run,mission,replans,alerts)
    add("timeline", timelineText(timeline),timeline)
    var flightEvents=timeline.filter(function (e) {return ["takeoff","start_in_air","landing"].indexOf(e.kind)>=0})
    var landed=!!flightEvents.length && flightEvents[flightEvents.length-1].kind==="landing"
    add("energy_margin", (landed ? "落地" : "紀錄終點")+"能量餘裕 M = "+(run.pct-v.reserve_pct).toFixed(1)+"%", {margin_pct:run.pct-v.reserve_pct,landing_inferred:landed,basis:"terminal_soc_minus_reserve"})
    if (alerts && alerts.length) add("alert_lead_time", "告警至預估跌破保留門檻的提前秒數；無可靠估計時不填數字",reserveAlertLeads(run,alerts))
    return facts
}

function ruleSuggestions(facts) {
    var f = {}, out = []
    facts.forEach(function (x) { if (x.key !== "replan" && x.key !== "alert") f[x.key] = x })
    function sug(text, keys, level) {
        out.push({ text_zh: text, evidence_ids: keys.filter(function (k) { return f[k] }).map(function (k) { return f[k].id }), level: level || "info" })
    }
    var r = f.energy_ratio.value.calibration_eligible ? f.energy_ratio.value.ratio : 1
    if (r > 1.08) sug("實際耗電比預估多 " + Math.round((r - 1) * 100) + "%，下次規劃請套用新的修正係數 " + f.calib.value["new"].toFixed(2) + "（系統可自動帶入），並檢查電池健康度與循環次數。", ["energy_ratio", "calib"], "warn")
    else if (r < 0.92) sug("實際耗電比預估少 " + Math.round((1 - r) * 100) + "%，預估偏保守，可考慮套用修正係數 " + f.calib.value["new"].toFixed(2) + " 以排入更多目標。", ["energy_ratio", "calib"])
    var eb = f.end_battery.value
    if (eb.end_pct < eb.reserve) sug("落地電量 " + eb.end_pct.toFixed(1) + "% 低於保留門檻 " + eb.reserve + "%，同樣的任務下次應分兩趟或減少選配目標。", ["end_battery"], "crit")
    else if (eb.end_pct < eb.reserve + 8) sug("落地電量只比保留門檻多 " + (eb.end_pct - eb.reserve).toFixed(1) + "%，餘裕偏小，建議出發前預留更多電量或提高保留門檻。", ["end_battery"], "warn")
    if (f.energy_ratio.value.calibration_eligible && f.headwind && f.headwind.value.ratio > 1.1) sug("逆風航段是超耗主因，建議把逆風段排在電量充足的前段，回程順風；規劃時選用「最省電順序」候選。", ["headwind", "worst_leg"], "warn")
    if (f.wind_change && f.best_speed && Math.abs(f.best_speed.value.speed_mps - f.best_speed.value.cruise) >= 1)
        sug("風大時把逆風段速度調到約 " + f.best_speed.value.speed_mps + " m/s 可降低單位距離耗電。", ["best_speed", "wind_change"])
    var comp = f.completion.value
    var missing = comp.all.filter(function (t) { return comp.done.indexOf(t) < 0 })
    var missMust = comp.must.filter(function (t) { return comp.done.indexOf(t) < 0 })
    var doneOpt = comp.done.filter(function (t) { return comp.must.indexOf(t) < 0 })
    if (missMust.length && doneOpt.length) sug("本次先做了選配目標（" + doneOpt.join("、") + "），卻漏掉必要目標（" + missMust.join("、") + "）；下次請選「必要目標優先」順序。", ["completion"], "warn")
    if (missing.length) sug("未完成目標：" + missing.join("、") + "，建議排入下一趟任務（可從本報告一鍵帶入規劃）。", ["completion"])
    if (!out.length) sug(f.data_quality.value.missing_wind ? "缺少風速／風向，未產生逆風建議；請補充資料後再評估校正。" :
        (f.data_quality.value.missing_current ? "本次能耗為電量差估算，尚不足以判定模型誤差；請補充電流紀錄再評估校正。" : "本次任務耗電與預估相符、電量餘裕充足，維持目前設定即可。"), ["energy_ratio", "end_battery"])
    return out
}

function makeReport(run, mission, plan, replans, alerts, versions) {
    var facts = buildFacts(run, mission, plan, replans, alerts)
    var by = function (k) { return facts.filter(function (x) { return x.key === k })[0] }
    var out = { facts: facts, suggestions: ruleSuggestions(facts), source: "rule",
             summary_zh: by("completion").text + "。" + by("energy_ratio").text + "。" + by("end_battery").text + "。" + by("data_quality").text + "。",
             next_calib: by("calib").value["new"], data_quality: by("data_quality").value,
             timeline: by("timeline").value, energy_margin: by("energy_margin").value,
             versions: {git_short_hash:(versions || {}).git_short_hash || null,prompt_hash:null,model:null} }
    if (alerts && alerts.length) out.alert_lead_time=by("alert_lead_time").value
    if (run.provenance) { out.data_provenance=run.provenance; out.calibration_eligible=out.data_quality.calibration_eligible }
    return out
}

var REPORT_SYSTEM = "你是無人機任務報告助理。只能根據給定事實（facts）寫，不可新增數字。輸出 JSON：{\"summary_zh\":\"3 句內繁體中文摘要\"," +
                    "\"suggestions\":[{\"text_zh\":\"建議\",\"evidence_ids\":[\"F1\"]}]}。建議依重要性排序，最多 5 條，每條都要引用 facts 的 id。可改寫給定的規則建議，但不可捏造。"

function reportPrompt(rep) {
    var p = { system: REPORT_SYSTEM,
             user: JSON.stringify({ facts: rep.facts.map(function (x) { return { id: x.id, text: x.text } }), rule_suggestions: rep.suggestions }) }
    p.prompt_hash=sha256Text(p.system+"\n---\n"+p.user).slice(0,16)
    return p
}

// 模型改寫的報告：沒引用事實的建議丟掉；全部被丟就保留規則版
function applyReportLlm(rep, text, metadata) {
    // Always rebuild from the rule snapshot, including after a prior accepted rewrite.
    var base=rep.rule_report ? clone(rep.rule_report) : clone(rep)
    var version=base.versions || {git_short_hash:null,prompt_hash:null,model:null}
    version.prompt_hash=(metadata || {}).prompt_hash || reportPrompt(base).prompt_hash
    version.model=(metadata || {}).model || null
    base.versions=version
    var d = extractJson(text)
    if (!d || typeof d.summary_zh !== "string" || !Array.isArray(d.suggestions)) { base.llm_fallback_reason="invalid_report_shape"; return base }
    var texts=[d.summary_zh]
    d.suggestions.forEach(function (s) { if (s && typeof s.text_zh==="string") texts.push(s.text_zh) })
    var bad=unsupportedNumbers(texts,base.facts)
    if (bad.length) { base.llm_fallback_reason="unsupported_numbers:"+bad.join(","); return base }
    if (base.data_quality && base.data_quality.missing_wind && texts.some(function (s) {return /逆風|順風|風況改變|風速增強|headwind|wind_change/i.test(s)})) {
        base.llm_fallback_reason="wind_advice_without_measurements"; return base
    }
    var ids = base.facts.map(function (x) { return x.id }), kept = []
    d.suggestions.slice(0, 5).forEach(function (s) {
        if (!s || typeof s.text_zh !== "string") return
        var ev = (Array.isArray(s.evidence_ids) ? s.evidence_ids : []).filter(function (e) { return ids.indexOf(e) >= 0 })
        if (ev.length) kept.push({ text_zh: s.text_zh, evidence_ids: ev, level: "info" })
    })
    if (!kept.length) return base
    var out = clone(base)
    out.rule_report=base
    out.rule_suggestions = base.suggestions; out.suggestions = kept; out.summary_zh = d.summary_zh; out.source = "llm"
    return out
}

// node 測試用
if (typeof module !== "undefined") module.exports = {
    createTypedFullMissionOrchestrator:createTypedFullMissionOrchestrator,
    estimateForBounds:estimateForBounds, bounds:bounds, transitionEstimate:transitionEstimate, rtlEnergy:rtlEnergy, estimateRouteEnergy:estimateRouteEnergy,
    turnEstimate:turnEstimate, loiterEstimate:loiterEstimate,
    windArcEstimate:windArcEstimate, windLoiterEstimate:windLoiterEstimate,
    windRouteEstimate:windRouteEstimate,
    geographicWindRouteEstimate:geographicWindRouteEstimate,
    typedAlertSpeeds:typedAlertSpeeds,
    evaluateTypedAlertCandidates:evaluateTypedAlertCandidates,
    geographicWindRouteBounds:geographicWindRouteBounds,
    evaluateGeographicAlertCandidates:evaluateGeographicAlertCandidates,
    geographicEnergyAlertSnapshot:geographicEnergyAlertSnapshot,
    createGeographicEnergyAlertPredictor:createGeographicEnergyAlertPredictor,
    createTypedGeographicAlertFeed:createTypedGeographicAlertFeed,
    createTypedMissionSampleFeed:createTypedMissionSampleFeed,
    typedBatteryCapacitySnapshot:typedBatteryCapacitySnapshot,
    createTypedCapacityFeed:createTypedCapacityFeed,
    createTypedMissionOrchestrator:createTypedMissionOrchestrator,
    typedReturnProbeSnapshot:typedReturnProbeSnapshot,
    typedLinkDistanceSnapshot:typedLinkDistanceSnapshot,
    createTypedLinkDistancePredictor:createTypedLinkDistancePredictor,
    typedWindTrendSnapshot:typedWindTrendSnapshot,
    createTypedWindTrendPredictor:createTypedWindTrendPredictor,
    missionVersion:missionVersion,checkApply:checkApply,replanContext:replanContext,
    canonicalVersion:canonicalVersion,constraintDeltas:constraintDeltas,splitSorties:splitSorties,ruleChoice:ruleChoice,timelineText:timelineText,
    loadAirframe:loadAirframe, airframeType:airframeType, speedRange:speedRange, powerW:powerW,
    turnGeometry:turnGeometry, validateAirframeProfile:validateAirframeProfile, propEfficiency:propEfficiency,
    legEstimate:legEstimate,
    haversineM: haversineM, vehicle: vehicle, wind: wind, routeEstimate: routeEstimate, bestSpeed: bestSpeed,
    planMission: planMission, replan: replan, MissionRun: MissionRun, makeReport: makeReport, predictiveAlert: predictiveAlert,
    pickPrompt: pickPrompt, validatePick: validatePick, reportPrompt: reportPrompt, applyReportLlm: applyReportLlm,
    unsupportedNumbers:unsupportedNumbers, reportEvents:reportEvents, reserveAlertLeads:reserveAlertLeads, sha256Text:sha256Text
}

// T3 version contract: finite IEEE754 doubles and UTF-8 hex strings/keys.
function timelineText(events) {
    var labels={takeoff:"起飛（推定）",start_in_air:"紀錄起點已在空中",landing:"降落（推定）",waypoint:"到達航點",alert:"告警",replan:"重規劃"}
    var parts=events.slice(0,5).map(function(e){return (e.t_s.toFixed(1)+" 秒 "+(labels[e.kind]||e.kind)+" "+(e.target_id||e.choice_id||"")).trim()})
    if(events.length>5) parts.push("另 "+(events.length-5)+" 件，詳見結構化時間軸")
    return "事件時間軸（起降為取樣推定，不代表上鎖確認）："+(parts.length?parts.join("；"):"無可推定事件")
}

function utf8Hex(text) {
    var bytes = unescape(encodeURIComponent(text)), out = ""
    for (var i = 0; i < bytes.length; ++i) out += ("0" + bytes.charCodeAt(i).toString(16)).slice(-2)
    return out
}
function canonicalVersion(value) {
    if (value === null) return "z"
    if (value === true) return "t"
    if (value === false) return "f"
    if (typeof value === "number") {
        if (!isFinite(value)) throw new Error("nonfinite mission version input")
        var buffer = new ArrayBuffer(8), view = new DataView(buffer), hex = ""
        view.setFloat64(0, value === 0 ? 0 : value, false)
        for (var i = 0; i < 8; ++i) hex += ("0" + view.getUint8(i).toString(16)).slice(-2)
        return "n" + hex
    }
    if (typeof value === "string") return "s" + utf8Hex(value)
    if (Array.isArray(value)) return "a[" + value.map(canonicalVersion).join(",") + "]"
    if (value && typeof value === "object") {
        var keys = Object.keys(value).sort(function (a,b) { var x=utf8Hex(a),y=utf8Hex(b); return x<y?-1:x>y?1:0 })
        return "o{" + keys.map(function (k) { return canonicalVersion(k) + ":" + canonicalVersion(value[k]) }).join(",") + "}"
    }
    throw new Error("unsupported mission version input")
}
function missionVersion(m, v, w, s) {
    return "t3-v1:" + sha256Text(canonicalVersion({mission:m,vehicle:v,wind:w,state:s === undefined ? null : s}))
}
function checkApply(result, m, v, w, s) {
    try { if (result && result.mission_version === missionVersion(m,v,w,s)) return {ok:true} } catch (e) {}
    return {ok:false,reason_zh:"任務已變更，請重新規劃"}
}
function replanContext(mission, vehicleIn, windIn, stateIn, event) {
    var m=clone(mission),v=clone(vehicleIn),w=clone(windIn),s=clone(stateIn)
    v.calib = rnd(s.observed_ratio !== undefined ? s.observed_ratio : v.calib,3)
    if (event.type === "wind") w=wind(event.speed_mps,event.from_deg)
    else if (event.type === "no_fly") m.no_fly=(m.no_fly||[]).concat([clone(event.zone)])
    else if (event.type === "add_target") {m.targets.push(clone(event.target));s.remaining.push(event.target.id)}
    else if (event.type === "battery") s.battery_pct=event.battery_pct
    m.completed=s.completed
    return {mission:m,vehicle:v,wind:w,state:s}
}
function constraintDeltas(m,v,path,est,missing) {
    var out=[],max=(m.limits||{}).max_altitude_m
    if (max === undefined) max=120
    if (est.margin_pct<0) out.push({violated:"reserve",short_pct:-est.margin_pct})
    path.forEach(function (p) {if ((p.alt||0)>max) out.push({violated:"altitude",point_id:p.id,over_m:p.alt-max})})
    var origin=[m.home.lat,m.home.lon]
    for (var i=0;i<path.length-1;++i) {
        var a=toXY(origin,[path[i].lat,path[i].lon]),b=toXY(origin,[path[i+1].lat,path[i+1].lon]),dx=b[0]-a[0],dy=b[1]-a[1]
        ;(m.no_fly||[]).forEach(function (z) {
            var c=toXY(origin,[z.lat,z.lon]),d=dx*dx+dy*dy
            var t=d?Math.max(0,Math.min(1,((c[0]-a[0])*dx+(c[1]-a[1])*dy)/d)):0
            var short=z.radius_m-Math.hypot(a[0]+t*dx-c[0],a[1]+t*dy-c[1])
            if (short>0) out.push({violated:"no_fly",zone_id:z.id,from:path[i].id,to:path[i+1].id,short_m:short})
        })
    }
    if (missing.length) out.push({violated:"required_targets",missing_count:missing.length,target_ids:missing.slice()})
    return out
}
function splitSorties(m,v,w,sequences,speeds) {
    if (m.targets.length<2) return null
    var best=null,seen={},ids=m.targets.map(function(t){return t.id}).sort().join("\u0000")
    sequences.forEach(function(seq) {
        for (var k=1;k<seq.length;++k) {
            var groups=[seq.slice(0,k),seq.slice(k)],key=JSON.stringify(groups.map(function(g){return g.map(function(t){return t.id})}))
            if (seen[key]) continue
            seen[key]=true
            speeds.filter(function(s,i,a){return a.indexOf(s)===i}).forEach(function(speed) {
                var sorties=groups.map(function(g,i) {
                    var sub=clone(m);sub.targets=g;sub.completed=[]
                    return evaluate("S1-"+(i+1),"分兩趟第 "+(i+1)+" 趟","獨立滿電、返航",sub,v,w,[home(m)].concat(g,[home(m)]),speed,100)
                })
                var order=sorties[0].order.concat(sorties[1].order)
                if (!sorties.every(function(s){return s.feasible}) || order.slice().sort().join("\u0000")!==ids) return
                var energy=rnd(sorties[0].energy_wh+sorties[1].energy_wh,1)
                if (best && energy>=best.energy_wh) return
                var must=m.targets.filter(function(t){return (t.priority||1)===1}).map(function(t){return t.id}),rank=0
                order.forEach(function(t,i){if(must.indexOf(t)>=0)rank+=i})
                best={id:"S1",label:"分兩趟完成全部目標",how:"兩個獨立返航架次，中間更換滿電電池",
                    note:"須分別檢視兩趟；尚無自動跨架次執行器；分割搜尋非窮舉最佳化",order:order,speed_mps:speed,calib:v.calib,
                    dist_km:rnd(sorties[0].dist_km+sorties[1].dist_km,2),time_min:rnd(sorties[0].time_min+sorties[1].time_min,1),
                    energy_wh:energy,end_pct:Math.min(sorties[0].end_pct,sorties[1].end_pct),margin_pct:Math.min(sorties[0].margin_pct,sorties[1].margin_pct),
                    feasible:true,must_rank:rank,violations:[],missing_must:[],constraint_deltas:[],sorties:sorties,requires_battery_swap:true,path:[],legs:[]}
            })
        }
    })
    return best
}

// T5b1 straight-flight only. Complete typed route/cmd3000/turn integration stays gated.
function routeNumber(x, name, low, high) {
    if (low === undefined) low = -1e100
    if (high === undefined) high = 1e100
    if (typeof x !== "number" || !isFinite(x) || x < low || x > high) throw new Error(name + ": finite number in range required")
    return x
}
function flightMode(v, mode, defaultMode) {
    var expected = airframeType(v) === "fixed_wing" ? "fw" : "mc"
    if (airframeType(v) === "vtol_hybrid") {
        if (mode === undefined || mode === null) mode = defaultMode
        if (mode !== "mc" && mode !== "fw") throw new Error("hybrid straight leg requires explicit mode='mc' or 'fw'")
        return mode
    }
    if (mode !== undefined && mode !== null && mode !== expected) throw new Error("mode is incompatible with airframe type")
    return expected
}
function routePosition(p) {
    if (!Array.isArray(p) || p.length !== 2) throw new Error("position: [lat, lon] required")
    routeNumber(p[0], "lat", -90, 90); routeNumber(p[1], "lon", -180, 180)
}
function routeWind(w) {
    routeNumber(w.speed_mps, "wind.speed_mps", 0); routeNumber(w.from_deg, "wind.from_deg")
    return windVector(w)
}
function airframeLegEstimate(v, a, b, altA, altB, groundMps, w, mode) {
    mode = flightMode(v, mode)
    routePosition(a); routePosition(b)
    routeNumber(altA,"alt_a"); routeNumber(altB,"alt_b"); routeNumber(groundMps,"ground_mps",1e-9)
    var windV = routeWind(w), we = windV[0], wn = windV[1]
    var dist = haversineM(a,b), dh = altB-altA, air, head, duration
    if (mode === "fw" && dist < 0.5) throw new Error("fixed-wing near-zero horizontal leg: loiter/takeoff/landing not modeled")
    if (dist >= 0.5) {
        var brg = bearingRad(a,b)
        air = Math.hypot(groundMps*Math.sin(brg)-we,groundMps*Math.cos(brg)-wn)
        head = -(we*Math.sin(brg)+wn*Math.cos(brg)); duration = dist/groundMps
    } else { air=w.speed_mps; head=0; duration=0 }
    var wh, watts
    if (mode === "fw") {
        watts=powerW(v,air,"fw",0,Math.max(0,dh)/duration)
        wh=watts*duration/3600*v.calib
    } else {
        if (air > v.max_mps) throw new Error("v_air: outside mc airspeed envelope")
        watts=powerW(v,air,"mc")
        var verticalS=dh>0?Math.max(0,dh)/3:Math.max(0,-dh)/2
        if (w.speed_mps > v.max_mps) throw new Error("wind exceeds mc airspeed envelope during vertical flight")
        var joules=watts*duration+powerW(v,w.speed_mps,"mc")*verticalS
        var eta=airframeType(v)==="vtol_hybrid"?v.airframe_profile.power.mc.eta:v.eta
        joules+=v.mass_kg*G*Math.max(0,dh)/eta; duration+=verticalS
        wh=joules/3600*v.calib
    }
    return {dist_m:dist,time_s:duration,energy_wh:wh,v_air:air,headwind_mps:head,mode:mode,scope:"straight_leg_only"}
}
function transitionEstimate(v, fromMode, toMode) {
    if (airframeType(v)!=="vtol_hybrid") throw new Error("transition requires vtol_hybrid")
    if (["mc","fw"].indexOf(fromMode)<0 || ["mc","fw"].indexOf(toMode)<0) throw new Error("transition modes must be mc or fw")
    var t=v.airframe_profile.transition, changed=fromMode!==toMode, prefix="to_"+toMode
    return {from_mode:fromMode,to_mode:toMode,energy_wh:changed?t[prefix+"_wh"]*v.calib:0,
            time_s:changed?t[prefix+"_s"]:0,dist_m:changed&&toMode==="fw"?t.to_fw_dist_m:0,
            scope:"transition_allowance_only"}
}
function airframeRtlEnergy(pos, home, v, w, groundMps, mode) {
    mode=flightMode(v,mode,"fw")
    var a=[pos.lat,pos.lon], b=[home.lat,home.lon]
    routePosition(a); routePosition(b)
    var alt=routeNumber(pos.alt===undefined?0:pos.alt,"rtl.alt",0)
    if (routeNumber(home.alt===undefined?0:home.alt,"home.alt")!==0) throw new Error("RTL expects altitude relative to home ground; home.alt must be zero")
    var speed=groundMps===undefined||groundMps===null?v.cruise_mps:groundMps
    routeNumber(speed,"ground_mps",1e-9); routeWind(w)
    var legs=[]
    if (airframeType(v)==="fixed_wing") legs.push(airframeLegEstimate(v,a,b,alt,alt,speed,w,"fw"))
    else if (mode==="fw") {
        if (haversineM(a,b)>=0.5) legs.push(airframeLegEstimate(v,a,b,alt,alt,speed,w,"fw"))
        legs.push(transitionEstimate(v,"fw","mc"))
        legs.push(airframeLegEstimate(v,b,b,alt,0,speed,w,"mc"))
    } else legs.push(airframeLegEstimate(v,a,b,alt,0,speed,w,"mc"))
    var wh=0,ts=0,dm=0
    legs.forEach(function(x){wh+=x.energy_wh;ts+=x.time_s;dm+=x.dist_m})
    var cap=routeNumber(v.battery_wh*v.usable_frac,"usable capacity",1e-9)
    return {dist_m:dm,time_s:ts,energy_wh:wh,used_pct:wh/cap*100,legs:legs,
            arrival_mode:airframeType(v)==="fixed_wing"?"fw":"mc",landing_modeled:airframeType(v)!=="fixed_wing",
            scope:"rtl_energy_only_not_executable_route"}
}
function airframeBestSpeed(v,w,headingDeg,lo,hi,mode) {
    mode=flightMode(v,mode,"fw")
    if (headingDeg===undefined) headingDeg=0
    if (lo===undefined) lo=4
    routeNumber(headingDeg,"heading_deg");routeNumber(lo,"lo",0)
    var range=mode==="fw"?speedRange(v):[0,v.max_mps]
    var upper=hi===undefined||hi===null?range[1]:Math.min(range[1],routeNumber(hi,"hi",0))
    var lower=Math.max(range[0],lo),wv=routeWind(w),theta=rad(headingDeg)
    var tail=wv[0]*Math.sin(theta)+wv[1]*Math.cos(theta),cross=wv[0]*Math.cos(theta)-wv[1]*Math.sin(theta)
    var best=null,count=Math.max(0,Math.floor((upper-lower)/.5+1e-9)+1)
    for (var k=0;k<count;k++) {
        var air=lower+k*.5
        if (air<=Math.abs(cross)) continue
        var ground=tail+Math.sqrt(Math.max(0,air*air-cross*cross))
        if (ground<=1e-9) continue
        var perKm=powerW(v,air,mode)*v.calib/ground/3.6
        if (best===null || perKm<best.wh_per_km) best={speed_mps:ground,airspeed_mps:air,wh_per_km:perKm}
    }
    if (best===null) throw new Error("no feasible forward airspeed in configured search interval/wind")
    best.wh_per_km=rnd(best.wh_per_km,2)
    return best
}

function estimateRouteEnergy(points,v,w,groundMps,startPct,mode) {
    if (groundMps===undefined||groundMps===null) groundMps=v.cruise_mps
    var pts=points.map(function(p,i){var q=clone(p);if(q.id===undefined)q.id="P"+i;return q})
    return routeEstimate(v,pts,groundMps,w,startPct,0,mode)
}
function rtlEnergy(pos,home,v,w,groundMps,mode) {
    if (airframeType(v)!=="multirotor") return airframeRtlEnergy(pos,home,v,w,groundMps,mode)
    flightMode(v,mode)
    var p=clone(pos),h=clone(home);p.id="here";h.id="home";h.alt=0
    return estimateRouteEnergy([p,h],v,w,groundMps)
}

// T5b2a: normalized local energy events, never raw MAVLink or a flown path.
function turnEstimate(v, vAir, angleDeg, w, bankDeg, radiusM) {
    routeNumber(angleDeg,"angle_deg",0,360); routeWind(w)
    if(w.speed_mps!==0) throw new Error("FW arc requires calm wind; ground-track turn model pending")
    var g=turnGeometry(v,vAir,bankDeg,radiusM)
    if(g.radius_m===null && angleDeg!==0) throw new Error("nonzero turn requires nonzero bank")
    var distance=(g.radius_m||0)*rad(angleDeg), seconds=distance/routeNumber(vAir,"v_air",1e-9)
    g.angle_deg=angleDeg;g.dist_m=distance;g.time_s=seconds
    g.energy_wh=powerW(v,vAir,"fw",g.bank_deg)*seconds/3600*v.calib
    g.mode="fw";g.scope="additive_air_relative_arc_allowance"
    return g
}
function loiterEstimate(v,vAir,durationS,w,radiusM,mode) {
    mode=flightMode(v,mode)
    routeNumber(durationS,"duration_s",0,86400);routeNumber(vAir,"v_air",1e-9);routeWind(w)
    if(mode==="mc") {
        if(radiusM!==undefined && radiusM!==null) throw new Error("MC hold does not accept an orbit radius")
        if(w.speed_mps>v.max_mps) throw new Error("wind exceeds mc airspeed envelope during hold")
        return {dist_m:0,time_s:durationS,energy_wh:powerW(v,w.speed_mps,"mc")*durationS/3600*v.calib,mode:"mc",scope:"stationary_mc_hold"}
    }
    if(w.speed_mps!==0) throw new Error("FW loiter requires calm wind; ground-track orbit model pending")
    var g=turnGeometry(v,vAir,undefined,radiusM)
    g.dist_m=vAir*durationS;g.time_s=durationS
    g.energy_wh=powerW(v,vAir,"fw",g.bank_deg)*durationS/3600*v.calib
    g.mode="fw";g.scope="air_relative_loiter_allowance"
    return g
}
function airframeRouteEstimate(v,points,groundMps,w,startPct,hoverS,mode) {
    if(airframeType(v)==="multirotor") throw new Error("typed_route is reserved for FW/hybrid; legacy MC route unchanged")
    if(!Array.isArray(points)||points.length<2||points.length>1000) throw new Error("route requires 2..1000 normalized events")
    if(startPct===undefined)startPct=100
    if(hoverS===undefined)hoverS=5
    routeNumber(groundMps,"ground_mps",1e-9);routeNumber(startPct,"start_pct",0,100)
    routeNumber(hoverS,"hover_s_per_wp",0,86400);routeWind(w)
    var cap=routeNumber(v.battery_wh*v.usable_frac,"usable capacity",1e-9)
    var has=function(o,k){return Object.prototype.hasOwnProperty.call(o,k)}
    var get=function(o,k,d){return has(o,k)?o[k]:d}
    var pose=function(p){if(!p||typeof p!=="object"||Array.isArray(p))throw new Error("point must be an object");routePosition([p.lat,p.lon]);routeNumber(get(p,"alt",0),"alt",0)}
    var first=points[0];pose(first)
    if(has(first,"cmd")||first.kind==="landing"||first.kind==="loiter")throw new Error("first event must be a pose, not a command/landing/loiter")
    if(mode!==undefined&&mode!==null&&get(first,"mode",mode)!==mode)throw new Error("initial mode contradicts first.mode")
    var initial=mode===undefined||mode===null?first.mode:mode
    if((initial===undefined||initial===null)&&first.kind==="takeoff")initial="mc"
    var active=flightMode(v,initial)
    if(first.kind==="takeoff"&&(airframeType(v)!=="vtol_hybrid"||active!=="mc"||get(first,"alt",0)!==0))throw new Error("takeoff start requires hybrid mc on ground")
    var current=clone(first);current.id=get(first,"id","P0")
    var legs=[],heading=null,landed=false,afterFwLoiter=false,pct=startPct
    var add=function(part,eventId){pct-=part.energy_wh/cap*100;part.from=current.id;part.to=eventId;part.pct_after=pct;legs.push(part)}
    var addTransition=function(t,eventId){t.transition_allowance_dist_m=t.dist_m;t.dist_m=0;add(t,eventId)}
    for(var i=1;i<points.length;i++) {
        var raw=points[i]
        if(!raw||typeof raw!=="object"||Array.isArray(raw))throw new Error("event must be an object")
        var eventId=get(raw,"id","P"+i)
        if(landed)throw new Error("events after landing are unsupported")
        if(has(raw,"cmd")) {
            if(raw.cmd!==3000||airframeType(v)!=="vtol_hybrid")throw new Error("only normalized hybrid cmd3000 is supported")
            Object.keys(raw).forEach(function(k){if(["id","cmd","to_mode","lat","lon","alt"].indexOf(k)<0)throw new Error("unsupported cmd3000 fields; normalize before estimating")})
            ;["lat","lon","alt"].forEach(function(k){if(has(raw,k)){routeNumber(raw[k],k);if(raw[k]!==get(current,k,0))throw new Error("cmd3000 cannot change pose")}})
            var t=transitionEstimate(v,active,raw.to_mode),changed=active!==t.to_mode
            addTransition(t,eventId);active=t.to_mode;if(changed){heading=null;afterFwLoiter=false}
            continue
        }
        pose(raw)
        var kind=get(raw,"kind","waypoint")
        if(["waypoint","target","home","takeoff","landing","loiter"].indexOf(kind)<0)throw new Error("unsupported normalized point kind")
        if(kind==="takeoff"||kind==="landing") {
            if(airframeType(v)!=="vtol_hybrid")throw new Error("FW takeoff/landing geometry is not modeled")
            if(kind==="takeoff"&&(get(current,"alt",0)!==0||get(raw,"alt",0)<=0))throw new Error("takeoff must leave ground for positive altitude")
            if(kind==="landing"&&(get(raw,"alt",0)!==0||get(current,"alt",0)<=0))throw new Error("landing must descend to relative ground altitude zero")
            if(active!=="mc"){addTransition(transitionEstimate(v,active,"mc"),eventId);active="mc";heading=null;afterFwLoiter=false}
        }
        if(get(raw,"mode",active)!==active)throw new Error("mode changes require cmd3000 or a takeoff/landing event")
        var a=[current.lat,current.lon],b=[raw.lat,raw.lon],distance=haversineM(a,b)
        var outbound=distance>=.5?bearingRad(a,b):null
        if(active==="fw"&&afterFwLoiter&&outbound!==null)throw new Error("FW departure after loiter requires an exit-heading model")
        if(active==="fw"&&heading!==null&&outbound!==null) {
            var angle=Math.abs((( (outbound-heading)*180/Math.PI+180)%360+360)%360-180)
            if(angle>1e-9)add(turnEstimate(v,groundMps,angle,w),current.id)
        }
        var dwell=get(raw,"loiter_s",kind==="target"?hoverS:0)
        routeNumber(dwell,"loiter_s",0,86400)
        if(kind==="loiter"&&dwell<=0)throw new Error("loiter event requires positive loiter_s")
        var samePoseHold=active==="fw"&&distance<.5&&get(raw,"alt",0)===get(current,"alt",0)&&dwell>0
        if(!samePoseHold)add(airframeLegEstimate(v,a,b,get(current,"alt",0),get(raw,"alt",0),groundMps,w,active),eventId)
        if(dwell>0)add(loiterEstimate(v,groundMps,dwell,w,raw.radius_m,active),eventId)
        else if(has(raw,"radius_m"))throw new Error("radius_m requires a positive loiter duration")
        heading=active==="fw"&&dwell===0?outbound:null
        afterFwLoiter=active==="fw"&&dwell>0
        current=clone(raw);current.id=eventId;landed=kind==="landing"
    }
    var wh=0,ts=0,dm=0,td=0
    legs.forEach(function(x){wh+=x.energy_wh;ts+=x.time_s;dm+=x.dist_m;td+=x.transition_allowance_dist_m||0})
    var energyOk=pct>=v.reserve_pct
    return {dist_m:dm,time_s:ts,energy_wh:wh,end_pct:pct,used_pct:startPct-pct,margin_pct:pct-v.reserve_pct,
            feasible:energyOk&&landed,energy_feasible:energyOk,arrival_mode:active,landing_modeled:landed,
            transition_allowance_dist_m:td,scope:"normalized_route_energy_only_not_executable_route",legs:legs}
}

// T5b2b: finite, replayable whole-route scenarios. No return-route inference.
function boundsSnapshot(x) {
    function check(v) {
        if(v===null||typeof v==="string"||typeof v==="boolean")return
        if(typeof v==="number"){if(!isFinite(v))throw new Error("nonfinite bounds context");return}
        if(Array.isArray(v)){v.forEach(check);return}
        if(v&&typeof v==="object"){Object.keys(v).forEach(function(k){check(v[k])});return}
        throw new Error("bounds context must be JSON data")
    }
    check(x);return clone(x)
}
function boundsCanonical(x) {
    if(Array.isArray(x))return "["+x.map(boundsCanonical).join(",")+"]"
    if(x&&typeof x==="object")return "{"+Object.keys(x).sort().map(function(k){return JSON.stringify(k)+":"+boundsCanonical(x[k])}).join(",")+"}"
    return JSON.stringify(x)
}
function boundsRequest(v,points,groundMps,w,startPct,hoverS,mode) {
    if(!Array.isArray(points)||points.length<2||points.length>1000)throw new Error("bounds route requires 2..1000 explicit events")
    points.forEach(function(p){
        if(!p||typeof p!=="object"||Array.isArray(p))throw new Error("bounds route event must be an object")
        if(Object.prototype.hasOwnProperty.call(p,"cmd")&&airframeType(v)!=="vtol_hybrid")throw new Error("mode events require a hybrid airframe")
        if(!Object.prototype.hasOwnProperty.call(p,"cmd")){routePosition([p.lat,p.lon]);routeNumber(p.alt===undefined?0:p.alt,"alt",0)}
        if(p.loiter_s!==undefined)routeNumber(p.loiter_s,"loiter_s",0,86400)
    })
    routeNumber(groundMps,"ground_mps",1e-9);routeNumber(startPct,"start_pct",0,100)
    routeNumber(hoverS,"hover_s_per_wp",0,86400);routeNumber(v.battery_wh*v.usable_frac,"usable capacity",1e-9)
    routeNumber(v.reserve_pct,"reserve_pct",0,100)
    if(mode!==null&&mode!=="mc"&&mode!=="fw")throw new Error("unknown flight mode")
    routeWind(w)
    var normalized=boundsSnapshot(points);normalized.forEach(function(p,i){if(p.id===undefined)p.id="P"+i})
    return boundsSnapshot({schema:1,route:normalized,ground_mps:groundMps,wind:{speed_mps:w.speed_mps,from_deg:w.from_deg},
        start_pct:startPct,hover_s_per_wp:hoverS,mode:mode,vehicle:v})
}
function estimateForBounds(v,points,groundMps,w,startPct,hoverS,mode) {
    if(startPct===undefined)startPct=100
    if(hoverS===undefined)hoverS=0
    if(mode===undefined)mode=null
    var c=boundsRequest(v,points,groundMps,w,startPct,hoverS,mode)
    var result=routeEstimate(v,clone(c.route),groundMps,w,startPct,hoverS,mode===null?undefined:mode)
    result.bounds_context=c;return result
}
function bounds(estimate,v) {
    if(!estimate||!estimate.bounds_context)throw new Error("bounds requires estimateForBounds replay context")
    var c=boundsSnapshot(estimate.bounds_context)
    var keys=["schema","route","ground_mps","wind","start_pct","hover_s_per_wp","mode","vehicle"]
    if(c.schema!==1||Object.keys(c).sort().join(",")!==keys.sort().join(","))throw new Error("unsupported bounds context")
    if(boundsCanonical(c.vehicle)!==boundsCanonical(boundsSnapshot(v)))throw new Error("bounds context belongs to a different vehicle snapshot")
    if(!c.wind||Object.keys(c.wind).sort().join(",")!=="from_deg,speed_mps")throw new Error("invalid context wind")
    boundsRequest(v,c.route,c.ground_mps,c.wind,c.start_pct,c.hover_s_per_wp,c.mode)
    if(!v.airframe_profile)throw new Error("bounds requires a profile with explicit uncertainty")
    var u=v.airframe_profile.uncertainty,power=routeNumber(u.power_pct,"uncertainty.power_pct",0,100)/100
    var capacity=routeNumber(u.capacity_pct,"uncertainty.capacity_pct",0,100)/100,delta=routeNumber(u.wind_mps,"uncertainty.wind_mps",0)
    if(capacity>=1)throw new Error("capacity uncertainty must leave positive usable Wh")
    var tuples=[[c.wind.speed_mps,1,1]]
    ;[Math.max(0,c.wind.speed_mps-delta),c.wind.speed_mps,c.wind.speed_mps+delta].forEach(function(speed){
        ;[1-power,1+power].forEach(function(pm){[1-capacity,1+capacity].forEach(function(cm){
            if(!tuples.some(function(t){return t[0]===speed&&t[1]===pm&&t[2]===cm}))tuples.push([speed,pm,cm])
        })})
    })
    var rows=tuples.map(function(t,i){
        var row={id:"S"+i,wind:{speed_mps:t[0],from_deg:c.wind.from_deg},power_multiplier:t[1],capacity_multiplier:t[2]}
        try {
            var e=routeEstimate(v,clone(c.route),c.ground_mps,row.wind,c.start_pct,c.hover_s_per_wp,c.mode===null?undefined:c.mode)
            var wh=routeNumber(routeNumber(e.energy_wh,"replayed energy_wh",0)*t[1],"scaled energy_wh",0)
            var cap=routeNumber(v.battery_wh*v.usable_frac*t[2],"scenario capacity",1e-9)
            var end=routeNumber(c.start_pct-wh/cap*100,"end_pct",-1e100)
            row.status="ok";row.base_energy_wh=e.energy_wh;row.energy_wh=wh;row.capacity_wh=cap;row.end_pct=end
            row.margin_pct=end-v.reserve_pct;row.energy_feasible=end>=v.reserve_pct;row.landing_modeled=e.landing_modeled===true;row.legs=e.legs
        } catch(err) {
            if(err instanceof ReferenceError||err instanceof TypeError||err instanceof SyntaxError)throw err
            row.status="unsupported";row.reason=String(err.message||err)
        }
        return row
    })
    var ok=rows.every(function(r){return r.status==="ok"}),low=null,high=null
    if(ok){low=rows[0];high=rows[0];rows.forEach(function(r){if(r.end_pct<low.end_pct)low=r;if(r.end_pct>high.end_pct)high=r})}
    return {available:ok,scope:"finite_full_route_scenarios_not_robust_or_probability_interval",wind_direction_varied:false,return_inferred:false,
        low_pct:ok?low.end_pct:null,high_pct:ok?high.end_pct:null,conservative:low,optimistic:high,nominal:rows[0],scenarios:rows}
}

// Explicit FW air-relative allowances in steady uniform wind, not ground orbits.
function windArcResult(v,vAir,durationS,w,entryHeadingDeg,clockwise,g) {
    routeNumber(entryHeadingDeg,"entry_heading_deg")
    if(typeof clockwise!=="boolean") throw new Error("clockwise: boolean required")
    var wv=routeWind(w),radius=g.radius_m
    if(radius===null) throw new Error("wind arc/loiter requires a nonzero bank")
    var bank=Math.abs(g.bank_deg)*(clockwise?1:-1),omega=vAir/radius*(clockwise?1:-1)
    var entry=((entryHeadingDeg%360)+360)%360,sweep=omega*durationS,theta=rad(entry)
    var end=theta+sweep%(2*Math.PI)
    var ae=vAir/omega*(Math.cos(theta)-Math.cos(end)),an=vAir/omega*(Math.sin(end)-Math.sin(theta))
    var de=wv[0]*durationS,dn=wv[1]*durationS
    var ee=vAir*Math.sin(end)+wv[0],en=vAir*Math.cos(end)+wv[1],speed=Math.sqrt(ee*ee+en*en)
    g.bank_deg=bank;g.time_s=durationS;g.air_dist_m=vAir*durationS
    g.energy_wh=powerW(v,vAir,"fw",bank)*durationS/3600*v.calib
    g.entry_air_heading_deg=entry;g.exit_air_heading_deg=((end*180/Math.PI)%360+360)%360
    g.signed_sweep_deg=sweep*180/Math.PI;g.clockwise=clockwise
    g.air_displacement_m={east:ae,north:an};g.wind_drift_m={east:de,north:dn}
    g.ground_displacement_m={east:ae+de,north:an+dn}
    g.exit_ground_speed_mps=speed
    g.exit_ground_heading_deg=speed>1e-9?((Math.atan2(ee,en)*180/Math.PI)%360+360)%360:null
    g.mode="fw";g.ground_fixed_orbit=false
    g.scope="uniform_wind_air_relative_allowance_not_executable_route"
    return g
}
function windArcEstimate(v,vAir,angleDeg,w,entryHeadingDeg,clockwise,bankDeg,radiusM) {
    if(clockwise===undefined) clockwise=true
    routeNumber(vAir,"v_air",1e-9);routeNumber(angleDeg,"angle_deg",0,360)
    var g=turnGeometry(v,vAir,bankDeg,radiusM)
    if(g.radius_m===null) throw new Error("wind arc/loiter requires a nonzero bank")
    return windArcResult(v,vAir,g.radius_m*rad(angleDeg)/vAir,w,entryHeadingDeg,clockwise,g)
}
function windLoiterEstimate(v,vAir,durationS,w,entryHeadingDeg,clockwise,radiusM) {
    if(clockwise===undefined) clockwise=true
    routeNumber(vAir,"v_air",1e-9);routeNumber(durationS,"duration_s",0,86400)
    return windArcResult(v,vAir,durationS,w,entryHeadingDeg,clockwise,turnGeometry(v,vAir,undefined,radiusM))
}

// Explicit flat local-frame tangent joins. Never an automatic waypoint fillet.
function windRouteEstimate(v,entry,events,w,startPct,mode) {
    if(startPct===undefined) startPct=100
    if(flightMode(v,mode)!=="fw") throw new Error("wind route requires FW mode")
    if(!entry||typeof entry!=="object"||Array.isArray(entry)||Object.keys(entry).sort().join(",")!=="air_heading_deg,east_m,north_m") throw new Error("entry requires only east_m, north_m, air_heading_deg")
    if(!Array.isArray(events)||events.length<1||events.length>1000) throw new Error("wind route requires 1..1000 events")
    var east=routeNumber(entry.east_m,"east_m"),north=routeNumber(entry.north_m,"north_m")
    var heading=((routeNumber(entry.air_heading_deg,"air_heading_deg")%360)+360)%360
    routeNumber(startPct,"start_pct",0,100)
    var windV=routeWind(w),we=windV[0],wn=windV[1],capacity=routeNumber(v.battery_wh*v.usable_frac,"usable capacity",1e-9)
    var previousAir=null,legs=[],energy=0,seconds=0,airDistance=0,straightDistance=0
    var allowed={straight:["kind","id","east_m","north_m","ground_mps"],arc:["kind","id","v_air","angle_deg","clockwise","bank_deg","radius_m"],loiter:["kind","id","v_air","duration_s","clockwise","radius_m"]}
    for(var index=0;index<events.length;index++) {
        var event=events[index]
        if(!event||typeof event!=="object"||Array.isArray(event)||typeof event.kind!=="string") throw new Error("event requires a kind")
        var kind=event.kind
        if(!Object.prototype.hasOwnProperty.call(allowed,kind)||Object.keys(event).some(function(k){return allowed[kind].indexOf(k)<0})) throw new Error("unsupported wind-route event fields")
        var start={east_m:east,north_m:north},air,part
        if(kind==="straight") {
            var te=routeNumber(event.east_m,"east_m"),tn=routeNumber(event.north_m,"north_m"),speed=routeNumber(event.ground_mps,"ground_mps",1e-9)
            var de=te-east,dn=tn-north,distance=routeNumber(Math.hypot(de,dn),"straight distance",1e-6)
            var ae=speed*de/distance-we,an=speed*dn/distance-wn
            air=routeNumber(Math.hypot(ae,an),"v_air",1e-9)
            var required=((Math.atan2(ae,an)*180/Math.PI)%360+360)%360
            if(Math.abs(((required-heading+540)%360)-180)>1e-6) throw new Error("straight target is not tangent to entry air heading")
            var duration=distance/speed
            part={time_s:duration,energy_wh:powerW(v,air,"fw")*duration/3600*v.calib,
                  air_dist_m:air*duration,straight_dist_m:distance,exit_air_heading_deg:required,
                  exit_ground_heading_deg:((Math.atan2(de,dn)*180/Math.PI)%360+360)%360,
                  exit_ground_speed_mps:speed,ground_displacement_m:{east:de,north:dn}}
        } else {
            air=routeNumber(event.v_air,"v_air",1e-9)
            if(typeof event.clockwise!=="boolean") throw new Error("clockwise: boolean required")
            if(kind==="arc") part=windArcEstimate(v,air,event.angle_deg,w,heading,event.clockwise,event.bank_deg,event.radius_m)
            else part=windLoiterEstimate(v,air,event.duration_s,w,heading,event.clockwise,event.radius_m)
            part.straight_dist_m=0
        }
        if(previousAir!==null&&Math.abs(air-previousAir)>1e-6) throw new Error("airspeed discontinuity: acceleration is not modeled")
        previousAir=air
        east=routeNumber(east+part.ground_displacement_m.east,"exit east_m");north=routeNumber(north+part.ground_displacement_m.north,"exit north_m")
        heading=part.exit_air_heading_deg
        energy=routeNumber(energy+part.energy_wh,"route energy",0);seconds=routeNumber(seconds+part.time_s,"route time",0)
        airDistance=routeNumber(airDistance+part.air_dist_m,"air distance",0);straightDistance=routeNumber(straightDistance+part.straight_dist_m,"straight distance",0)
        part.kind=kind;part.id=event.id===undefined?"E"+index:event.id
        part.entry_local_m=start;part.exit_local_m={east_m:east,north_m:north};part.pct_after=startPct-energy/capacity*100;legs.push(part)
    }
    var endPct=startPct-energy/capacity*100,last=legs[legs.length-1]
    return {energy_wh:energy,time_s:seconds,air_dist_m:airDistance,straight_dist_m:straightDistance,
            end_pct:endPct,used_pct:startPct-endPct,margin_pct:endPct-v.reserve_pct,energy_feasible:endPct>=v.reserve_pct,
            feasible:false,landing_modeled:false,arrival_mode:"fw",exit_local_m:{east_m:east,north_m:north},
            exit_air_heading_deg:heading,exit_ground_heading_deg:last.exit_ground_heading_deg,exit_ground_speed_mps:last.exit_ground_speed_mps,
            legs:legs,scope:"explicit_local_tangent_energy_route_not_executable_route"}
}

// Bounded approximate geographic adapter. Never a geodesic/flight trajectory.
function geographicWindRouteEstimate(v,entry,events,w,startPct,mode) {
    var maxPath=10000,maxLat=75
    if(!entry||typeof entry!=="object"||Array.isArray(entry)||Object.keys(entry).sort().join(",")!=="air_heading_deg,alt,lat,lon") throw new Error("geographic entry requires only lat, lon, alt, air_heading_deg")
    routePosition([entry.lat,entry.lon])
    var lat0=routeNumber(entry.lat,"origin lat",-maxLat,maxLat),lon0=entry.lon
    var alt=routeNumber(entry.alt,"alt",0),heading=routeNumber(entry.air_heading_deg,"air_heading_deg")
    if(!Array.isArray(events)||events.length<1||events.length>1000) throw new Error("geographic route requires 1..1000 events")
    var metres=Math.PI*6371000/180,scale=metres*Math.cos(lat0*Math.PI/180)
    var allowed={straight:["kind","id","lat","lon","alt","ground_mps"],arc:["kind","id","v_air","angle_deg","clockwise","bank_deg","radius_m"],loiter:["kind","id","v_air","duration_s","clockwise","radius_m"]}
    var local=[]
    for(var i=0;i<events.length;i++) {
        var event=events[i]
        if(!event||typeof event!=="object"||Array.isArray(event)||typeof event.kind!=="string") throw new Error("geographic event requires a kind")
        var kind=event.kind
        if(!Object.prototype.hasOwnProperty.call(allowed,kind)||Object.keys(event).some(function(k){return allowed[kind].indexOf(k)<0})) throw new Error("unsupported geographic event fields")
        if(Object.prototype.hasOwnProperty.call(event,"id")&&(typeof event.id!=="string"||Array.from(event.id).length<1||Array.from(event.id).length>128)) throw new Error("id requires a nonempty string of at most 128 characters")
        if(kind==="straight") {
            routePosition([event.lat,event.lon])
            if(routeNumber(event.alt,"straight alt",0)!==alt) throw new Error("geographic wind route requires constant altitude")
            var east=(((event.lon-lon0+180)%360+360)%360-180)*scale,north=(event.lat-lat0)*metres
            if(Math.hypot(east,north)>maxPath) throw new Error("geographic target exceeds 10 km local frame")
            var item={kind:kind,east_m:east,north_m:north,ground_mps:event.ground_mps}
            if(Object.prototype.hasOwnProperty.call(event,"id")) item.id=event.id
            local.push(item)
        } else local.push(Object.assign({},event))
    }
    var result=windRouteEstimate(v,{east_m:0,north_m:0,air_heading_deg:heading},local,w,startPct,mode)
    var reach=routeNumber(result.air_dist_m+w.speed_mps*result.time_s,"path budget",0)
    if(reach>maxPath) throw new Error("geographic route exceeds 10 km cumulative path budget")
    function geographic(p){return {lat:lat0+p.north_m/metres,lon:(((lon0+p.east_m/scale+180)%360+360)%360)-180,alt:alt}}
    result.legs=result.legs.map(function(leg){return Object.assign({},leg,{entry_geographic:geographic(leg.entry_local_m),exit_geographic:geographic(leg.exit_local_m)})})
    result.exit_geographic=geographic(result.exit_local_m)
    result.projection={kind:"entry_anchored_equirectangular_approximation",origin:{lat:lat0,lon:lon0,alt:alt},earth_radius_m:6371000,max_path_m:maxPath,max_origin_lat_deg:maxLat,path_budget_m:reach}
    result.scope="geographic_explicit_tangent_energy_approximation_not_executable_route"
    return result
}

// Explicit typed mission alternatives; never an automatic live alert action.
function typedAlertSpeeds(v,requested,mode,bankDeg) {
    if(!v.airframe_profile)throw new Error("typed alerts require an explicit airframe profile")
    if(bankDeg===undefined)bankDeg=0
    var active=flightMode(v,mode),low,high
    routeNumber(bankDeg,"bank_deg",-89.999999,89.999999)
    if(active==="mc") {
        if(bankDeg!==0)throw new Error("MC airspeed options do not model bank")
        low=v.airframe_profile.limits.min_airspeed_mps;high=v.airframe_profile.limits.max_airspeed_mps
    } else {var envelope=speedRange(v,bankDeg);low=envelope[0];high=envelope[1]}
    routeNumber(low,"minimum airspeed",0);routeNumber(high,"maximum airspeed",low)
    if(!Array.isArray(requested)||requested.length<1||requested.length>101)throw new Error("requested airspeeds require 1..101 values")
    var values=[]
    requested.forEach(function(x){routeNumber(x,"requested airspeed",0);if(values.indexOf(x)<0)values.push(x)})
    values.sort(function(a,b){return a-b})
    return {basis:"airspeed_mps_not_ground_speed",mode:active,minimum_mps:low,maximum_mps:high,
        accepted_mps:values.filter(function(x){return x>=low&&x<=high}),rejected_mps:values.filter(function(x){return x<low||x>high})}
}

function evaluateTypedAlertCandidates(v,candidates,w,startPct) {
    if(startPct===undefined)startPct=100
    if(!v.airframe_profile||["fixed_wing","vtol_hybrid"].indexOf(airframeType(v))<0)throw new Error("typed candidate evaluator requires FW/hybrid profile")
    routeWind(w);routeNumber(startPct,"start_pct",0,100)
    if(!Array.isArray(candidates)||candidates.length<1||candidates.length>16)throw new Error("typed candidates require 1..16 alternatives")
    var items=boundsSnapshot(candidates),seen=[]
    items.forEach(function(item){
        if(!item||typeof item!=="object"||Array.isArray(item)||!["id","points","ground_mps"].every(function(k){return Object.prototype.hasOwnProperty.call(item,k)}))throw new Error("candidate requires id, points, ground_mps")
        if(Object.keys(item).some(function(k){return ["id","points","ground_mps","mode","hover_s_per_wp"].indexOf(k)<0}))throw new Error("unsupported typed candidate fields")
        if(typeof item.id!=="string"||Array.from(item.id).length<1||Array.from(item.id).length>128||seen.indexOf(item.id)>=0)throw new Error("candidate id must be unique, nonempty, at most 128 characters")
        seen.push(item.id)
    })
    var rows=items.map(function(item){
        var row={id:item.id,feasible:false,return_inferred:false}
        try {
            var active=flightMode(v,item.mode)
            if(!Array.isArray(item.points)||item.points.length<2||item.points.length>1000)throw new Error("candidate points require 2..1000 events")
            item.points.forEach(function(p){if(!p||typeof p!=="object"||Array.isArray(p)||(!Object.prototype.hasOwnProperty.call(p,"cmd")&&(!Object.prototype.hasOwnProperty.call(p,"lat")||!Object.prototype.hasOwnProperty.call(p,"lon"))))throw new Error("candidate movement event requires lat/lon")})
            var estimate=estimateForBounds(v,item.points,item.ground_mps,w,startPct,item.hover_s_per_wp===undefined?0:item.hover_s_per_wp,active)
            var interval=bounds(estimate,v),supported=interval.available
            row.status=supported?"ok":"unsupported";row.estimate=estimate;row.bounds=interval
            row.sampled_energy_feasible=!!(supported&&interval.low_pct>=v.reserve_pct)
            if(!supported)row.reason="one or more full-route scenarios unsupported"
        } catch(error) {
            // Only domain errors use Error in the current energy core. Preserve
            // unexpected native errors instead of hiding programming defects.
            if(error.constructor!==Error)throw error
            row.status="unsupported";row.reason=error.message;row.sampled_energy_feasible=false
        }
        return row
    })
    var best=null
    rows.forEach(function(row){if(row.sampled_energy_feasible&&(!best||row.bounds.low_pct>best.bounds.low_pct))best=row})
    return {scope:"caller_supplied_normalized_mission_energy_comparison_only",candidates:rows,best_energy_id:best?best.id:null,
        ranking:"maximum_sampled_low_pct_first_input_on_tie",return_inferred:false,wind_direction_varied:false,feasible:false,executable:false}
}

// Finite JSON only. Reject values JSON.stringify would silently discard/change.
function geographicAlertSnapshot(value) {
    function check(x,stack) {
        if(x===null||typeof x==="string"||typeof x==="boolean")return
        if(typeof x==="number") {if(!Number.isFinite(x))throw new Error("geographic alert input must be finite JSON data");return}
        if(typeof x!=="object"||stack.indexOf(x)>=0)throw new Error("geographic alert input must be finite JSON data")
        stack.push(x)
        if(Array.isArray(x)) {for(var i=0;i<x.length;i++){if(!Object.prototype.hasOwnProperty.call(x,i))throw new Error("sparse JSON array unsupported");check(x[i],stack)}}
        else {if(Object.prototype.toString.call(x)!=="[object Object]")throw new Error("JSON object required");Object.keys(x).forEach(function(k){check(x[k],stack)})}
        stack.pop()
    }
    check(value,[])
    return JSON.parse(JSON.stringify(value))
}

function geographicWindRouteBounds(v,entry,events,w,startPct,mode) {
    if(!v.airframe_profile||["fixed_wing","vtol_hybrid"].indexOf(airframeType(v))<0)throw new Error("geographic bounds require FW/hybrid profile")
    var active=flightMode(v,mode)
    if(active!=="fw")throw new Error("geographic bounds support only explicit FW flight")
    routeWind(w)
    if(startPct===undefined)startPct=100
    routeNumber(startPct,"start_pct",0,100)
    var usable=routeNumber(v.battery_wh*v.usable_frac,"usable capacity",1e-9),reserve=routeNumber(v.reserve_pct,"reserve_pct",0,100)
    var request=geographicAlertSnapshot({entry:entry,events:events}),u=v.airframe_profile.uncertainty
    var power=routeNumber(u.power_pct,"uncertainty.power_pct",0,100)/100,capacity=routeNumber(u.capacity_pct,"uncertainty.capacity_pct",0,100)/100
    var delta=routeNumber(u.wind_mps,"uncertainty.wind_mps",0)
    if(capacity>=1)throw new Error("capacity uncertainty must leave positive usable Wh")
    var tuples=[[w.speed_mps,1,1]]
    ;[Math.max(0,w.speed_mps-delta),w.speed_mps,w.speed_mps+delta].forEach(function(speed){
        ;[1-power,1+power].forEach(function(pm){[1-capacity,1+capacity].forEach(function(cm){
            if(!tuples.some(function(t){return t[0]===speed&&t[1]===pm&&t[2]===cm}))tuples.push([speed,pm,cm])
        })})
    })
    var rows=tuples.map(function(t,i){
        var row={id:"G"+i,wind:{speed_mps:t[0],from_deg:w.from_deg},power_multiplier:t[1],capacity_multiplier:t[2]}
        try {
            var e=geographicWindRouteEstimate(v,request.entry,request.events,wind(t[0],w.from_deg),startPct,active)
            var wh=routeNumber(routeNumber(e.energy_wh,"base energy_wh",0)*t[1],"scaled energy_wh",0)
            var cap=routeNumber(usable*t[2],"scenario capacity",1e-9),end=routeNumber(startPct-wh/cap*100,"end_pct")
            Object.assign(row,{status:"ok",base_estimate:e,base_energy_wh:e.energy_wh,energy_wh:wh,capacity_wh:cap,end_pct:end,margin_pct:end-reserve,energy_feasible:end>=reserve,landing_modeled:false})
        }catch(err){row.status="unsupported";row.reason=String(err.message||err)}
        return row
    })
    var available=rows.every(function(r){return r.status==="ok"}),low=null,high=null
    if(available){low=rows[0];high=rows[0];rows.forEach(function(r){if(r.end_pct<low.end_pct)low=r;if(r.end_pct>high.end_pct)high=r})}
    return geographicAlertSnapshot({available:available,scenarios:rows,nominal:rows[0],low_pct:available?low.end_pct:null,high_pct:available?high.end_pct:null,
        conservative:low,optimistic:high,scope:"finite_geographic_event_scenarios_not_robust_or_probability_interval",wind_direction_varied:false,
        return_inferred:false,common_endpoint_enforced:false,geometry_replayed:true,landing_modeled:false,feasible:false,executable:false})
}

function evaluateGeographicAlertCandidates(v,candidates,w,startPct) {
    if(!v.airframe_profile||["fixed_wing","vtol_hybrid"].indexOf(airframeType(v))<0)throw new Error("geographic candidates require FW/hybrid profile")
    routeWind(w)
    if(startPct===undefined)startPct=100
    routeNumber(startPct,"start_pct",0,100)
    if(!Array.isArray(candidates)||candidates.length<1||candidates.length>16)throw new Error("geographic candidates require 1..16 alternatives")
    var items=geographicAlertSnapshot(candidates),seen=[]
    items.forEach(function(item){
        if(!item||typeof item!=="object"||Array.isArray(item)||!["id","entry","events"].every(function(k){return Object.prototype.hasOwnProperty.call(item,k)}))throw new Error("geographic candidate requires id, entry, events")
        if(Object.keys(item).some(function(k){return ["id","entry","events","mode"].indexOf(k)<0}))throw new Error("unsupported geographic candidate fields")
        if(typeof item.id!=="string"||Array.from(item.id).length<1||Array.from(item.id).length>128||seen.indexOf(item.id)>=0)throw new Error("candidate id must be unique, nonempty, at most 128 characters")
        seen.push(item.id)
    })
    var rows=items.map(function(item){
        var row={id:item.id,feasible:false,return_inferred:false,sampled_energy_feasible:false}
        try {
            var interval=geographicWindRouteBounds(v,item.entry,item.events,w,startPct,item.mode),supported=interval.available
            Object.assign(row,{status:supported?"ok":"unsupported",bounds:interval,sampled_energy_feasible:!!(supported&&interval.low_pct>=v.reserve_pct)})
            if(!supported)row.reason="one or more full geographic event scenarios unsupported"
        }catch(err){row.status="unsupported";row.reason=String(err.message||err)}
        return row
    }),best=null
    rows.forEach(function(r){if(r.sampled_energy_feasible&&(!best||r.bounds.low_pct>best.bounds.low_pct))best=r})
    return {scope:"caller_supplied_geographic_event_energy_comparison_only",candidates:rows,best_energy_id:best?best.id:null,ranking:"maximum_sampled_low_pct_first_input_on_tie",
        return_inferred:false,wind_direction_varied:false,common_endpoint_enforced:false,feasible:false,executable:false}
}

// Additive P1 only: explicit caller-owned geographic candidates; no action.
function geographicEnergyAlertSnapshot(v,candidates,currentId,w,startPct) {
    var items=geographicAlertSnapshot(candidates)
    var comparison=evaluateGeographicAlertCandidates(v,items,w,startPct)
    if(typeof currentId!=="string"||!items.some(function(x){return x.id===currentId}))throw new Error("current_id must identify one supplied candidate")
    var current=items.filter(function(x){return x.id===currentId})[0],activeMode=flightMode(v,current.mode)
    if(activeMode!=="fw")throw new Error("typed geographic alerts require FW mode")
    items.forEach(function(item){
        var p=item.entry,keys=["lat","lon","alt","air_heading_deg"]
        if(!p||typeof p!=="object"||Array.isArray(p)||Object.keys(p).length!==4||!keys.every(function(k){return Object.prototype.hasOwnProperty.call(p,k)}))throw new Error("typed alert entry requires lat, lon, alt, air_heading_deg")
        routeNumber(p.lat,"entry lat",-75,75);routeNumber(p.lon,"entry lon",-180,180);routeNumber(p.alt,"entry alt",0);routeNumber(p.air_heading_deg,"entry air_heading_deg")
        if(!item.entry||!current.entry||Object.keys(item.entry).length!==Object.keys(current.entry).length||Object.keys(current.entry).some(function(k){return !Object.prototype.hasOwnProperty.call(item.entry,k)||item.entry[k]!==current.entry[k]}))throw new Error("typed alert alternatives require one identical entry pose")
        if(flightMode(v,item.mode)!==activeMode)throw new Error("typed alert alternatives require one flight mode")
    })
    var row=comparison.candidates.filter(function(x){return x.id===currentId})[0],known=row.status==="ok",bounds=row.bounds||{},nominal=bounds.nominal||{}
    return geographicAlertSnapshot({scope:"typed_geographic_P1_finite_energy_samples_only",status:known?"ok":"unsupported",current_id:currentId,
        entry:current.entry,mode:activeMode,start_pct:startPct===undefined?100:startPct,reserve_pct:v.reserve_pct,
        sampled_energy_risk:known?bounds.low_pct<v.reserve_pct:null,nominal_end_pct:nominal.status==="ok"?nominal.end_pct:null,
        low_pct:known?bounds.low_pct:null,high_pct:known?bounds.high_pct:null,comparison:comparison,rule_choice:null,
        return_inferred:false,landing_modeled:false,feasible:false,executable:false})
}

function typedPredictorInteger(value,name,low,high) {
    if(!Number.isSafeInteger(value)||value<low||value>high)throw new Error(name+" must be an integer in range")
    return value
}

function createGeographicEnergyAlertPredictor(v,raiseTicks,clearTicks) {
    if(raiseTicks===undefined)raiseTicks=3
    if(clearTicks===undefined)clearTicks=10
    typedPredictorInteger(raiseTicks,"raise_ticks",1,10000)
    typedPredictorInteger(clearTicks,"clear_ticks",1,10000)
    // Match Python deepcopy: later caller edits cannot alter a live latch.
    var vehicle=geographicAlertSnapshot(v),lastSequence=-1,active=false,raising=0,clearing=0
    return {tick:function(sequence,candidates,currentId,w,startPct){
        typedPredictorInteger(sequence,"sequence",0,9007199254740991)
        if(sequence<=lastSequence)throw new Error("sequence must increase strictly")
        var result=geographicEnergyAlertSnapshot(vehicle,candidates,currentId,w,startPct)
        lastSequence=sequence
        var known=result.status==="ok",risk=result.sampled_energy_risk
        if(!known){active=false;raising=0;clearing=0}
        else if(risk){raising=Math.min(raising+1,raiseTicks);clearing=0;if(raising>=raiseTicks)active=true}
        else{clearing=Math.min(clearing+1,clearTicks);raising=0;if(clearing>=clearTicks)active=false}
        var published=known?active:null,severity=!published?5:(result.nominal_end_pct<0?2:4),finding=null
        if(known)finding={key:"typed_geographic_energy",active:published,severity:severity,title:"Typed geographic route energy samples",
            value:risk?"sampled reserve risk":"sampled reserve met",
            evidence:[{id:"E_TYPED_P1",text:"finite energy samples; no landing modeled",value:{current_id:currentId,nominal_end_pct:result.nominal_end_pct,low_pct:result.low_pct,high_pct:result.high_pct,reserve_pct:result.reserve_pct}}],
            candidates:[],rule_choice:null,lead_s:null}
        Object.assign(result,{sequence:sequence,active:published,finding:finding,raise_streak:raising,clear_streak:clearing,raise_ticks:raiseTicks,clear_ticks:clearTicks})
        return geographicAlertSnapshot(result)
    }}
}

// Explicit P1 feed. No legacy ENU fallback or external explanation call.
function createTypedGeographicAlertFeed(v,raiseTicks,clearTicks) {
    if(!v.airframe_profile||["fixed_wing","vtol_hybrid"].indexOf(airframeType(v))<0)
        throw new Error("typed feed requires an explicit FW/hybrid profile")
    if(raiseTicks===undefined)raiseTicks=3
    if(clearTicks===undefined)clearTicks=10
    typedPredictorInteger(raiseTicks,"raise_ticks",1,10000)
    typedPredictorInteger(clearTicks,"clear_ticks",1,10000)
    var vehicle=geographicAlertSnapshot(v),predictor=null,version=null,current=null,lastSequence=-1,lastTime=-1,active=null,severity=null
    return {tick:function(sequence,rec,candidates,currentId,missionVersion){
        typedPredictorInteger(sequence,"sequence",0,9007199254740991)
        if(sequence<=lastSequence)throw new Error("sequence must increase strictly")
        if(typeof missionVersion!=="string"||missionVersion.length<1||missionVersion.length>128||/[^A-Za-z0-9._:-]/.test(missionVersion))
            throw new Error("mission_version requires 1..128 ASCII version characters")
        if(!rec||typeof rec!=="object"||Array.isArray(rec))throw new Error("typed feed requires measured geographic telemetry")
        var required=["t_s","lat","lon","alt","air_heading_deg","battery_pct","wind_mps","wind_from"],tm={}
        required.forEach(function(k){
            if(!Object.prototype.hasOwnProperty.call(rec,k))throw new Error("typed feed missing measured telemetry field")
            tm[k]=routeNumber(rec[k],k)
        })
        routeNumber(tm.t_s,"t_s",0)
        if(tm.t_s<=lastTime)throw new Error("t_s must increase strictly")
        routeNumber(tm.lat,"lat",-75,75);routeNumber(tm.lon,"lon",-180,180)
        routeNumber(tm.alt,"alt",0);routeNumber(tm.battery_pct,"battery_pct",0,100);routeNumber(tm.wind_mps,"wind_mps",0)
        var items=geographicAlertSnapshot(candidates),pose={lat:tm.lat,lon:tm.lon,alt:tm.alt,air_heading_deg:tm.air_heading_deg}
        if(!Array.isArray(items)||items.length<1||items.length>16)throw new Error("typed feed requires 1..16 explicit alternatives")
        items.forEach(function(c){
            if(!c||typeof c!=="object"||!c.entry||Object.keys(c.entry).length!==4||
                !Object.keys(pose).every(function(k){return Object.prototype.hasOwnProperty.call(c.entry,k)&&c.entry[k]===pose[k]}))
                throw new Error("every candidate entry must equal measured geographic pose")
        })
        var changed=version!==null&&missionVersion!==version
        if(version===missionVersion&&currentId!==current)throw new Error("current_id change requires a new mission_version")
        var next=(!predictor||changed)?createGeographicEnergyAlertPredictor(vehicle,raiseTicks,clearTicks):predictor
        var result=next.tick(sequence,items,currentId,wind(tm.wind_mps,tm.wind_from),tm.battery_pct)
        var previous=changed?null:active,events=[]
        function event(kind,finding){
            var f=finding||{key:"typed_geographic_energy",active:null,severity:5,title:"Typed geographic energy status",
                value:"unassessed energy status",evidence:[],candidates:[],rule_choice:null,lead_s:null}
            events.push(Object.assign({},f,{t:tm.t_s,type:kind,status:result.status,sequence:sequence,mission_version:missionVersion,executable:false}))
        }
        if(changed)event("reset")
        if(result.active===null){if(previous!==null||version===null||changed)event("unknown")}
        else if(result.active){
            if(previous!==true)event("raise",result.finding)
            else if(result.finding.severity<severity)event("update",result.finding)
        }else if(previous===true)event("resolve",result.finding)
        else if(previous===null)event("known",result.finding)
        Object.assign(result,{mission_version:missionVersion,t_s:tm.t_s,events:events,
            unassessed_predictors:["P2","P3","P4","P5"],caller_scope:"explicit_geographic_P1_feed_only"})
        predictor=next;version=missionVersion;current=currentId;lastSequence=sequence;lastTime=tm.t_s;active=result.active
        severity=result.finding?result.finding.severity:null
        return geographicAlertSnapshot(result)
    }}
}

// Independent measured P5; existing P1 feed deliberately remains P1-only.
function typedWindOptions(options) {
    var cfg={window_s:180,min_samples:60,min_span_s:30,max_gap_s:30,horizon_s:300,min_slope_mps2:0.002,min_r2:0.6}
    if(options===undefined||options===null)options={}
    if(typeof options!=="object"||Array.isArray(options)||Object.keys(options).some(function(k){return !Object.prototype.hasOwnProperty.call(cfg,k)}))
        throw new Error("unsupported typed wind options")
    Object.keys(options).forEach(function(k){cfg[k]=options[k]})
    typedPredictorInteger(cfg.min_samples,"min_samples",2,601)
    routeNumber(cfg.window_s,"window_s",1e-6,86400)
    routeNumber(cfg.min_span_s,"min_span_s",1e-6,cfg.window_s)
    routeNumber(cfg.max_gap_s,"max_gap_s",1e-6,cfg.window_s)
    routeNumber(cfg.horizon_s,"horizon_s",0,86400)
    routeNumber(cfg.min_slope_mps2,"min_slope_mps2",0,1000)
    routeNumber(cfg.min_r2,"min_r2",0,1)
    return cfg
}

function typedWindLimit(v) {
    if(!v.airframe_profile||["fixed_wing","vtol_hybrid"].indexOf(airframeType(v))<0)
        throw new Error("typed wind requires an explicit FW/hybrid profile")
    return routeNumber(v.airframe_profile.limits.wind_limit_mps,"wind_limit_mps",0)
}

function typedWindMeasurement(rec) {
    if(!rec||typeof rec!=="object"||Array.isArray(rec)||
       !Object.prototype.hasOwnProperty.call(rec,"t_s")||!Object.prototype.hasOwnProperty.call(rec,"wind_mps"))
        throw new Error("measured t_s and wind_mps required")
    return {t_s:routeNumber(rec.t_s,"t_s",0,9007199254740991),wind_mps:routeNumber(rec.wind_mps,"wind_mps",0)}
}

function typedWindHistory(samples,cfg) {
    if(!Array.isArray(samples)||samples.length<1||samples.length>601)throw new Error("typed wind requires 1..601 measured samples")
    var points=samples.map(typedWindMeasurement)
    for(var i=1;i<points.length;i++)if(points[i].t_s<=points[i-1].t_s)throw new Error("measured time must increase strictly")
    var end=points[points.length-1].t_s
    points=points.filter(function(p){return p.t_s>=end-cfg.window_s})
    var cut=0
    for(var j=1;j<points.length;j++)if(points[j].t_s-points[j-1].t_s>cfg.max_gap_s)cut=j
    return points.slice(cut)
}

function typedWindTrendSnapshot(v,samples,options) {
    var cfg=typedWindOptions(options),limit=typedWindLimit(v),points=typedWindHistory(samples,cfg),latest=points[points.length-1]
    var span=latest.t_s-points[0].t_s
    var result={scope:"typed_P5_measured_speed_trend_only",status:"unknown",reason:"insufficient_samples",risk:null,
        limit_mps:limit,current_wind_mps:latest.wind_mps,sample_count:points.length,span_s:span,t_s:latest.t_s,
        trend_mps_per_s:null,fitted_now_mps:null,r2:null,lead_s:null,horizon_s:cfg.horizon_s,
        direction_predicted:false,probability_interval:false,sensor_validated:false,feasible:false,executable:false}
    if(latest.wind_mps>=limit){Object.assign(result,{status:"ok",reason:"observed_limit_reached",risk:true,lead_s:0});return geographicAlertSnapshot(result)}
    if(points.length<cfg.min_samples)return geographicAlertSnapshot(result)
    if(span<cfg.min_span_s){result.reason="insufficient_span";return geographicAlertSnapshot(result)}
    var xs=points.map(function(p){return p.t_s-latest.t_s}),ys=points.map(function(p){return p.wind_mps})
    function sum(a){return a.reduce(function(s,x){return s+x},0)}
    var mx=sum(xs)/xs.length,my=sum(ys)/ys.length,sxx=0,sxy=0,syy=0
    for(var i=0;i<points.length;i++){var dx=xs[i]-mx,dy=ys[i]-my;sxx+=dx*dx;sxy+=dx*dy;syy+=dy*dy}
    var slope=routeNumber(sxy/sxx,"trend slope"),fitted=routeNumber(my-slope*mx,"fitted wind")
    var r2=syy===0?1:Math.max(0,Math.min(1,sxy*sxy/(sxx*syy)))
    Object.assign(result,{trend_mps_per_s:slope,fitted_now_mps:fitted,r2:r2})
    if(syy===0)Object.assign(result,{status:"ok",reason:"constant_wind",risk:false})
    else if(r2<cfg.min_r2)result.reason="trend_fit_unreliable"
    else if(slope<=cfg.min_slope_mps2)Object.assign(result,{status:"ok",reason:"trend_not_rising",risk:false})
    else{
        var lead=routeNumber(Math.max(0,(limit-fitted)/slope),"lead_s",0),risk=lead<=cfg.horizon_s
        Object.assign(result,{status:"ok",reason:risk?"crossing_within_horizon":"crossing_beyond_horizon",risk:risk,lead_s:lead})
    }
    return geographicAlertSnapshot(result)
}

function createTypedWindTrendPredictor(v,options,raiseTicks,clearTicks) {
    typedWindLimit(v)
    var vehicle=geographicAlertSnapshot(v),cfg=typedWindOptions(options)
    if(raiseTicks===undefined)raiseTicks=3
    if(clearTicks===undefined)clearTicks=10
    typedPredictorInteger(raiseTicks,"raise_ticks",1,10000);typedPredictorInteger(clearTicks,"clear_ticks",1,10000)
    function branch(lastSequence,lastTime,version,history,active,severity,raising,clearing) {
    return {fork:function(){return branch(lastSequence,lastTime,version,geographicAlertSnapshot(history),active,severity,raising,clearing)},tick:function(sequence,rec,missionVersion){
        typedPredictorInteger(sequence,"sequence",0,9007199254740991)
        if(sequence<=lastSequence)throw new Error("sequence must increase strictly")
        if(typeof missionVersion!=="string"||missionVersion.length<1||missionVersion.length>128||/[^A-Za-z0-9._:-]/.test(missionVersion))
            throw new Error("mission_version requires 1..128 ASCII version characters")
        var tm=typedWindMeasurement(rec)
        if(tm.t_s<=lastTime)throw new Error("t_s must increase strictly")
        var changed=version!==null&&missionVersion!==version,gap=lastTime>=0&&tm.t_s-lastTime>cfg.max_gap_s,reset=changed||gap
        var nextHistory=typedWindHistory((reset?[]:history).concat([tm]).slice(-601),cfg)
        var result=typedWindTrendSnapshot(vehicle,nextHistory,cfg),previous=reset?null:active
        var nextActive=reset||active===null?false:active,nextRaise=reset?0:raising,nextClear=reset?0:clearing
        if(result.status!=="ok"){nextActive=null;nextRaise=0;nextClear=0}
        else if(result.risk){nextRaise=Math.min(nextRaise+1,raiseTicks);nextClear=0;nextActive=nextActive||nextRaise>=raiseTicks}
        else{nextRaise=0;nextClear=Math.min(nextClear+1,clearTicks);if(nextClear>=clearTicks)nextActive=false}
        var nextSeverity=nextActive&&tm.wind_mps>=result.limit_mps?2:(nextActive?4:5)
        var finding={key:"typed_wind_trend",active:nextActive,severity:nextSeverity,title:"Measured wind speed trend",value:result.reason,
            evidence:[{id:"E_TYPED_P5",text:"conditional finite-window speed trend",value:{current_wind_mps:result.current_wind_mps,
                limit_mps:result.limit_mps,trend_mps_per_s:result.trend_mps_per_s,r2:result.r2,lead_s:result.lead_s}}],
            candidates:[],rule_choice:null,lead_s:result.lead_s},events=[]
        function event(kind){
            events.push(Object.assign({},finding,{type:kind,t:tm.t_s,status:result.status,sequence:sequence,mission_version:missionVersion,executable:false}))
            if(kind==="reset")Object.assign(events[events.length-1],{active:null,severity:5,value:"history and latch reset",evidence:[],lead_s:null})
        }
        if(reset)event("reset")
        if(nextActive===null){if(previous!==null||version===null||reset)event("unknown")}
        else if(nextActive){if(previous!==true)event("raise");else if(nextSeverity<severity)event("update")}
        else if(previous===true)event("resolve")
        else if(previous===null)event("known")
        Object.assign(result,{sequence:sequence,mission_version:missionVersion,active:nextActive,raise_streak:nextRaise,clear_streak:nextClear,
            finding:finding,events:events,reset_reason:changed?"mission_version_changed":(gap?"telemetry_gap":null)})
        var detached=geographicAlertSnapshot(result)
        lastSequence=sequence;lastTime=tm.t_s;version=missionVersion;history=nextHistory;active=nextActive;severity=nextSeverity;raising=nextRaise;clearing=nextClear
        return detached
    }}
    }
    return branch(-1,-1,null,[],null,null,0,0)
}

// T5b2h1: independent measured P4; explicit distances/probes, no route or action.
function typedLinkIdentity(value,name) {
    if(typeof value!=="string"||value.length<1||value.length>128||/[^A-Za-z0-9._:-]/.test(value))
        throw new Error(name+" requires 1..128 ASCII identity characters")
    return value
}
function typedLinkProfile(v) {
    if(!v.airframe_profile||["fixed_wing","vtol_hybrid"].indexOf(airframeType(v))<0)
        throw new Error("typed link requires an explicit FW/hybrid profile")
}
function typedLinkOptions(options) {
    var cfg={window_s:180,min_samples:60,min_distance_span_m:300,max_gap_s:30,horizon_s:300,
        min_r2:0.5,link_min_pct:35,max_extrapolation_m:0}
    if(options===undefined||options===null)options={}
    profileObject(options,"typed link options")
    Object.keys(options).forEach(function(k){if(!Object.prototype.hasOwnProperty.call(cfg,k))throw new Error("unsupported typed link options");cfg[k]=options[k]})
    typedPredictorInteger(cfg.min_samples,"min_samples",2,601)
    routeNumber(cfg.window_s,"window_s",1e-6,86400);routeNumber(cfg.max_gap_s,"max_gap_s",1e-6,cfg.window_s)
    routeNumber(cfg.min_distance_span_m,"min_distance_span_m",1e-6,10000)
    routeNumber(cfg.horizon_s,"horizon_s",0,86400);routeNumber(cfg.min_r2,"min_r2",0,1)
    routeNumber(cfg.link_min_pct,"link_min_pct",0,100);routeNumber(cfg.max_extrapolation_m,"max_extrapolation_m",0,10000)
    return cfg
}
function typedLinkMeasurement(rec) {
    profileObject(rec,"measured link telemetry")
    return {t_s:routeNumber(rec.t_s,"t_s",0,9007199254740991),
        distance_m:routeNumber(rec.distance_m,"distance_m",0,10000),link_pct:routeNumber(rec.link_pct,"link_pct",0,100)}
}
function typedLinkHistory(samples,cfg) {
    if(!Array.isArray(samples)||samples.length<1||samples.length>601)throw new Error("typed link requires 1..601 measured samples")
    var pts=samples.map(typedLinkMeasurement),cut=0
    for(var i=1;i<pts.length;i++)if(pts[i].t_s<=pts[i-1].t_s)throw new Error("measured time must increase strictly")
    pts=pts.filter(function(p){return p.t_s>=pts[pts.length-1].t_s-cfg.window_s})
    for(var j=1;j<pts.length;j++)if(pts[j].t_s-pts[j-1].t_s>cfg.max_gap_s)cut=j
    return pts.slice(cut)
}
function typedLinkProbes(probes) {
    var items=geographicAlertSnapshot(probes)
    if(!Array.isArray(items)||items.length<1||items.length>1000)throw new Error("typed link requires 1..1000 explicit probes")
    var seen=[],previous=-1
    items.forEach(function(p){
        profileObject(p,"probe")
        if(Object.keys(p).sort().join(",")!=="distance_m,eta_s,id")throw new Error("probe requires exactly id, distance_m and eta_s")
        var id=typedLinkIdentity(p.id,"probe id")
        if(seen.indexOf(id)>=0)throw new Error("probe id must be unique")
        seen.push(id);routeNumber(p.distance_m,"probe distance_m",0,10000)
        var eta=routeNumber(p.eta_s,"probe eta_s",0,86400)
        if(eta<=previous)throw new Error("probe eta_s must increase strictly")
        previous=eta
    })
    return items
}
function typedLinkDistanceSnapshot(v,referenceId,samples,probes,options) {
    typedLinkProfile(v);typedLinkIdentity(referenceId,"reference_id")
    var cfg=typedLinkOptions(options),pts=typedLinkHistory(samples,cfg),targets=typedLinkProbes(probes),latest=pts[pts.length-1]
    var distances=pts.map(function(p){return p.distance_m}),lo=Math.min.apply(null,distances),hi=Math.max.apply(null,distances)
    var result={scope:"typed_P4_caller_referenced_distance_probes_only",reference_id:referenceId,status:"unknown",risk:null,
        reason:"insufficient_samples",t_s:latest.t_s,current_link_pct:latest.link_pct,link_min_pct:cfg.link_min_pct,
        sample_count:pts.length,distance_min_m:lo,distance_max_m:hi,distance_span_m:hi-lo,slope_pct_per_m:null,r2:null,
        first_probe_id:null,lead_s:null,probes:[],distance_reference_verified:false,eta_verified:false,
        geometry_evaluated:false,landing_modeled:false,probability_interval:false,sensor_validated:false,feasible:false,executable:false}
    if(latest.link_pct<=cfg.link_min_pct){Object.assign(result,{status:"ok",risk:true,reason:"observed_limit_reached",lead_s:0});return geographicAlertSnapshot(result)}
    if(pts.length<cfg.min_samples)return geographicAlertSnapshot(result)
    if(hi-lo<cfg.min_distance_span_m){result.reason="insufficient_distance_span";return geographicAlertSnapshot(result)}
    var xs=pts.map(function(p){return p.distance_m-latest.distance_m}),ys=pts.map(function(p){return p.link_pct})
    function sum(a){return a.reduce(function(s,x){return s+x},0)}
    var mx=sum(xs)/xs.length,my=sum(ys)/ys.length,sxx=0,sxy=0,syy=0
    for(var i=0;i<pts.length;i++){var dx=xs[i]-mx,dy=ys[i]-my;sxx+=dx*dx;sxy+=dx*dy;syy+=dy*dy}
    var slope=routeNumber(sxy/sxx,"link slope"),fitted=routeNumber(my-slope*mx,"fitted current link")
    var r2=syy===0?1:Math.max(0,Math.min(1,sxy*sxy/(sxx*syy)))
    Object.assign(result,{slope_pct_per_m:slope,r2:r2})
    if(r2<cfg.min_r2||slope>0){result.reason=r2<cfg.min_r2?"distance_fit_unreliable":"distance_fit_increasing";return geographicAlertSnapshot(result)}
    targets.forEach(function(p){
        var row={id:p.id,distance_m:p.distance_m,eta_s:p.eta_s,status:"ok",predicted_link_pct:null,risk:null}
        if(p.eta_s>cfg.horizon_s)Object.assign(row,{status:"unsupported",reason:"beyond_horizon"})
        else if(p.distance_m<lo-cfg.max_extrapolation_m||p.distance_m>hi+cfg.max_extrapolation_m)
            Object.assign(row,{status:"unsupported",reason:"outside_distance_envelope"})
        else{var q=routeNumber(fitted+slope*(p.distance_m-latest.distance_m),"predicted link");Object.assign(row,{predicted_link_pct:q,risk:q<=cfg.link_min_pct})}
        result.probes.push(row)
    })
    if(result.probes.some(function(p){return p.status!=="ok"}))result.reason="one_or_more_probes_unsupported"
    else{
        var first=null
        for(var j=0;j<result.probes.length;j++)if(result.probes[j].risk){first=result.probes[j];break}
        Object.assign(result,{status:"ok",risk:first!==null,reason:first?"probe_limit_reached":"probes_above_limit",
            first_probe_id:first?first.id:null,lead_s:first?first.eta_s:null})
    }
    return geographicAlertSnapshot(result)
}
function createTypedLinkDistancePredictor(v,referenceId,options,raiseTicks,clearTicks) {
    typedLinkProfile(v);typedLinkIdentity(referenceId,"reference_id")
    var vehicle=geographicAlertSnapshot(v),cfg=typedLinkOptions(options)
    if(raiseTicks===undefined)raiseTicks=3
    if(clearTicks===undefined)clearTicks=10
    typedPredictorInteger(raiseTicks,"raise_ticks",1,10000);typedPredictorInteger(clearTicks,"clear_ticks",1,10000)
    function branch(lastSequence,lastTime,version,history,active,severity,raising,clearing) {
    return {fork:function(){return branch(lastSequence,lastTime,version,geographicAlertSnapshot(history),active,severity,raising,clearing)},tick:function(sequence,rec,probes,missionVersion){
        typedPredictorInteger(sequence,"sequence",0,9007199254740991)
        if(sequence<=lastSequence)throw new Error("sequence must increase strictly")
        typedLinkIdentity(missionVersion,"mission_version")
        var tm=typedLinkMeasurement(rec)
        if(tm.t_s<=lastTime)throw new Error("t_s must increase strictly")
        var changed=version!==null&&missionVersion!==version,gap=lastTime>=0&&tm.t_s-lastTime>cfg.max_gap_s,reset=changed||gap
        var nextHistory=typedLinkHistory((reset?[]:history).concat([tm]).slice(-601),cfg)
        var result=typedLinkDistanceSnapshot(vehicle,referenceId,nextHistory,probes,cfg),previous=reset?null:active
        var nextActive=reset||active===null?false:active,nextRaise=reset?0:raising,nextClear=reset?0:clearing
        if(result.status!=="ok"){nextActive=null;nextRaise=0;nextClear=0}
        else if(result.risk){nextRaise=Math.min(nextRaise+1,raiseTicks);nextClear=0;nextActive=nextActive||nextRaise>=raiseTicks}
        else{nextRaise=0;nextClear=Math.min(nextClear+1,clearTicks);if(nextClear>=clearTicks)nextActive=false}
        var nextSeverity=nextActive&&tm.link_pct<=result.link_min_pct?2:(nextActive?4:5)
        var evidence={}
        ;["reference_id","current_link_pct","link_min_pct","slope_pct_per_m","r2","first_probe_id","lead_s"].forEach(function(k){evidence[k]=result[k]})
        var finding={key:"typed_link_distance",active:nextActive,severity:nextSeverity,title:"Measured link quality by distance",value:result.reason,
            evidence:[{id:"E_TYPED_P4",text:"conditional explicit-distance probe fit",value:evidence}],candidates:[],rule_choice:null,lead_s:result.lead_s},events=[]
        function event(kind){
            var e=Object.assign({},finding,{type:kind,t:tm.t_s,status:result.status,sequence:sequence,mission_version:missionVersion,executable:false})
            if(kind==="reset")Object.assign(e,{active:null,severity:5,value:"history and latch reset",evidence:[],lead_s:null})
            events.push(e)
        }
        if(reset)event("reset")
        if(nextActive===null){if(previous!==null||version===null||reset)event("unknown")}
        else if(nextActive){if(previous!==true)event("raise");else if(nextSeverity<severity)event("update")}
        else if(previous===true)event("resolve")
        else if(previous===null)event("known")
        Object.assign(result,{sequence:sequence,mission_version:missionVersion,active:nextActive,raise_streak:nextRaise,clear_streak:nextClear,
            finding:finding,events:events,reset_reason:changed?"mission_version_changed":(gap?"telemetry_gap":null)})
        var detached=geographicAlertSnapshot(result)
        lastSequence=sequence;lastTime=tm.t_s;version=missionVersion;history=nextHistory;active=nextActive;severity=nextSeverity;raising=nextRaise;clearing=nextClear
        return detached
    }}
    }
    return branch(-1,-1,null,[],null,null,0,0)
}
// Additive P2: explicit ordered outbound-prefix/return samples, no action.
function typedReturnKeys(obj,keys,name) {
    if(!obj||typeof obj!=="object"||Array.isArray(obj)||Object.keys(obj).length!==keys.length||!keys.every(function(k){return Object.prototype.hasOwnProperty.call(obj,k)}))throw new Error(name+" requires exactly "+keys.join(", "))
}
function typedReturnEqual(a,b) {
    if(a===b)return true
    if(!a||!b||typeof a!=="object"||typeof b!=="object"||Array.isArray(a)!==Array.isArray(b))return false
    var ka=Object.keys(a),kb=Object.keys(b)
    return ka.length===kb.length&&ka.every(function(k){return Object.prototype.hasOwnProperty.call(b,k)&&typedReturnEqual(a[k],b[k])})
}
function typedReturnRequest(entry,target,probes) {
    var request=geographicAlertSnapshot({entry:entry,target:target,probes:probes})
    entry=request.entry;target=request.target;probes=request.probes
    typedReturnKeys(entry,["lat","lon","alt","air_heading_deg"],"entry")
    typedReturnKeys(target,["lat","lon","alt","tolerance_m"],"recovery target")
    ;[["entry",entry],["target",target]].forEach(function(pair){routeNumber(pair[1].lat,pair[0]+" lat",-75,75);routeNumber(pair[1].lon,pair[0]+" lon",-180,180);routeNumber(pair[1].alt,pair[0]+" alt",0)})
    routeNumber(entry.air_heading_deg,"air_heading_deg");routeNumber(target.tolerance_m,"tolerance_m",0,100)
    if(target.alt!==entry.alt)throw new Error("P2 recovery target must be at the entry flight altitude")
    if(!Array.isArray(probes)||probes.length<1||probes.length>16)throw new Error("P2 requires 1..16 explicit return probes")
    var seen=[],previous=[],total=0
    probes.forEach(function(p){
        typedReturnKeys(p,["id","outbound_events","return_events"],"probe")
        if(typeof p.id!=="string"||Array.from(p.id).length<1||Array.from(p.id).length>128||seen.indexOf(p.id)>=0)throw new Error("probe id must be unique, nonempty, at most 128 characters")
        seen.push(p.id)
        var out=p.outbound_events,ret=p.return_events
        if([out,ret].some(function(x){return !Array.isArray(x)||!x.length}))throw new Error("probe requires nonempty outbound and return event lists")
        if(out.length<=previous.length||!typedReturnEqual(out.slice(0,previous.length),previous))throw new Error("outbound events must strictly extend the previous prefix")
        if(out.concat(ret).some(function(e){return !e||typeof e!=="object"||Array.isArray(e)||typeof e.kind!=="string"}))throw new Error("probe events require objects with kind")
        total+=out.length+ret.length;if(total>1000)throw new Error("P2 batch exceeds 1000 total replayed events")
        previous=out
    })
    return request
}
function typedReturnEndpointError(pose,target,origin) {
    var metres=Math.PI*6371000/180,dl=((pose.lon-target.lon+180)%360+360)%360-180
    return Math.hypot(dl*metres*Math.cos(origin.lat*Math.PI/180),(pose.lat-target.lat)*metres)
}
function typedReturnProbeSnapshot(v,entry,target,probes,w,startPct,mode) {
    if(!v.airframe_profile||["fixed_wing","vtol_hybrid"].indexOf(airframeType(v))<0)throw new Error("typed return probes require an explicit FW/hybrid profile")
    var active=flightMode(v,mode)
    if(active!=="fw")throw new Error("typed return probes require explicit FW flight")
    routeWind(w);if(startPct===undefined)startPct=100;routeNumber(startPct,"start_pct",0,100)
    var request=typedReturnRequest(entry,target,probes);entry=request.entry;target=request.target
    var rows=request.probes.map(function(p){
        var split=p.outbound_events.length,interval=geographicWindRouteBounds(v,entry,p.outbound_events.concat(p.return_events),w,startPct,active)
        var scenarios=interval.scenarios.map(function(s){
            var row={id:s.id,status:s.status,endpoint_supported:false,wind:s.wind,power_multiplier:s.power_multiplier,capacity_multiplier:s.capacity_multiplier}
            if(s.status==="ok"){
                var e=s.base_estimate,error=typedReturnEndpointError(e.exit_geographic,target,entry)
                Object.assign(row,{endpoint_supported:error<=target.tolerance_m&&e.exit_geographic.alt===target.alt,endpoint_error_m:error,
                    exit_geographic:e.exit_geographic,probe_geographic:e.legs[split-1].exit_geographic,
                    eta_s:e.legs.slice(0,split).reduce(function(sum,leg){return sum+leg.time_s},0),end_pct:s.end_pct})
            }else row.reason=s.reason
            return row
        }),known=interval.available&&scenarios.every(function(s){return s.endpoint_supported}),nominal=scenarios[0]
        return {id:p.id,status:known?"ok":"unknown",reason:known?"finite_probe_supported":"route_or_recovery_endpoint_unsupported",outbound_event_count:split,
            sampled_energy_risk:known?interval.low_pct<v.reserve_pct:null,low_pct:known?interval.low_pct:null,high_pct:known?interval.high_pct:null,
            nominal_eta_s:nominal.eta_s===undefined?null:nominal.eta_s,scenarios:scenarios,bounds:interval}
    }),known=rows.every(function(r){return r.status==="ok"}),first=null,last=null,reentry=false
    if(known)rows.forEach(function(r){if(r.sampled_energy_risk){if(first===null)first=r}else if(first===null)last=r;else reentry=true})
    return geographicAlertSnapshot({scope:"typed_P2_explicit_return_probe_samples_only",status:known?"ok":"unknown",entry:entry,target:target,mode:active,start_pct:startPct,reserve_pct:v.reserve_pct,
        probes:rows,sampled_energy_risk:known?first!==null:null,first_sampled_infeasible_id:first?first.id:null,
        first_sampled_infeasible_nominal_eta_s:first?first.nominal_eta_s:null,last_sampled_feasible_prefix_id:last?last.id:null,
        sampled_feasibility_reentry:known?reentry:null,sampled_endpoint_constraint_met:known,continuous_boundary_known:false,return_inferred:false,
        recovery_reference_verified:false,landing_modeled:false,wind_direction_varied:false,feasible:false,executable:false,candidates:[],rule_choice:null})
}

// Atomic P1/P2 explicit samples. No continuous return deadline or actions.
function missionSampleMeasurement(rec) {
    if(!rec||typeof rec!=="object"||Array.isArray(rec))throw new Error("measured geographic telemetry required")
    var fields=["t_s","lat","lon","alt","air_heading_deg","battery_pct","wind_mps","wind_from","mode"],tm={}
    fields.forEach(function(k){if(!Object.prototype.hasOwnProperty.call(rec,k))throw new Error("missing measured telemetry field");tm[k]=rec[k]})
    tm=geographicAlertSnapshot(tm)
    fields.slice(0,-1).forEach(function(k){routeNumber(tm[k],k)})
    routeNumber(tm.t_s,"t_s",0,9007199254740991);routeNumber(tm.lat,"lat",-75,75);routeNumber(tm.lon,"lon",-180,180)
    routeNumber(tm.alt,"alt",0);routeNumber(tm.battery_pct,"battery_pct",0,100);routeNumber(tm.wind_mps,"wind_mps",0)
    if(tm.mode!=="fw")throw new Error("measured mode must explicitly be fw")
    return tm
}
function missionSampleRequest(request,pose) {
    var r=geographicAlertSnapshot(request)
    typedReturnKeys(r,["mission_version","recovery_reference_id","p1","p2"],"mission sample request")
    typedLinkIdentity(r.mission_version,"mission_version");typedLinkIdentity(r.recovery_reference_id,"recovery_reference_id")
    typedReturnKeys(r.p1,["current_id","candidates"],"p1");typedReturnKeys(r.p2,["target","probes","mode"],"p2")
    if(r.p2.mode!=="fw")throw new Error("p2 mode must match measured fw mode")
    var items=r.p1.candidates
    if(!Array.isArray(items)||items.length<1||items.length>16)throw new Error("p1 requires 1..16 explicit alternatives")
    items.forEach(function(c){
        if(!c||typeof c!=="object"||Array.isArray(c)||!typedReturnEqual(c.entry,pose))throw new Error("every p1 entry must equal the measured pose")
        if(c.mode!=="fw")throw new Error("every p1 candidate requires explicit measured fw mode")
    })
    var current=items.filter(function(c){return c.id===r.p1.current_id})[0]
    if(!current||!Array.isArray(current.events)||!current.events.length)throw new Error("current_id must identify a nonempty explicit current route")
    var probes=r.p2.probes
    if(!Array.isArray(probes)||probes.length<1||probes.length>16)throw new Error("p2 requires 1..16 explicit return probes")
    probes.forEach(function(p){
        var out=p&&typeof p==="object"&&!Array.isArray(p)?p.outbound_events:null
        if(!Array.isArray(out)||!out.length||out.length>current.events.length||!typedReturnEqual(out,current.events.slice(0,out.length)))
            throw new Error("every P2 outbound must prefix the current P1 route")
    })
    return r
}
function missionSampleEmptyLatch(){return {active:null,severity:5,raise:0,clear:0}}
function missionSampleReduce(code,snapshot,previous,reset,raiseTicks,clearTicks,context) {
    var old=reset?missionSampleEmptyLatch():previous,known=snapshot.status==="ok",risk=snapshot.sampled_energy_risk
    var active=old.active,raising=old.raise,clearing=old.clear
    if(!known){active=null;raising=0;clearing=0}
    else if(risk){raising=Math.min(raising+1,raiseTicks);clearing=0;active=active===true||raising>=raiseTicks}
    else{raising=0;clearing=Math.min(clearing+1,clearTicks);active=active===true&&clearing<clearTicks}
    var severity=active!==true?5:(code==="P1"&&snapshot.nominal_end_pct<0?2:4)
    var value=risk===true?"sampled_risk":(known?"sampled_reserve_met":"unknown_samples")
    if(active===true&&risk===false)value="sampled_risk_latched_pending_clear"
    var keys=code==="P1"?["current_id","nominal_end_pct","low_pct","high_pct","reserve_pct"]:
        ["first_sampled_infeasible_id","first_sampled_infeasible_nominal_eta_s","last_sampled_feasible_prefix_id","sampled_feasibility_reentry","reserve_pct"],evidence={}
    if(known)keys.forEach(function(k){evidence[k]=snapshot[k]})
    var finding={key:"typed_mission_sample_"+code.toLowerCase(),predictor:code,active:active,severity:severity,title:code+" explicit energy samples",
        value:value,evidence:known?[{id:"E_TYPED_"+code+"_SAMPLES",text:"finite samples; no continuous deadline or landing",value:evidence}]:[],
        candidates:[],rule_choice:null,lead_s:null,executable:false},events=[]
    function event(kind){
        var e=Object.assign({},finding,context,{type:kind,status:known?"ok":"unknown"})
        if(kind==="reset")Object.assign(e,{active:null,severity:5,value:"latch_reset",evidence:[]})
        events.push(e)
    }
    if(reset)event("reset")
    if(active===null){if(old.active!==null||context.initial||reset)event("unknown")}
    else if(active){if(old.active!==true)event("raise");else if(severity<old.severity)event("update")}
    else if(old.active===true)event("resolve")
    else if(old.active===null)event("known")
    return {result:{status:known?"ok":"unknown",sampled_energy_risk:risk,active:active,raise_streak:raising,clear_streak:clearing,
        raise_ticks:raiseTicks,clear_ticks:clearTicks,finding:finding,snapshot:snapshot},
        state:{active:active,severity:severity,raise:raising,clear:clearing},events:events}
}
function createTypedMissionSampleFeed(v,raiseTicks,clearTicks,maxGapS) {
    if(!v.airframe_profile||["fixed_wing","vtol_hybrid"].indexOf(airframeType(v))<0)throw new Error("typed mission samples require explicit FW/hybrid profile")
    if(raiseTicks===undefined)raiseTicks=3
    if(clearTicks===undefined)clearTicks=10
    if(maxGapS===undefined)maxGapS=30
    typedPredictorInteger(raiseTicks,"raise_ticks",1,10000);typedPredictorInteger(clearTicks,"clear_ticks",1,10000);routeNumber(maxGapS,"max_gap_s",1e-6,86400)
    var vehicle=geographicAlertSnapshot(v)
    function branch(lastSequence,lastTime,lastRequest,latches){
    return {fork:function(){return branch(lastSequence,lastTime,geographicAlertSnapshot(lastRequest),geographicAlertSnapshot(latches))},tick:function(sequence,rec,request){
        typedPredictorInteger(sequence,"sequence",0,9007199254740991)
        if(sequence<=lastSequence)throw new Error("sequence must increase strictly")
        var tm=missionSampleMeasurement(rec)
        if(tm.t_s<=lastTime)throw new Error("t_s must increase strictly")
        var pose={lat:tm.lat,lon:tm.lon,alt:tm.alt,air_heading_deg:tm.air_heading_deg},r=missionSampleRequest(request,pose)
        var initial=lastRequest===null,changed=!initial&&r.mission_version!==lastRequest.mission_version
        if(!initial&&!changed&&(r.p1.current_id!==lastRequest.p1.current_id||r.recovery_reference_id!==lastRequest.recovery_reference_id||!typedReturnEqual(r.p2.target,lastRequest.p2.target)))
            throw new Error("current route/recovery identity or target change requires new mission_version")
        var reasons=changed?["mission_version_changed"]:[]
        if(lastTime>=0&&tm.t_s-lastTime>maxGapS)reasons.push("telemetry_gap")
        var w=wind(tm.wind_mps,tm.wind_from)
        // Evaluate both before reducing/committing either latch.
        var snapshots={P1:geographicEnergyAlertSnapshot(vehicle,r.p1.candidates,r.p1.current_id,w,tm.battery_pct),
            P2:typedReturnProbeSnapshot(vehicle,pose,r.p2.target,r.p2.probes,w,tm.battery_pct,r.p2.mode)}
        var context={sequence:sequence,t:tm.t_s,mission_version:r.mission_version,recovery_reference_id:r.recovery_reference_id,
            initial:initial,continuous_boundary_known:false,latest_return_deadline_s:null},results={},states={},events=[]
        ;["P1","P2"].forEach(function(code){
            var reduced=missionSampleReduce(code,snapshots[code],latches[code],reasons.length>0,raiseTicks,clearTicks,context)
            results[code]=reduced.result;states[code]=reduced.state;events=events.concat(reduced.events)
        })
        var output=geographicAlertSnapshot({caller_scope:"atomic_measured_P1_P2_explicit_samples_only",
            status:results.P1.status==="ok"&&results.P2.status==="ok"?"ok":"unknown",sequence:sequence,t_s:tm.t_s,mission_version:r.mission_version,
            recovery_reference_id:r.recovery_reference_id,mode:tm.mode,predictors:results,events:events,reset_reasons:reasons,
            evaluated_predictors:["P1","P2"],unassessed_predictors:["P3","P4","P5"],continuous_boundary_known:false,latest_return_deadline_s:null,
            return_now_evaluated:false,recovery_reference_verified:false,telemetry_freshness_verified:false,landing_modeled:false,
            feasible:false,executable:false,candidates:[],rule_choice:null})
        lastSequence=sequence;lastTime=tm.t_s;lastRequest=r;latches=states
        return output
    }}
    }
    return branch(-1,-1,null,{P1:missionSampleEmptyLatch(),P2:missionSampleEmptyLatch()})
}

// P3 finite-window hypothesis only; explicit chemistry and discharging session.
function typedBatteryCapacitySnapshot(v, samples, options) {
    var defaults={min_samples:90,min_energy_span_fraction:0.08,min_r2:0.8,max_gap_s:30,min_fall_v_per_wh:1e-6,capacity_ratio_limit:0.9,soc_gap_limit_pct:3};
    function fail(s){throw new Error(s);}
    function num(x,s,lo,hi){if(typeof x!=="number"||!isFinite(x)||x<lo||x>hi)fail(s);return x;}
    function integer(x,s,lo,hi){num(x,s,lo,hi);if(Math.floor(x)!==x)fail(s);}
    function object(x){return x!==null&&typeof x==="object"&&!Array.isArray(x);}
    function keys(x,required){if(!object(x)||Object.keys(x).sort().join("|")!==required.slice().sort().join("|"))fail("invalid sample keys");}
    function identity(x){if(typeof x!=="string"||x.length<1||x.length>128||/[^A-Za-z0-9._:-]/.test(x))fail("battery_id");}
    if(!v.airframe_profile||["fixed_wing","vtol_hybrid"].indexOf(airframeType(v))<0)fail("typed capacity requires FW/hybrid profile");
    var nominal=num(v.battery_wh,"battery_wh",1e-6,1e9),cfg={},k;
    if(!object(options)||!Object.prototype.hasOwnProperty.call(options,"cell_r_ohm")||!Object.prototype.hasOwnProperty.call(options,"cell_empty_v"))fail("explicit chemistry required");
    Object.keys(defaults).forEach(function(key){cfg[key]=defaults[key];});
    Object.keys(options).forEach(function(key){if(!Object.prototype.hasOwnProperty.call(defaults,key)&&key!=="cell_r_ohm"&&key!=="cell_empty_v")fail("unsupported option");cfg[key]=options[key];});
    integer(cfg.min_samples,"min_samples",3,601);
    [["cell_r_ohm",0,1],["cell_empty_v",0.1,10],["min_energy_span_fraction",1e-6,1],["min_r2",0,1],["max_gap_s",1e-6,86400],["min_fall_v_per_wh",1e-12,10],["capacity_ratio_limit",1e-6,1],["soc_gap_limit_pct",0,100]].forEach(function(a){num(cfg[a[0]],a[0],a[1],a[2]);});
    if(!Array.isArray(samples)||samples.length<1||samples.length>601)fail("1..601 samples required");
    var fields=["t_s","battery_id","used_wh","voltage","current_a","cell_count","battery_pct"],gap=false,volts=[],i,row;
    for(i=0;i<samples.length;i++){
        row=samples[i];keys(row,fields);identity(row.battery_id);integer(row.cell_count,"cell_count",1,100);
        [["t_s",0,9007199254740991],["used_wh",0,1e9],["voltage",1e-6,1000],["current_a",0,10000],["battery_pct",0,100]].forEach(function(a){num(row[a[0]],a[0],a[1],a[2]);});
        if(row.battery_id!==samples[0].battery_id||row.cell_count!==samples[0].cell_count)fail("mixed battery/cell identity");
        if(i){if(row.t_s<=samples[i-1].t_s||row.used_wh<samples[i-1].used_wh)fail("unordered samples");gap=gap||row.t_s-samples[i-1].t_s>cfg.max_gap_s;}
        volts.push(num(row.voltage/row.cell_count+row.current_a*cfg.cell_r_ohm,"compensated cell voltage",0.1,10));
    }
    var latest=samples[samples.length-1],out={predictor:"P3",status:"unknown",reason:"insufficient_samples",risk:null,battery_id:latest.battery_id,cell_count:latest.cell_count,sample_count:samples.length,energy_span_wh:latest.used_wh-samples[0].used_wh,nominal_wh:nominal,compensated_cell_v:volts[volts.length-1],slope_v_per_wh:null,r2:null,estimated_total_wh:null,capacity_ratio:null,estimated_remaining_wh:null,soc_remaining_wh:latest.battery_pct/100*nominal,conservative_remaining_wh:null,soc_overestimate_pct:null,assumptions:cfg,measured_capacity:false,sensor_validated:false,probability_interval:false,energy_correction_applied:false,feasible:false,executable:false,candidates:[],rule_choice:null};
    if(gap){out.reason="telemetry_gap";return out;}
    if(samples.length<cfg.min_samples)return out;
    if(out.energy_span_wh<nominal*cfg.min_energy_span_fraction){out.reason="insufficient_energy_span";return out;}
    var xs=[],mx=0,my=0,sxx=0,syy=0,sxy=0;
    for(i=0;i<samples.length;i++){xs.push(samples[i].used_wh-samples[0].used_wh);mx+=xs[i];my+=volts[i];}
    mx/=samples.length;my/=samples.length;
    for(i=0;i<samples.length;i++){sxx+=Math.pow(xs[i]-mx,2);syy+=Math.pow(volts[i]-my,2);sxy+=(xs[i]-mx)*(volts[i]-my);}
    if(sxx<=1e-12||syy<=1e-12){out.reason="degenerate_fit";return out;}
    var slope=num(sxy/sxx,"capacity slope",-1e100,1e100),r2=Math.max(0,Math.min(1,sxy*sxy/(sxx*syy)));
    out.slope_v_per_wh=slope;out.r2=r2;
    if(slope>=-cfg.min_fall_v_per_wh||r2<cfg.min_r2){out.reason="capacity_fit_unreliable";return out;}
    var total=num(samples[0].used_wh+(cfg.cell_empty_v-(my-slope*mx))/slope,"estimated total Wh",-1e100,1e100);
    if(total<=latest.used_wh){out.reason="extrapolated_empty_reached";return out;}
    var remaining=total-latest.used_wh,conservative=Math.min(out.soc_remaining_wh,remaining),gapPct=(out.soc_remaining_wh-conservative)/nominal*100;
    var risk=total/nominal<cfg.capacity_ratio_limit&&gapPct>cfg.soc_gap_limit_pct;
    out.status="ok";out.reason=risk?"conditional_capacity_risk":"conditional_capacity_no_risk";out.risk=risk;
    out.estimated_total_wh=total;out.capacity_ratio=total/nominal;out.estimated_remaining_wh=remaining;out.conservative_remaining_wh=conservative;out.soc_overestimate_pct=gapPct;
    return out;
}


// Independent P3 caller: conditional overlapping windows, no P1/P2 mutation.
function createTypedCapacityFeed(v, options, raiseTicks, clearTicks, maxSamples) {
    if(!v.airframe_profile||["fixed_wing","vtol_hybrid"].indexOf(airframeType(v))<0)throw new Error("typed capacity feed requires FW/hybrid profile")
    routeNumber(v.battery_wh,"battery_wh",1e-6,1e9)
    var defaults={min_samples:90,min_energy_span_fraction:0.08,min_r2:0.8,max_gap_s:30,min_fall_v_per_wh:1e-6,capacity_ratio_limit:0.9,soc_gap_limit_pct:3}
    if(!options||typeof options!=="object"||Array.isArray(options)||!Object.prototype.hasOwnProperty.call(options,"cell_r_ohm")||!Object.prototype.hasOwnProperty.call(options,"cell_empty_v"))throw new Error("explicit chemistry options required")
    var cfg=Object.assign({},defaults)
    Object.keys(options).forEach(function(k){if(!Object.prototype.hasOwnProperty.call(defaults,k)&&k!=="cell_r_ohm"&&k!=="cell_empty_v")throw new Error("unsupported option");cfg[k]=options[k]})
    cfg=geographicAlertSnapshot(cfg)
    typedPredictorInteger(cfg.min_samples,"min_samples",3,601)
    ;[["cell_r_ohm",0,1],["cell_empty_v",0.1,10],["min_energy_span_fraction",1e-6,1],["min_r2",0,1],["max_gap_s",1e-6,86400],["min_fall_v_per_wh",1e-12,10],["capacity_ratio_limit",1e-6,1],["soc_gap_limit_pct",0,100]].forEach(function(a){routeNumber(cfg[a[0]],a[0],a[1],a[2])})
    raiseTicks=raiseTicks===undefined?3:raiseTicks;clearTicks=clearTicks===undefined?10:clearTicks;maxSamples=maxSamples===undefined?601:maxSamples
    typedPredictorInteger(raiseTicks,"raise_ticks",1,10000);typedPredictorInteger(clearTicks,"clear_ticks",1,10000);typedPredictorInteger(maxSamples,"max_samples",cfg.min_samples,601)
    function empty(){return {active:null,raise:0,clear:0}}
    var vehicle=geographicAlertSnapshot(v)
    function branch(lastSequence,lastTime,lastSession,history,latch){
    return {fork:function(){return branch(lastSequence,lastTime,lastSession,geographicAlertSnapshot(history),geographicAlertSnapshot(latch))},tick:function(sequence,rec,sessionId){
        typedPredictorInteger(sequence,"sequence",0,9007199254740991)
        if(sequence<=lastSequence)throw new Error("sequence must increase strictly")
        typedLinkIdentity(sessionId,"session_id")
        var row=geographicAlertSnapshot(rec)
        typedBatteryCapacitySnapshot(vehicle,[row],cfg)
        if(row.t_s<=lastTime)throw new Error("t_s must increase strictly across sessions")
        var initial=lastSession===null,changed=!initial&&sessionId!==lastSession,last=history.length?history[history.length-1]:null
        if(last&&!changed&&(row.battery_id!==last.battery_id||row.cell_count!==last.cell_count||row.used_wh<last.used_wh))throw new Error("battery/cell/counter change requires new session_id")
        var reasons=changed?["session_changed"]:[]
        if(lastTime>=0&&row.t_s-lastTime>cfg.max_gap_s)reasons.push("telemetry_gap")
        var rows=(reasons.length?[]:history).concat([row]).slice(-maxSamples),snapshot=typedBatteryCapacitySnapshot(vehicle,rows,cfg)
        var old=reasons.length?empty():latch,active=old.active,raising=old.raise,clearing=old.clear,known=snapshot.status==="ok",risk=snapshot.risk
        if(!known){active=null;raising=0;clearing=0}
        else if(risk){raising=Math.min(raising+1,raiseTicks);clearing=0;active=active===true||raising>=raiseTicks}
        else{raising=0;clearing=Math.min(clearing+1,clearTicks);active=active===true&&clearing<clearTicks}
        var value=active===true&&risk===false?"conditional_capacity_risk_latched_pending_clear":snapshot.reason,evidence={}
        if(known)["sample_count","energy_span_wh","capacity_ratio","soc_overestimate_pct","assumptions"].forEach(function(k){evidence[k]=snapshot[k]})
        var finding={key:"typed_capacity_P3",predictor:"P3",active:active,severity:active===true?4:5,title:"P3 conditional capacity hypothesis",value:value,
            evidence:known?[{id:"E_TYPED_P3_WINDOW",text:"conditional fit, overlapping windows; not measured capacity",value:evidence}]:[],lead_s:null,candidates:[],rule_choice:null,executable:false},events=[]
        function event(kind){
            var e=Object.assign({},finding,{type:kind,status:snapshot.status,sequence:sequence,t:row.t_s,session_id:sessionId,battery_id:row.battery_id})
            if(kind==="reset")Object.assign(e,{active:null,severity:5,value:"window_and_latch_reset",evidence:[]})
            events.push(e)
        }
        if(reasons.length)event("reset")
        if(active===null){if(old.active!==null||initial||reasons.length)event("unknown")}
        else if(active){if(old.active!==true)event("raise")}
        else if(old.active===true)event("resolve")
        else if(old.active===null)event("known")
        var output=geographicAlertSnapshot({caller_scope:"bounded_P3_only_conditional_capacity_feed",status:snapshot.status,sequence:sequence,t_s:row.t_s,session_id:sessionId,battery_id:row.battery_id,
            active:active,risk:risk,raise_streak:raising,clear_streak:clearing,raise_ticks:raiseTicks,clear_ticks:clearTicks,window_sample_count:rows.length,max_samples:maxSamples,
            snapshot:snapshot,finding:finding,events:events,reset_reasons:reasons,evaluated_predictors:["P3"],unassessed_predictors:["P1","P2","P4","P5"],
            measured_capacity:false,sensor_validated:false,telemetry_freshness_verified:false,independent_window_evidence:false,energy_correction_applied:false,landing_modeled:false,
            feasible:false,executable:false,candidates:[],rule_choice:null})
        lastSequence=sequence;lastTime=row.t_s;lastSession=sessionId;history=rows;latch={active:active,raise:raising,clear:clearing}
        return output
    }}
    }
    return branch(-1,-1,null,[],empty())
}


// P1/P2/P3 transactional caller. Other predictors remain visibly unassessed.
function createTypedMissionOrchestrator(v,capacityOptions,raiseTicks,clearTicks,maxGapS,maxSamples) {
    var mission=createTypedMissionSampleFeed(v,raiseTicks,clearTicks,maxGapS)
    var capacity=createTypedCapacityFeed(v,capacityOptions,raiseTicks,clearTicks,maxSamples)
    function branch(mission,capacity,lastSession,lastVersion) {
    return {fork:function(){return branch(mission.fork(),capacity.fork(),lastSession,lastVersion)},tick:function(sequence,measurement,request){
        var m=geographicAlertSnapshot(measurement),r=geographicAlertSnapshot(request)
        typedReturnKeys(m,["mission","capacity"],"orchestrator measurement")
        typedReturnKeys(r,["mission","capacity_session_id"],"orchestrator request")
        typedLinkIdentity(r.capacity_session_id,"capacity_session_id")
        function object(x){return x!==null&&typeof x==="object"&&!Array.isArray(x)}
        if(!object(m.mission)||!object(m.capacity)||!object(r.mission))throw new Error("mission/capacity objects required")
        ;["t_s","battery_pct"].forEach(function(k){
            if(!Object.prototype.hasOwnProperty.call(m.mission,k)||!Object.prototype.hasOwnProperty.call(m.capacity,k)||m.mission[k]!==m.capacity[k])
                throw new Error("mission and capacity require identical measured "+k)
        })
        var session=r.capacity_session_id
        if(lastSession!==null&&session!==lastSession&&r.mission.mission_version===lastVersion)throw new Error("battery session change requires new mission_version")
        var nextMission=mission.fork(),nextCapacity=capacity.fork()
        var a=nextMission.tick(sequence,m.mission,r.mission),b=nextCapacity.tick(sequence,m.capacity,session)
        var predictors={P1:a.predictors.P1,P2:a.predictors.P2,P3:b}
        var events=a.events.concat(b.events).map(function(e){return Object.assign({},e,{mission_version:a.mission_version,
            recovery_reference_id:a.recovery_reference_id,session_id:session,battery_id:b.battery_id})})
        var output=geographicAlertSnapshot({caller_scope:"atomic_measured_P1_P2_P3_only",
            status:["P1","P2","P3"].every(function(k){return predictors[k].status==="ok"})?"ok":"unknown",
            sequence:a.sequence,t_s:a.t_s,mission_version:a.mission_version,recovery_reference_id:a.recovery_reference_id,
            session_id:session,battery_id:b.battery_id,mode:a.mode,predictors:predictors,events:events,
            reset_reasons_by_predictor:{P1:a.reset_reasons,P2:a.reset_reasons,P3:b.reset_reasons},
            evaluated_predictors:["P1","P2","P3"],unassessed_predictors:["P4","P5"],
            continuous_boundary_known:false,latest_return_deadline_s:null,return_now_evaluated:false,
            recovery_reference_verified:false,telemetry_freshness_verified:false,measured_capacity:false,sensor_validated:false,
            independent_window_evidence:false,energy_correction_applied:false,landing_modeled:false,
            feasible:false,executable:false,candidates:[],rule_choice:null})
        mission=nextMission;capacity=nextCapacity;lastSession=session;lastVersion=a.mission_version
        return output
    }}
    }
    return branch(mission,capacity,null,null)
}

// Opt-in atomic measured P1-P5; no geometry, route, action or policy inference.
function createTypedFullMissionOrchestrator(v,capacityOptions,linkReferenceId,linkOptions,windOptions,raiseTicks,clearTicks,maxGapS,maxSamples) {
    var reference=typedLinkIdentity(linkReferenceId,"link_reference_id")
    var mission=createTypedMissionOrchestrator(v,capacityOptions,raiseTicks,clearTicks,maxGapS,maxSamples)
    var link=createTypedLinkDistancePredictor(v,reference,linkOptions,raiseTicks,clearTicks)
    var wind=createTypedWindTrendPredictor(v,windOptions,raiseTicks,clearTicks)
    return {tick:function(sequence,measurement,request){
        var m=geographicAlertSnapshot(measurement),r=geographicAlertSnapshot(request)
        typedReturnKeys(m,["mission","capacity","link","wind"],"full measurement")
        typedReturnKeys(r,["mission","capacity_session_id","link"],"full request")
        function object(x){return x!==null&&typeof x==="object"&&!Array.isArray(x)}
        if(!Object.keys(m).every(function(k){return object(m[k])})||!object(r.mission)||!object(r.link))throw new Error("full members must be objects")
        typedReturnKeys(r.link,["reference_id","probes"],"full link request")
        if(typedLinkIdentity(r.link.reference_id,"reference_id")!==reference)throw new Error("link reference change requires a new caller")
        if(!Object.keys(m).every(function(k){return Object.prototype.hasOwnProperty.call(m[k],"t_s")&&m[k].t_s===m.mission.t_s}))throw new Error("all predictors require identical measured t_s")
        if(!Object.prototype.hasOwnProperty.call(m.mission,"wind_mps")||!Object.prototype.hasOwnProperty.call(m.wind,"wind_mps")||m.mission.wind_mps!==m.wind.wind_mps)throw new Error("mission and P5 require identical measured wind_mps")
        var nextMission=mission.fork(),nextLink=link.fork(),nextWind=wind.fork()
        var a=nextMission.tick(sequence,{mission:m.mission,capacity:m.capacity},{mission:r.mission,capacity_session_id:r.capacity_session_id})
        var version=a.mission_version,p4=nextLink.tick(sequence,m.link,r.link.probes,version),p5=nextWind.tick(sequence,m.wind,version)
        var predictors=Object.assign({},a.predictors,{P4:p4,P5:p5}),events=a.events.slice(),resets=Object.assign({},a.reset_reasons_by_predictor)
        ;[["P4",p4],["P5",p5]].forEach(function(pair){
            var name=pair[0],result=pair[1]
            result.events.forEach(function(event){var e=Object.assign({},event,{predictor_id:name,mission_version:version,recovery_reference_id:a.recovery_reference_id,session_id:a.session_id,battery_id:a.battery_id});if(name==="P4")e.reference_id=reference;events.push(e)})
            resets[name]=result.reset_reason?[result.reset_reason]:[]
        })
        var output=geographicAlertSnapshot(Object.assign({},a,{
            caller_scope:"atomic_measured_P1_P2_P3_P4_P5_only",
            status:Object.keys(predictors).every(function(k){return predictors[k].status==="ok"})?"ok":"unknown",
            link_reference_id:reference,predictors:predictors,events:events,reset_reasons_by_predictor:resets,
            evaluated_predictors:["P1","P2","P3","P4","P5"],unassessed_predictors:[],
            continuous_boundary_known:false,latest_return_deadline_s:null,return_now_evaluated:false,
            recovery_reference_verified:false,telemetry_freshness_verified:false,measured_capacity:false,sensor_validated:false,
            independent_window_evidence:false,energy_correction_applied:false,landing_modeled:false,
            feasible:false,executable:false,candidates:[],rule_choice:null}))
        mission=nextMission;link=nextLink;wind=nextWind
        return output
    }}
}
