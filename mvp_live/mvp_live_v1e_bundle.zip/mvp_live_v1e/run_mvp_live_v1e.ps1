﻿# MVP live smoke v1e -- run ONCE on the user's PC after the user types the agreed hash8.
# Scope (user chose 2026-11-08 09:29 TW: "fix UI first, then test together"): warm-up, UI, mission/report only.
# Alerts and recognition already passed in v1d (087aef81, 2026-11-05) and are not rerun here.
# Preflight makes NO model call; if it fails, the script stops before any model call.
# Never cd into a subfolder of the thesis folder (thesis_guard hook); all paths are absolute.
# Output: <this folder>\out_run1 (must not exist). First result is kept as-is; fixes go to a new version.
# Sources: gateway 847f5a9 (ui budget 32 s), UI 1a58482 (state-machine model path, L01/L07 fixes, 32 s client),
# mission f54c7c1 (state-machine planner; smoke flies rule choice C3 so replanning is always exercised).

param([string]$UiRoot = "D:\UAV GCP\GCP UI圖\elan\ELAN_GCP_ui")
$ErrorActionPreference = "Continue"
$B = $PSScriptRoot
$OUT = Join-Path $B "out_run1"
$PY = "python"
$MODEL = "gemma4:e2b"
$GW_URL = "http://127.0.0.1:8090"
[System.Net.WebRequest]::DefaultWebProxy = New-Object System.Net.WebProxy
$env:NO_PROXY = "127.0.0.1,localhost"; $env:no_proxy = $env:NO_PROXY
foreach ($v in "GCS_LLM_BACKEND","GCS_LLM_URL","GCS_LLM_MODEL","GCS_LLM_URL_REPORT","GCS_LLM_TIMEOUT","PYTHONPATH") {
    Remove-Item "Env:$v" -ErrorAction SilentlyContinue }
$env:PYTHONIOENCODING = "utf-8"

if (Test-Path $OUT) { Write-Host "out_run1 already exists; refusing to overwrite."; exit 2 }
New-Item -ItemType Directory -Path $OUT | Out-Null
(Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ") | Set-Content (Join-Path $OUT "ran_at_utc.txt")

# ---------------- preflight (no model call)
$pre = [ordered]@{}
$pre.python = (& $PY --version 2>&1 | Out-String).Trim()
& $PY -c "import sys; sys.exit(0 if sys.version_info >= (3,11) else 1)"; $pre.python_ge_311 = ($LASTEXITCODE -eq 0)
& $PY -c "import PySide6; print(PySide6.__version__)" > (Join-Path $OUT "0_pyside6.txt") 2>&1
if ($LASTEXITCODE -ne 0) {
    # user approved 2026-11-02 21:55 TW: PySide6 6.8.3 from PyPI (4 win_amd64 wheels, about 202 MB)
    & $PY -m pip install --user "PySide6==6.8.3" > (Join-Path $OUT "0_pyside6_install.log") 2>&1
    $pre.pyside6_installed_now = ($LASTEXITCODE -eq 0)
    & $PY -c "import PySide6; print(PySide6.__version__)" >> (Join-Path $OUT "0_pyside6.txt") 2>&1 }
$pre.pyside6 = ($LASTEXITCODE -eq 0)
try { $tags = Invoke-RestMethod -Uri "http://127.0.0.1:11434/api/tags" -TimeoutSec 10
      $pre.ollama = $true; $pre.model_present = (@($tags.models | Where-Object { $_.name -eq $MODEL }).Count -gt 0) }
catch { $pre.ollama = $false; $pre.model_present = $false }
# Get-NetTCPConnection cannot see some listeners on this PC (seen with Ollama and the gateway), so use netstat + an HTTP probe
$ns = (netstat -ano -p TCP | Select-String -Pattern '^\s*TCP\s+\S+:8090\s+\S+:0\s')
$probe = $false; try { Invoke-WebRequest -UseBasicParsing -Uri "$GW_URL/health" -TimeoutSec 2 | Out-Null; $probe = $true } catch {}
$pre.port_8090_netstat = ($ns | Out-String).Trim()
$pre.port_8090_free = (-not $ns) -and (-not $probe)
$pre | ConvertTo-Json | Set-Content (Join-Path $OUT "0_preflight.json")
if (-not ($pre.python_ge_311 -and $pre.pyside6 -and $pre.ollama -and $pre.model_present -and $pre.port_8090_free)) {
    Write-Host "PREFLIGHT FAILED (no model call made):"; $pre | Format-List; exit 3 }

# ---------------- theme copy for UI color rows T01/T02 (read-only copy of formal UI theme + patch; no model call)
$THEME = Join-Path $OUT "theme_gcp"
& $PY -I (Join-Path $B "src\ui\ui_agent\test\prepare_theme_v6.py") $UiRoot $THEME > (Join-Path $OUT "0_theme_prepare.stdout") 2> (Join-Path $OUT "0_theme_prepare.stderr")
"$LASTEXITCODE" | Set-Content (Join-Path $OUT "0_theme_prepare.exit")
if ($LASTEXITCODE -ne 0) { Write-Host "THEME PREPARE FAILED (no model call made); see 0_theme_prepare.stdout"; exit 4 }

# ---------------- gateway
$env:GCS_GATEWAY_UPSTREAM = "ollama"; $env:GCS_GATEWAY_MODEL = $MODEL
$env:GCS_GATEWAY_LOG = Join-Path $OUT "gateway_calls.jsonl"
$env:PYTHONPATH = Join-Path $B "src\gateway"
$GW_PROC = Start-Process -FilePath $PY -ArgumentList "-P","-m","gcs_demo.llm_gateway" -PassThru -WindowStyle Hidden `
      -RedirectStandardOutput (Join-Path $OUT "1_gateway.stdout") -RedirectStandardError (Join-Path $OUT "1_gateway.stderr")
Remove-Item Env:PYTHONPATH
$ok = $false
for ($i = 0; $i -lt 20; $i++) { Start-Sleep -Milliseconds 500
    try { Invoke-RestMethod -Uri "$GW_URL/health" -TimeoutSec 2 | ConvertTo-Json -Depth 5 | Set-Content (Join-Path $OUT "1_gateway_health.json"); $ok = $true; break }
    catch { "try $i $(Get-Date -Format o): $($_.Exception.GetType().FullName): $($_.Exception.Message)" | Add-Content (Join-Path $OUT "1_gateway_health_errors.txt") } }
$summary = [ordered]@{ gateway_started = $ok }

function Step($name, $pp, [string[]]$pyargs) {
    if ($pp) { $env:PYTHONPATH = $pp } else { Remove-Item Env:PYTHONPATH -ErrorAction SilentlyContinue }
    $t0 = Get-Date
    & $PY @pyargs > (Join-Path $OUT "$name.stdout") 2> (Join-Path $OUT "$name.stderr")
    $code = $LASTEXITCODE
    Remove-Item Env:PYTHONPATH -ErrorAction SilentlyContinue
    "$code" | Set-Content (Join-Path $OUT "$name.exit")
    return [ordered]@{ exit = $code; seconds = [math]::Round(((Get-Date) - $t0).TotalSeconds, 1) }
}

try {
    if ($ok) {
        # warm-up: 1 call, loads the model so the UI 32 s wait is not eaten by model loading
        $body = '{"messages":[{"role":"user","content":"Reply with the JSON object {\"ok\": true} only."}]}'
        $t0 = Get-Date
        try { $r = Invoke-RestMethod -Method Post -Uri "$GW_URL/f/warmup/v1/chat/completions" -ContentType "application/json" `
                  -Body ([Text.Encoding]::UTF8.GetBytes($body)) -TimeoutSec 90
              $r | ConvertTo-Json -Depth 6 | Set-Content (Join-Path $OUT "2_warmup.json"); $summary.warmup = "ok" }
        catch { $_ | Out-String | Set-Content (Join-Path $OUT "2_warmup.error.txt"); $summary.warmup = "error" }
        $summary.warmup_seconds = [math]::Round(((Get-Date) - $t0).TotalSeconds, 1)

        $summary.ui = Step "3_ui" $null @("-P", (Join-Path $B "src\ui\ui_agent\test\run_live_ui_gateway_v6.py"), (Join-Path $OUT "ui"), "$GW_URL/f/ui/v1", $MODEL, $THEME)
        New-Item -ItemType Directory -Path (Join-Path $OUT "mission") | Out-Null
        $summary.mission = Step "5_mission" (Join-Path $B "src\mission") @("-P", "-m", "gcs_demo.smoke_mvp_mission", (Join-Path $OUT "mission\run1.json"))
    }
} finally {
    if ($GW_PROC -and -not $GW_PROC.HasExited) { Stop-Process -Id $GW_PROC.Id -Force }
    $summary | ConvertTo-Json -Depth 4 | Set-Content (Join-Path $OUT "summary.json")
    Get-ChildItem -Recurse -File $OUT | Get-FileHash -Algorithm SHA256 | ForEach-Object { "$($_.Hash)  $($_.Path.Substring($OUT.Length + 1))" } |
        Set-Content (Join-Path $B "out_run1.SHA256SUMS.txt")
    Write-Host "DONE"; $summary | ConvertTo-Json -Depth 4
}
if (-not $ok) { Write-Host "GATEWAY NOT STARTED: see 1_gateway_health_errors.txt (no model call made)"; exit 5 }
foreach ($k in "ui","mission") { if ($summary[$k] -and $summary[$k].exit -eq 2) { exit 6 } }
exit 0
